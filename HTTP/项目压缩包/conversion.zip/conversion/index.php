<?php
//    require 'Import.php';
    require 'Parse.php';
    $import = new Parse();
    $file = $_FILES['file'];
//    var_dump($file);die;
    if(empty($file)){
        echo "<script>alert('上传文件不能为空');</script>";
        echo "<script>history.back();</script>";
        exit;
    }
    move_uploaded_file($file["tmp_name"],$file["name"]);
    $result = $import->import($file['name']);
