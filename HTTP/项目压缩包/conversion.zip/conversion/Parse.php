<?php
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Reader;
use PhpOffice\PhpSpreadsheet\Worksheet;
use PhpOffice\PhpSpreadsheet\IOFactory;

class Parse
{
    public function import($file)
    {
        $csv = new ParseCsv\Csv($file);
        $data = $csv->data;
        /*for($i=0;$i<count($data);$i++){
            var_dump($data[$i],"<br><br><br><br><br><br>");
        }die;
        $key = 'Title';
        $data = $this->array_unset_tt($data,$key);*/
        $array = [];
        foreach ($data as $k => $v) {
            if(isset($array[$v['Handle']]))
            {
                $array[$v['Handle']]['Image Src'] = $array[$v['Handle']]['Image Src'].','.$v['Image Src'];
            }else{
                if(empty($array)){
                    $array[$v['Handle']] = $v;
                }else{
                    $make = 1;
                    foreach ($array as $keyd=>$valued) {
                        if(stripos($keyd,substr($v['Handle'],0,-3))!==false){
                            $make = 0;
                            break;
                        }
                    }
                    if($make == 1){
                        $array[$v['Handle']] = $v;
                    }
                }

            }
        }
        //$array = $this->array_unset_tt($array);
        $new_data = array(array());
        foreach ($array as $k =>$v)
        {
            $v['Body (HTML)'] = strip_tags($v['Body (HTML)']);
            $v['Published'] = 'true' ? 1 : '';
            if(!empty($v))
            {
//                $new_data[$k]['ID'] = $v['ID'];
                $new_data[$k]['Type'] = 'simple';
                $new_data[$k]['SKU'] = '';
                $new_data[$k]['Name'] = $v['Title'];
                $new_data[$k]['Published'] = $v['Published'];
                $new_data[$k]['Is featured?'] = 0;
                $new_data[$k]['Visibility in catalog'] = 'visible';
                $new_data[$k]['Short description'] = '';
                $new_data[$k]['Description'] = $v['Body (HTML)'];
                $new_data[$k]['Date sale price starts'] = '';
                $new_data[$k]['Date sale price ends'] = '';
                $new_data[$k]['Tax status'] = 'taxable';
                $new_data[$k]['Tax class'] = '';
                $new_data[$k]['In stock?'] = 1;
                $new_data[$k]['Stock'] = '';
                $new_data[$k]['Low stock amount'] = '';
                $new_data[$k]['Backorders allowed?'] = 0;
                $new_data[$k]['Sold individually?'] = 0;
                $new_data[$k]['Weight (g)'] = $v['Variant Grams'];
                $new_data[$k]['Length (cm)'] = '';
                $new_data[$k]['Width (cm)'] = '';
                $new_data[$k]['Height (cm)'] = '';
                $new_data[$k]['Allow customer reviews?'] = 1;
                $new_data[$k]['Purchase note'] = '';
                $new_data[$k]['Sale price'] = '';
                $new_data[$k]['Regular price'] = $v['Variant Price'];
                $new_data[$k]['Categories'] = 'shopify';
                $new_data[$k]['Tags'] = $v['Tags'];
                $new_data[$k]['Shipping class'] = '';
                $new_data[$k]['Images'] = $v['Image Src'];
                $new_data[$k]['Download limit'] = '';
                $new_data[$k]['Download expiry days'] = '';
                $new_data[$k]['Parent'] = '';
                $new_data[$k]['Grouped products'] = '';
                $new_data[$k]['Upsells'] = '';
                $new_data[$k]['Cross-sells'] = '';
                $new_data[$k]['External URL'] = '';
                $new_data[$k]['Button text'] = '';
                $new_data[$k]['Position'] = 0;
            }
        }
//        var_dump($new_data);die;
//'ID',
        $title = [
            'Type', 'SKU', 'Name', 'Published','Is featured?','Visibility in catalog',
            'Short description', 'Description', 'Date sale price starts', 'Date sale price ends',
            'Tax status', 'Tax class', 'In stock?', 'Stock', 'Low stock amount', 'Backorders allowed?',
            'Sold individually?','Weight (g)','Length (cm)', 'Width (cm)', 'Height (cm)',
            'Allow customer reviews?', 'Purchase note', 'Sale price', 'Regular price', 'Categories',
            'Tags', 'Shipping class', 'Images', 'Download limit', 'Download expiry days',
            'Parent', 'Grouped products', 'Upsells', 'Cross-sells',	'External URL',
            'Button text', 'Position'
        ];
        $spreadsheet = new Spreadsheet();
        $worksheet = $spreadsheet->getActiveSheet();
        foreach ($title as $key => $value) {
            $worksheet->setCellValueByColumnAndRow($key+1, 1, $value);
        }

        $row = 1; //从第二行开始
        foreach ($new_data as $item) {
            $column = 1;
            foreach ($item as $value) {
                $worksheet->setCellValueByColumnAndRow($column, $row, $value);
                $column++;
            }
            $row++;
        }

        $fileName = date('YmdHis');
        $fileType = 'Csv';
        ob_end_clean();
        //2.输出到浏览器
        $writer = IOFactory::createWriter($spreadsheet, 'Csv'); //按照指定格式生成Excel文件
        $this->excelBrowserExport($fileName, $fileType);
        $writer->save('php://output');

    }

    function excelBrowserExport($fileName, $fileType)
    {

        //文件名称校验
        if (!$fileName) {
            trigger_error('文件名不能为空', E_USER_ERROR);
        }

        //Excel文件类型校验
        $type = ['Excel2007', 'Xlsx', 'Excel5', 'xls', 'Csv'];
        if (!in_array($fileType, $type)) {
            trigger_error('未知文件类型', E_USER_ERROR);
        }

        if ($fileType == 'Excel2007' || $fileType == 'Xlsx') {
            header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
            header('Content-Disposition: attachment;filename="' . $fileName . '.xlsx"');
            header('Cache-Control: max-age=0');
        } else if($fileType == 'Csv') {
            //ob_end_clean();
            header('Content-Type: application/vnd.ms-excel;charset=UTF-8');
            header('Content-type: text/csv; charset=UTF-8');
            header('Content-Encoding: UTF-8');
            header('Content-Disposition: attachment;filename="' . $fileName . '.csv"');
            header('Cache-Control: max-age=0');
        }else {
            header('Content-Type: application/vnd.ms-excel');
            header('Content-Disposition: attachment;filename="' . $fileName . '.xls"');
            header('Cache-Control: max-age=0');
        }
    }
    /*
     * 去重
     * */
    function array_unset_tt($arr){
        //建立一个目标数组
        $res = array();
        foreach ($arr as $keye=>$value) {
            if(empty($res)){
                $res[$keye] = $value;
            }else{
                $make = 1;
                foreach ($res as $keyd=>$valued) {
                    if(stripos($keyd,substr($keye,0,-3))!==false){
                        $make = 0;
                        break;
                    }
                }
                if($make == 1){
                    $res[$keye] = $value;
                }
            }

        }
        return $res;
    }
}