<?php /*a:3:{s:47:"/var/www/html/lemocms/view/admin/order/add.html";i:1573134832;s:51:"/var/www/html/lemocms/view/admin/common/header.html";i:1574136639;s:51:"/var/www/html/lemocms/view/admin/common/footer.html";i:1572332123;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo config('admin.sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/admin/css/main.css" media="all">
    <link rel="stylesheet" href="/static/plugins/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style id="LM-bg-color">
    </style>
</head>
<div class="LM-container">
    <div class="LM-main">
        <div class="admin-main layui-anim layui-anim-upbit">
            <fieldset class="layui-elem-field layui-field-title">
                <legend><?php echo htmlentities($title); ?></legend>
            </fieldset>
            <form class="layui-form layui-form-pane" lay-filter="form">


                <div class="layui-form-item">
                    <label class="layui-form-label">日期</label>
                    <div class="layui-input-inline">
                        <input type="text" name="date" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>date" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">操作者姓名</label>
                    <div class="layui-input-inline">
                        <select name="username" lay-verify="required">
                            <option value="0">默认顶级</option>
                            <?php if(is_array($user) || $user instanceof \think\Collection || $user instanceof \think\Paginator): $i = 0; $__LIST__ = $user;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo htmlentities($vo['id']); ?>" <?php if(!empty($info) && $info['username']==$vo['username']): ?> selected <?php endif; ?> ><?php echo htmlentities($vo['username']); ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">主页姓名</label>
                    <div class="layui-input-inline">
                        <input type="text" name="homepage_name" placeholder="<?php echo lang('pleaseEnter'); ?>主页姓名" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">客户姓名</label>
                    <div class="layui-input-inline">
                        <input type="text" name="guest_name" placeholder="<?php echo lang('pleaseEnter'); ?>客户姓名" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">是否骗子</label>
                    <div class="layui-input-inline">
                        <select name="is_liar" lay-verify="required">
                            <option value="1" {if $info.is_liar == 1} selected>否</option>
                            <option value="2" {if $info.is_liar == 2} selected>是</option>
                        </select>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">订单状态</label>
                    <div class="layui-input-inline">
                        <select name="order_status" lay-verify="required">
                            <option value="0">默认顶级</option>
                            <?php if(is_array($ArticleCate) || $ArticleCate instanceof \think\Collection || $ArticleCate instanceof \think\Paginator): $i = 0; $__LIST__ = $ArticleCate;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo htmlentities($vo['id']); ?>" <?php if(!empty($info) && $info['order_status'] == $vo['id']): ?> selected <?php endif; ?> ><?php echo htmlentities($vo['title']); ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">订单号</label>
                    <div class="layui-input-inline">
                        <input type="text" name="order_number" placeholder="<?php echo lang('pleaseEnter'); ?>订单号" class="layui-input">
                    </div>
                </div>


<!--                <div class="layui-form-item">-->
<!--                    <label class="layui-form-label">订单状态</label>-->
<!--                    <div class="layui-input-inline">-->
<!--                        <input type="text" name="order_status" placeholder="<?php echo lang('pleaseEnter'); ?>订单状态" class="layui-input">-->
<!--                    </div>-->
<!--                </div>-->

                <div class="layui-form-item">
                    <label class="layui-form-label">关键词</label>
                    <div class="layui-input-inline">
                        <input type="text" name="keywords"  placeholder="<?php echo lang('pleaseEnter'); ?>关键词" class="layui-input">
                    </div>
<!--                    <div class="layui-form-mid layui-word-aux">-->
<!--                        (多个关键词用空格隔开)-->
<!--                    </div>-->
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">礼品卡卡号</label>
                    <div class="layui-input-inline">
                        <input type="text" name="gift_card" lay-verify="number" placeholder="<?php echo lang('pleaseEnter'); ?>点击量" class="layui-input">
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label">是否愿意留言</label>
                    <div class="layui-input-inline">
                        <input type="text" name="is_leave_comments" lay-verify="require" placeholder="<?php echo lang('pleaseEnter'); ?>点击量" class="layui-input">
                    </div>
                </div>


                <div class="layui-form-item">
                    <label class="layui-form-label">留评进度</label>
                    <div class="layui-input-inline">
                        <textarea type="text" name="message" lay-verify="require" placeholder="<?php echo lang('pleaseEnter'); ?>留评进度" class="layui-textarea"></textarea>
                    </div>
                </div>


                <div class="layui-form-item">
                    <label class="layui-form-label">内容</label>

                </div>
                <script id="container" name="content" type="text/plain"></script>

                <div class="layui-form-item">
                    <div class="layui-input-inline">
                        <input type="hidden" name="id"  >
                        <button type="button" class="layui-btn" lay-submit="" lay-filter="submit"><?php echo lang('submit'); ?></button>
                        <a href="<?php echo url('index'); ?>" class="layui-btn layui-btn-primary"><?php echo lang('back'); ?></a>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>

<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<?php echo $ueditor; ?>;


<script>
    layui.use(['form', 'layer','upload'], function () {
        var form = layui.form, layer = layui.layer,$= layui.jquery,upload = layui.upload;
        var info = '';

        info = <?php echo json_encode($info); ?>;
        form.val("form", info);
        if(info){
            $('#addPic').attr('src',info.thumb);
        }
        form.render();
        form.on('submit(submit)', function (data) {
            loading =layer.load(1, {shade: [0.1,'#fff']});
            $.post("", data.field, function (res) {
                layer.close(loading);
                if (res.code > 0) {
                    layer.msg(res.msg, {time: 1800, icon: 1}, function () {
                        location.href = res.url;
                    });
                } else {
                    layer.msg(res.msg, {time: 1800, icon: 2});
                }
            });
        });
        //普通图片上传
        var uploadInt = upload.render({
            elem: '#addBtn'
            ,url: '<?php echo url("uploads/uploads"); ?>'
            ,before: function(obj){
                //预读本地文件示例，不支持ie8
                obj.preview(function(index, file, result){
                    $('#addPic').attr('src', result); //图片链接（base64）
                });
            },
            done: function(res){
                if(res.code>0){
                    $('#avatar').val(res.url);
                }else{
                    //如果上传失败
                    return layer.msg('上传失败');
                }
            }
            ,error: function(){
                //演示失败状态，并实现重传
                var notice = $('#notice');
                notice.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                notice.find('.demo-reload').on('click', function(){
                    uploadInt.upload();
                });
            }
        });
    });
</script>