<?php /*a:3:{s:52:"/var/www/html/lemocms/view/admin/auth/admin_add.html";i:1573442284;s:51:"/var/www/html/lemocms/view/admin/common/header.html";i:1574136639;s:51:"/var/www/html/lemocms/view/admin/common/footer.html";i:1572332123;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo config('admin.sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/admin/css/main.css" media="all">
    <link rel="stylesheet" href="/static/plugins/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style id="LM-bg-color">
    </style>
</head>
<div class="LM-container">
    <div class="LM-main">
        <div class="admin-main layui-anim layui-anim-upbit">
            <fieldset class="layui-elem-field layui-field-title">
                <legend><?php echo htmlentities($title); ?></legend>
            </fieldset>
            <form class="layui-form layui-form-pane" lay-filter="form">
                <div class="layui-form-item">
                    <label class="layui-form-label">所属用户组</label>
                    <div class="layui-input-inline">
                        <select name="group_id" lay-verify="required">
                            <option value="">请选择用户组</option>
                            <?php if(is_array($authGroup) || $authGroup instanceof \think\Collection || $authGroup instanceof \think\Paginator): $i = 0; $__LIST__ = $authGroup;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo htmlentities($vo['id']); ?>" <?php if(!empty($info) && $info['group_id']==$vo['id']): ?> selected <?php endif; ?> ><?php echo htmlentities($vo['title']); ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label"><?php echo lang('username'); ?></label>
                    <div class="layui-input-inline">
                        <input type="text" name="username" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>登录用户名" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        用户名在4到25个字符之间。
                    </div>
                </div>

                <div class="layui-form-item">
                    <label class="layui-form-label"><?php echo lang('password'); ?></label>
                    <div class="layui-input-inline">
                        <input type="password" name="password" placeholder="<?php echo lang('pleaseEnter'); ?>登录密码" <?php if(!empty($info)): ?> lay-verify="required"<?php endif; ?> class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        密码必须大于6位，小于15位。
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label">头像</label>
                    <input type="hidden" name="avatar" id="avatar">
                    <div class="layui-input-inline">
                        <div class="layui-upload">
                            <button type="button" class="layui-btn layui-btn-primary" id="addBtn"><i class="icon icon-upload3"></i>点击上传</button>
                            <div class="layui-upload-list">
                                <img class="layui-upload-img" id="addPic">
                                <p id="notice"></p>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label"><?php echo lang('email'); ?></label>
                    <div class="layui-input-inline">
                        <input type="text" name="email" lay-verify="email" placeholder="<?php echo lang('pleaseEnter'); ?>用户邮箱" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        用于密码找回，请认真填写。
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label"><?php echo lang('公司名'); ?></label>
                    <div class="layui-input-inline">
                        <input type="text" name="company" lay-verify="" placeholder="<?php echo lang('pleaseEnter'); ?>公司名" class="layui-input">
                    </div>
                    <div class="layui-form-mid layui-word-aux">
                        当添加公司超级`管理员`时请务必添加
                    </div>
                </div>
                <div class="layui-form-item">
                    <label class="layui-form-label"><?php echo lang('mobile'); ?></label>
                    <div class="layui-input-inline">
                        <input type="text" name="mobile" lay-verify="phone" value="" placeholder="<?php echo lang('pleaseEnter'); ?>手机号" class="layui-input">
                    </div>
                </div>
                <div class="layui-form-item">
                    <div class="layui-input-inline">
                        <input type="hidden" name="id"  >
                        <button type="button" class="layui-btn" lay-submit="" lay-filter="submit"><?php echo lang('submit'); ?></button>
                        <a href="<?php echo url('adminList'); ?>" class="layui-btn layui-btn-primary"><?php echo lang('back'); ?></a>
                    </div>
                </div>
            </form>
        </div>

    </div>
</div>

<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<script>
    layui.use(['form', 'layer','upload'], function () {
        var form = layui.form, layer = layui.layer,$= layui.jquery,upload = layui.upload;
        var info = '';
        info = <?php echo json_encode($info); ?>;
        form.val("form", info);
        if(info){
            $('#addPic').attr('src',info.avatar);
        }
        form.render();
        form.on('submit(submit)', function (data) {
            loading =layer.load(1, {shade: [0.1,'#fff']});
            $.post("", data.field, function (res) {
                layer.close(loading);
                if (res.code > 0) {
                    layer.msg(res.msg, {time: 1800, icon: 1}, function () {
                        location.href = res.url;
                    });
                } else {
                    layer.msg(res.msg, {time: 1800, icon: 2});
                }
            });
        });
        //普通图片上传
        var uploadInt = upload.render({
            elem: '#addBtn'
            ,url: '<?php echo url("uploads/uploads"); ?>'
            ,before: function(obj){
                //预读本地文件示例，不支持ie8
                obj.preview(function(index, file, result){
                    $('#addPic').attr('src', result); //图片链接（base64）
                });
            },
            done: function(res){
                if(res.code>0){
                    $('#avatar').val(res.url);
                }else{
                    //如果上传失败
                    return layer.msg('上传失败');
                }
            }
            ,error: function(){
                //演示失败状态，并实现重传
                var notice = $('#notice');
                notice.html('<span style="color: #FF5722;">上传失败</span> <a class="layui-btn layui-btn-mini demo-reload">重试</a>');
                notice.find('.demo-reload').on('click', function(){
                    uploadInt.upload();
                });
            }
        });
    });
</script>