<?php /*a:3:{s:53:"/var/www/html/lemocms/view/admin/auth/admin_list.html";i:1572332123;s:51:"/var/www/html/lemocms/view/admin/common/header.html";i:1574136639;s:51:"/var/www/html/lemocms/view/admin/common/footer.html";i:1572332123;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo config('admin.sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/admin/css/main.css" media="all">
    <link rel="stylesheet" href="/static/plugins/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style id="LM-bg-color">
    </style>
</head>
<div class="LM-container">
    <div class="LM-main">
        <fieldset class="layui-elem-field layui-field-title">
            <legend><?php echo lang('admin'); ?><?php echo lang('list'); ?></legend>

            <blockquote class="layui-elem-quote">
                <div class="LM-table">
                    <div class="layui-inline">
                        <input type="text" name="keys" id="keys" lay-verify="required" placeholder="请输入" autocomplete="off" class="layui-input">

                    </div>
                    <button class="layui-btn data-add-btn layui-btn-sm" lay-submit="" lay-filter="add" id="search">搜索</button>
                    <a href="<?php echo url('adminAdd'); ?>" class="layui-btn layui-btn-sm layui-btn-warm"><?php echo lang('add'); ?><?php echo lang('admin'); ?></a>

                </div>

            </blockquote>

        </fieldset>

        <table class="layui-table" id="list" lay-filter="list"></table>
    </div>
</div>
<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<script type="text/html" id="action">
    <a href="<?php echo url('adminEdit'); ?>?id={{d.id}}" class="layui-btn layui-btn-xs"><?php echo lang('edit'); ?></a>
    {{# if(d.id==1){ }}
    <a href="#" class="layui-btn layui-btn-xs layui-btn-disabled"><?php echo lang('del'); ?></a>
    {{# }else{  }}
    <a href="#" class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><?php echo lang('del'); ?></a>
    {{# } }}
</script>
<script type="text/html" id="status">
    {{# if(d.id==1){ }}
    <input type="checkbox" disabled name="status" value="{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="status" checked>
    {{# }else{  }}
    <input type="checkbox" name="status" value="{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="status" {{ d.status == 1 ? 'checked' : '' }}>
    {{# } }}
</script>

<script>
    layui.use(['table','form','layer'], function() {
        var table = layui.table,form = layui.form,$ = layui.jquery;
        var tableIn = table.render({
            elem: '#list',
            url: '<?php echo url("adminList"); ?>',
            method:'post',
            title:'<?php echo lang("admin"); ?><?php echo lang("list"); ?>',
            cols: [[
                {field:'id', title: 'ID', width:60,fixed: true}
                ,{field:'username', title: '用户名', width:180}
                ,{field:'title', title: '<?php echo lang("adminGroup"); ?>', width:100}
                ,{field:'email', title: '<?php echo lang("email"); ?>', width:200}
                ,{field:'mobile', title: '<?php echo lang("mobile"); ?>', width:150}
                ,{field:'ip', title: '<?php echo lang("ip"); ?>',width:150,hide:true}
                ,{field:'status', title: '<?php echo lang("status"); ?>',width:150,toolbar: '#status'}
                ,{title:'操作',width:150, toolbar: '#action',align:"center"}
            ]]
        });
        form.on('switch(status)', function(obj){
            loading =layer.load(1, {shade: [0.1,'#fff']});
            var id = this.value;
            var is_open = obj.elem.checked===true?1:0;
            $.post('<?php echo url("adminState"); ?>',{'id':id,'is_open':is_open},function (res) {
                layer.close(loading);
                if (res.code>0) {
                    tableIn.reload();
                }else{
                    layer.msg(res.msg,{time:1000,icon:2});
                    return false;
                }
            })
        });
        table.on('tool(list)', function(obj){
            var data = obj.data;
            if(obj.event === 'del'){
                layer.confirm('<?php echo lang("Are you sure you want to delete it"); ?>', function(index){
                    $.post("<?php echo url('adminDel'); ?>",{id:data.id},function(res){
                        if (res.code>0) {
                            layer.msg(res.msg,{time:1000,icon:1});
                            obj.del();
                        }else{
                            layer.msg(res.msg,{time:1000,icon:2});
                        }
                    });
                    layer.close(index);
                });
            }
        });
        $('#LM-add').click(function () {
            var index = layer.open({
                type: 2,
                content: '<?php echo url("adminAdd"); ?>',
                area: ['800px', '600px'],
                maxmin: true
            });
            layer.full(index);
        })
        $('#search').click(function () {
            var $keys = $('#keys').val();
            if(!$keys){
                return layer.msg('请输入关键词');
            }

            tableIn.reload({ page: {page: 1},where: {keys: $keys}});

        })
    });
</script>
