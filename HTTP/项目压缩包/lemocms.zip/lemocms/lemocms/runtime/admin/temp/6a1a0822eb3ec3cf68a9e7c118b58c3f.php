<?php /*a:3:{s:49:"/var/www/html/lemocms/view/admin/order/index.html";i:1574237181;s:51:"/var/www/html/lemocms/view/admin/common/header.html";i:1574136639;s:51:"/var/www/html/lemocms/view/admin/common/footer.html";i:1572332123;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo config('admin.sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/admin/css/main.css" media="all">
    <link rel="stylesheet" href="/static/plugins/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style id="LM-bg-color">
    </style>
</head>
<div class="LM-container">
    <div class="LM-main">
        <fieldset class="layui-elem-field layui-field-title">
            <legend>订单<?php echo lang('list'); ?></legend>
            <blockquote class="layui-elem-quote">
                <div class="LM-table">

                    <div class="layui-inline">
                        <input type="text" id='date' name="date" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>日期" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-inline">
                        <input type="text" id='gift_card' name="gift_card" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>礼品卡卡号" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-inline">
                        <input type="text" id='order_number' name="order_number" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>订单号" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-inline">
                        <input type="text" id='homepage_name' name="homepage_name" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>主页名" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-inline">
                        <input type="text" id='guest_name' name="guest_name" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>客户名字" autocomplete="off" class="layui-input">
                    </div>

                    <div class="layui-inline">
                        <input type="text" id='message' name="message" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>催评进度" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-inline">
                        <input type="text" id='is_leave_comments' name="is_leave_comments" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>是否愿意留评" autocomplete="off" class="layui-input">
                    </div>
                    <div class="layui-inline">
                        <input type="text" id='keys' name="keys" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>关键词" autocomplete="off" class="layui-input">
                    </div>
                </div>
                <div style="width: 100%;height: 15px"></div>
                <div class="LM-table">
                    <div class="layui-inline">
                        <input type="text" id='content' name="content" lay-verify="required" placeholder="<?php echo lang('pleaseEnter'); ?>备注内容" autocomplete="off" class="layui-input">
                    </div>

                    <div class="layui-inline">
                        <form action="<?php echo url('import'); ?>" method="post" enctype="multipart/form-data">
                            <input type="file" name="file">
                            <button class="layui-btn data-add-btn layui-btn-sm" id="import">订单导入</button>
                        </form>
                    </div>

                    <div style="width: 514px; float: left">
                        <div class="layui-inline">
                            <input type="text" id='total' name="total" lay-verify="required|number" placeholder="<?php echo lang('pleaseEnter'); ?>催评数量" autocomplete="off" class="layui-input">
                        </div>

                        <form class="layui-form layui-form-pane" action="" style="width: 100px;float: left;margin-right: 10px;">
                            <div class="layui-inline">
                                <select name="orders_status" id="orders_status" lay-verify="required">
                                    <option value>订单状态</option>
                                    <?php if(is_array($shipment_status) || $shipment_status instanceof \think\Collection || $shipment_status instanceof \think\Paginator): $i = 0; $__LIST__ = $shipment_status;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vo): $mod = ($i % 2 );++$i;?>
                                    <option value="<?php echo htmlentities($vo['id']); ?>"><?php echo htmlentities($vo['title']); ?></option>
                                    <?php endforeach; endif; else: echo "" ;endif; ?>
                                </select>
                            </div>
                        </form>
                        <form class="layui-form layui-form-pane" action="" style="width: 100px;float: left;margin-right: 10px;">
                            <div class="layui-inline">
                                <select name="is_liar" id="is_liar" lay-verify="required">
                                    <option value>是否骗子</option>
                                    <option value="1">否</option>
                                    <option value="2">是</option>
                                </select>
                            </div>
                        </form>
                        <form class="layui-form layui-form-pane" action="" style="width: 100px;float: left;margin-right: 10px;">
                            <div class="layui-inline">
                                <select name="conditions" id="conditions" lay-verify="required">
                                    <option value>筛选条件</option>
                                    <option value="0">等于</option>
                                    <option value="1">大于</option>
                                    <option value="2">小于</option>
                                </select>
                            </div>
                        </form>
                    </div>
                    <button class="layui-btn data-add-btn layui-btn-sm" lay-submit="" lay-filter="add" id="search" style="width: 70px;margin-left: 50px;margin-right: 30px;"><?php echo lang('search'); ?></button>
                    <a href="<?php echo url('add'); ?>"  class="layui-btn layui-btn-sm layui-btn-warm"><?php echo lang('add'); ?>订单</a>
                </div>
<!--                <div style="width: 100%;height: 15px">-->

<!--                <div class="LM-table">-->
<!--                    <div class="layui-inline">-->
<!--                        <label class="layui-form-label" style="padding: 9px 0 9px 5px;text-align: center">开始时间:</label>-->
<!--                        <div class="layui-input-inline">-->
<!--                            <input type="text" class="layui-input" id="starttime" placeholder="选择开始时间">-->
<!--                        </div>-->
<!--                    </div>-->
<!--                    <div class="layui-inline">-->
<!--                        <label class="layui-form-label" style="padding: 9px 0 9px 5px;text-align: center">结束时间:</label>-->
<!--                        <div class="layui-input-inline">-->
<!--                            <input type="text" class="layui-input" id="endtime" placeholder="选择结束时间">-->
<!--                        </div>-->
<!--                    </div>-->
<!--                </div>-->
<!--                    <div class="layui-inline" style="margin-left: 5px;margin-right: 20px;">-->
<!--                        <a href="javascript:void(0);" onclick="submit(this)" class="layui-btn data-add-btn layui-btn-sm">excel导出</a>-->
<!--                    </div>-->
            </blockquote>

        </fieldset>



        <table class="layui-table" id="list" lay-filter="list"></table>
    </div>
</div>


<script type="text/html" id="action">
    <a href="<?php echo url('total'); ?>?id={{d.id}}" class="layui-btn layui-btn-danger  layui-btn-xs" lay-event="edit">催评</a>
    <a href="<?php echo url('edit'); ?>?id={{d.id}}" class="layui-btn  layui-btn-xs" lay-event="edit"><?php echo lang('edit'); ?></a>
    <a  class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><?php echo lang('del'); ?></a>
</script>
<script type="text/html" id="status">
    <input type="checkbox" name="status" value="{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="status" {{ d.status == 1 ? 'checked' : '' }}>
</script>
<script type="text/html" id="thumb">
    {{d.title}}<img src="/static/admin/images/image.gif" onmouseover="layer.tips('<img src={{d.thumb}}>',this,{tips: [1, '#fff']});" onmouseout="layer.closeAll();">
</script>
<script type="text/html" id="start_time">
    {{layui.util.toDateString(d.start_time*1000, 'yyyy/MM/dd HH:mm:ss')}}
</script>
<script type="text/html" id="publish_time">
    {{layui.util.toDateString(d.publish_time*1000, 'yyyy/MM/dd HH:mm:ss')}}
</script>
<script type="text/html" id="create_time">
    {{layui.util.toDateString(d.create_time*1000, 'yyyy/MM/dd HH:mm:ss')}}
</script>
<!--<script type="text/html" id="update_time">-->
<!--    {{layui.util.toDateString(d.update_time*1000, 'yyyy-MM-dd HH:mm:ss')}}-->
<!--</script>-->
<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<script>
    layui.use(['form', 'table'], function () {
        var $ = layui.jquery,
            form = layui.form,
            table = layui.table;

        var tableIn = table.render({
            elem: '#list',
            url: '<?php echo url("index"); ?>',
            method: 'post',
            cols: [[
                {checkbox: true, fixed: true},
                {field: 'id', title: 'ID', width: 80, fixed: true, sort: true},
                {field: 'date', title: '日期', width: 80, fixed: true, sort: true},
                {field: 'homepage_name', title: '主页名字', width: 110, fixed: true, sort: true},
                {field: 'shipment', title: '配送状态', width: 110, fixed: true, sort: true},
                {field: 'guest_name', title: '客户名字', width: 110, fixed: true, sort: true},
                {field: 'is_liar', title: '是否骗子', width: 110, fixed: true, sort: true},
                {field: 'order_number', title: '订单号', width: 120, fixed: true,},
                {field: 'content', title: '备注内容', width: 250},
                {field: 'keywords', title: '关键词', width: 180},
                {field: 'gift_card', title: '礼品卡卡号', width: 180},
                {field: 'is_leave_comments', title: '是否愿意留评', width: 180},
                {field: 'total', title: '催评次数', width: 180},
                {field: 'message', title: '催评进度', width: 180},
                {field: 'createtime', title: '添加时间', width: 180,templet:'#create_time'},
                {field: 'updatetime', title: '修改时间', width: 180,templet:'#update_time'},
                {title:'操作',width:180, toolbar: '#action',align:"center"}

            ]],
            limits: [10, 15, 20, 25, 50, 100],
            limit: 15,
            page: true,
            done:function () {
                $("[data-field='is_liar']").children().each(function(){
                    if($(this).text()=='1'){
                        $(this).text("不是骗子")
                    }else if($(this).text()=='2'){
                        $(this).text("骗子")
                    }
                })
            }
        });



        table.on('tool(list)', function(obj){
            var data = obj.data;
            if(obj.event === 'del'){
                layer.confirm('<?php echo lang("Are you sure you want to delete it"); ?>', function(index){
                    loading =layer.load(1, {shade: [0.1,'#fff']});
                    $.post("<?php echo url('delete'); ?>",{id:data.id},function(res){
                        layer.close(loading);
                        layer.close(index);
                        if(res.code>0){
                            layer.msg(res.msg,{time:1000,icon:1});
                            obj.del();
                        }else{
                            layer.msg(res.msg,{time:1000,icon:2});
                        }
                    });
                });
            }

        });

        form.on('switch(status)', function(data){
            loading =layer.load(1, {shade: [0.1,'#fff']});
            var status = $(this).attr('checked')?0:1;
            $.post("<?php echo url('state'); ?>",{id:data.value,status:status},function(res){
                layer.close(loading);
                if(res.code>0){
                    layer.msg(res.msg,{time:1000,icon:1});
                }else{
                    layer.msg(res.msg,{time:1000,icon:2});
                }
            });
        });

        form.on('select', function(data){
            console.log(data.elem); //得到select原始DOM对象
            console.log(data.value); //得到被选中的值]
            $("#condition").val(data.value)
            console.log(data.othis); //得到美化后的DOM对象
        });
        form.on('select', function(data){
            console.log(data.elem); //得到select原始DOM对象
            console.log(data.value); //得到被选中的值]
            $("#is_liar").val(data.value)
            console.log(data.othis); //得到美化后的DOM对象
        });
        form.on('select', function(data){
            console.log(data.elem); //得到select原始DOM对象
            console.log(data.value); //得到被选中的值]
            $("#order_status").val(data.value)
            console.log(data.othis); //得到美化后的DOM对象
        });
        $('#search').click(function () {
            var $keys = $('#keys').val() ? $('#keys').val() :'';
            var $date = $('#date').val() ? $('#date').val() : '';
            var $gift_card = $('#gift_card').val() ? $('#gift_card').val() : '';
            var $order_number = $('#order_number').val() ? $('#order_number').val() : '';
            var $total = $('#total').val() ? $('#total').val() : '';
            var $condition = $("#conditions").val() ? $("#conditions").val() : '';
            var $is_liar = $("#is_liar").val() ? $("#is_liar").val() : '';
            var $message = $("#message").val() ? $("#message").val() : '';
            var $homepage_name = $("#homepage_name").val() ? $("#homepage_name").val() : '';
            var $guest_name = $("#guest_name").val() ? $("#guest_name").val() : '';
            var $order_status = $("#orders_status").val() ? $("#orders_status").val() : '';
            var $content = $("#content").val() ? $("#content").val() : '';
            var $is_leave_comments = $("#is_leave_comments").val() ? $("#is_leave_comments").val() : '';
            if($total !== '')
            {
                if($condition == '')
                {
                    alert('筛选条件不能为空！');
                    return;
                }
            }
            if($condition !== '')
            {
                if($total == '')
                {
                    alert('催评数量不能为空！');
                    return;
                }
            }

            tableIn.reload({
                page: {
                    page: 1
                },
                where: {
                    keys: $keys,
                    date:$date,
                    gift_card:$gift_card,
                    order_number:$order_number,
                    total:$total,
                    condition:$condition,
                    is_liar:$is_liar,
                    message:$message,
                    homepage_name:$homepage_name,
                    guest_name:$guest_name,
                    order_status:$order_status,
                    content:$content,
                    is_leave_comments:$is_leave_comments,
                }
            });

        })


    });


</script>
<script>
    layui.use('laydate', function() {
        var laydate = layui.laydate;
        laydate.render({
            elem: '#starttime'
            , type: 'datetime'

        });
        laydate.render({
            elem: '#endtime'
            , type: 'datetime'

        });
    })
</script>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script>
    function submit()
    {
        var starttime = document.getElementById('starttime').value;
        var endtime   = document.getElementById('endtime').value;
        window.location.href='export?starttime='+starttime+'&endtime='+ endtime;
    }
</script>
