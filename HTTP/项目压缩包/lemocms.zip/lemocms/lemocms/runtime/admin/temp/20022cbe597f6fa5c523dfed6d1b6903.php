<?php /*a:3:{s:53:"D:\lemocms\lemocms\view\admin\order\order_status.html";i:1573455526;s:48:"D:\lemocms\lemocms\view\admin\common\header.html";i:1574136639;s:48:"D:\lemocms\lemocms\view\admin\common\footer.html";i:1572332123;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo config('admin.sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/admin/css/main.css" media="all">
    <link rel="stylesheet" href="/static/plugins/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style id="LM-bg-color">
    </style>
</head>
<div class="LM-container">
    <div class="LM-main">
        <div class="admin-main layui-anim layui-anim-upbit">
            <fieldset class="layui-elem-field layui-field-title">
                <legend>配送分类<?php echo lang('list'); ?></legend>
                <blockquote class="layui-elem-quote">
                    <div class="LM-table">
                        <div class="layui-inline">
                        </div>
                        <a href="<?php echo url('shipmentAdd'); ?>" class="layui-btn layui-btn-sm"><?php echo lang('add'); ?>配送状态</a>
                    </div>
                </blockquote>
            </fieldset>
            <table class="layui-table" id="treeGrid" lay-filter="treeGrid"></table>
        </div>
    </div>
</div>


<script type="text/html" id="action">
    <a href="<?php echo url('shipmentEdit'); ?>?id={{d.id}}" class="layui-btn  layui-btn-xs" lay-event="edit"><?php echo lang('edit'); ?></a>
    <a  class="layui-btn layui-btn-danger layui-btn-xs" lay-event="del"><?php echo lang('del'); ?></a>
</script>
<script type="text/html" id="status">
    <input type="checkbox" name="status" value="{{d.id}}" lay-skin="switch" lay-text="开启|关闭" lay-filter="status" {{ d.status == 1 ? 'checked' : '' }}>
</script>
<script type="text/html" id="create_time">
    {{layui.util.toDateString(d.create_time*1000, 'yyyy/MM/dd HH:mm:ss')}}
</script>
<!--<script type="text/html" id="update_time">-->
<!--    {{layui.util.toDateString(d.update_time*1000, 'yyyy-MM-dd HH:mm:ss')}}-->
<!--</script>-->
<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<script>
    var editObj=null,ptable=null,treeGrid=null,tableId='treeGrid',layer=null;
    layui.config({
        base: '/static/plugins/layui/extend/'
    }).extend({
        treeGrid: 'treeGrid/treeGrid'
    }).use(['jquery','treeGrid','layer','form','table'], function(){
        var $=layui.jquery ,form = layui.form;
        treeGrid = layui.treeGrid;
        layer=layui.layer;

        ptable=treeGrid.render({
            id:tableId
            ,elem: '#'+tableId
            ,idField:'id'
            ,url:'<?php echo url("order_status"); ?>'
            ,cellMinWidth: 100
            ,treeId:'id'//树形id字段名称
            ,treeUpId:'pid'//树形父id字段名称
            ,treeShowName:'title'//以树形式显示的字段
            ,height:'full-140'
            ,isFilter:false
            ,iconOpen:true//是否显示图标【默认显示】
            ,isOpenDefault:true//节点默认是展开还是折叠【默认展开】
            ,cols: [[
                {checkbox: true, fixed: true},
                {field: 'id', title: 'ID', width: 80, fixed: true, sort: true},
                {field: 'title', title: '分类名称', width: 120, fixed: true,},
                {field: 'status', title: '状态', width: 180, templet:'#status'},
                {field: 'create_time', title: '添加时间', width: 180,templet:'#create_time'},
                // {field: 'update_time', title: '修改时间', width: 180,templet:'#update_time'},
                {title:'操作',width:150, toolbar: '#action',align:"center"}
            ]],
            limits: [10, 15, 20, 25, 50, 100],
            limit: 15,
            page: true,
        });
        treeGrid.on('tool('+tableId+')',function (obj) {
            var data = obj.data;
            if(obj.event === 'del'){
                layer.confirm('<?php echo lang("Are you sure you want to delete it"); ?>', function(index){
                    var loading = layer.load(1, {shade: [0.1, '#fff']});
                    $.post("<?php echo url('cateDel'); ?>",{id:data.id},function(res){
                        layer.close(loading);
                        if(res.code==1){
                            layer.msg(res.msg,{time:1000,icon:1});
                            obj.del();
                        }else{
                            layer.msg(res.msg,{time:1000,icon:2});
                        }
                    });
                    layer.close(index);
                });
            }
        });



        form.on('switch(status)', function(data){
            loading =layer.load(1, {shade: [0.1,'#fff']});
            var status = $(this).attr('checked')?0:1;
            $.post("<?php echo url('cateState'); ?>",{id:data.value,status:status},function(res){
                layer.close(loading);
                if(res.code>0){
                    layer.msg(res.msg,{time:1000,icon:1});
                }else{
                    layer.msg(res.msg,{time:1000,icon:2});
                }
            });
        });

        $('#search').click(function () {
            var $keys = $('#keys').val();
            if(!$keys){
                return layer.msg('请输入关键词');
            }

            treeGrid.reload(tableId,{page: {page: 1},where: {keys: $keys}});

        })


    });

    function openAll() {
        var treedata=treeGrid.getDataTreeList(tableId);
        treeGrid.treeOpenAll(tableId,!treedata[0][treeGrid.config.cols.isOpen]);
    }
</script>