<?php /*a:3:{s:46:"D:\lemocms\lemocms\view\admin\index\index.html";i:1572332123;s:48:"D:\lemocms\lemocms\view\admin\common\header.html";i:1574136639;s:48:"D:\lemocms\lemocms\view\admin\common\footer.html";i:1572332123;}*/ ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title><?php echo config('admin.sys_name'); ?>后台管理</title>
    <meta name="renderer" content="webkit">
    <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <meta name="apple-mobile-web-app-status-bar-style" content="black">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="format-detection" content="telephone=no">
    <link rel="stylesheet" href="/static/plugins/layui/css/layui.css" media="all" />
    <link rel="stylesheet" href="/static/admin/css/main.css" media="all">
    <link rel="stylesheet" href="/static/plugins/font-awesome-4.7.0/css/font-awesome.min.css" media="all">
    <!--[if lt IE 9]>
    <script src="https://cdn.staticfile.org/html5shiv/r29/html5.min.js"></script>
    <script src="https://cdn.staticfile.org/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->
    <style id="LM-bg-color">
    </style>
</head>
<link rel="stylesheet" href="/static/admin/css/common.css" media="all">

<body class="layui-layout-body LM-all">
<div class="layui-layout layui-layout-admin">

    <div class="layui-header header">
        <div class="layui-logo"><a href="">
            <img src="<?php echo site_logo(); ?>" alt="lemocms">
            <h1><?php echo site_name(); ?></h1>
        </a>
        </div>
        <a>
            <div class="LM-tool"><i title="展开" class="fa fa-outdent" data-side-fold="1"></i></div>
        </a>

        <ul class="layui-nav layui-layout-left layui-header-menu layui-header-pc-menu mobile layui-hide-xs">
        </ul>
        <ul class="layui-nav layui-layout-left layui-header-menu mobile layui-hide-sm">
            <li class="layui-nav-item">
                <a href="javascript:;"><i class="fa fa-list-ul"></i> 选择模块</a>
                <dl class="layui-nav-child layui-header-mini-menu">
                </dl>
            </li>
        </ul>

        <ul class="layui-nav layui-layout-right">
            <li class="layui-nav-item">
                <a href="javascript:;" data-refresh="刷新"><i class="fa fa-refresh"></i></a>
            </li>
            <li class="layui-nav-item">
                <a href="javascript:;" data-clear="清理" data-href="<?php echo url('cleardata'); ?>" class="LM-clear"><i class="fa fa-trash-o"></i></a>
            </li>
            <li class="layui-nav-item LM-setting">
                <a href="javascript:;"><?php echo session('admin.username'); ?></a>
                <dl class="layui-nav-child">
                    <dd>
                        <a href="javascript:;" data-iframe-tab="<?php echo url('auth/adminEdit'); ?>" data-title="基本资料" data-icon="fa fa-gears">基本资料</a>
                    </dd>
                    <dd>
                        <a href="javascript:;" data-iframe-tab="<?php echo url('password'); ?>" data-title="修改密码" data-icon="fa fa-gears">修改密码</a>
                    </dd>
                    <dd>
                        <a href="javascript:;" class="login-out">退出登录</a>
                    </dd>
                </dl>
            </li>
            <li class="layui-nav-item LM-setting">
                <a href="javascript:;"><?php echo lang('lang'); ?></a>
                <dl class="layui-nav-child">
                    <dd>
                        <a href="javascript:;" class="lang zh" data-icon="fa fa-gears">中文</a>
                    </dd>
                    <dd>
                        <a href="javascript:;" class="lang en" data-icon="fa fa-gears">English</a>
                    </dd>

                </dl>
            </li>
            <li class="layui-nav-item LM-select-bgcolor mobile layui-hide-xs">
                <a href="javascript:;" data-bgcolor="配色方案"><i class="fa fa-ellipsis-v"></i></a>
            </li>
        </ul>
    </div>

    <div class="layui-side layui-bg-black">
        <div class="layui-side-scroll layui-left-menu">
        </div>
    </div>

    <div class="layui-body">
        <div class="layui-tab" lay-filter="LMTab" id="top_tabs_box">
            <ul class="layui-tab-title" id="top_tabs">
                <li class="layui-this" id="LMHomeTabId" lay-id=""></li>
            </ul>
<!--            关闭按钮-->
            <ul class="layui-nav closeBox">
                <li class="layui-nav-item">
                    <a href="javascript:;"> <i class="fa fa-dot-circle-o"></i> 页面操作</a>
                    <dl class="layui-nav-child">
                        <dd><a href="javascript:;" data-page-close="other"><i class="fa fa-window-close"></i> 关闭其他</a></dd>
                        <dd><a href="javascript:;" data-page-close="all"><i class="fa fa-window-close-o"></i> 关闭全部</a></dd>
                    </dl>
                </li>
            </ul>
            <div class="layui-tab-content clildFrame">
                <!--           加载iframe          /-->
                <div id="LMHomeTabIframe" class="layui-tab-item layui-show"
                </div>

            </div>
        </div>

        <div class="layui-footer footer footer-demo" id="admin-footer">
            <div class="layui-main">
                <p>2018 ©
                    <a href="http://www.lemocms.com/">www.lemocms.com</a> Apache Licence 2.0
                </p>
            </div>
        </div>
    </div>


<script src="/static/plugins/layui/layui.js" charset="utf-8"></script>
<script>
    var menus ='<?php echo $menus; ?>';
    layui.config({
        base: "/static/admin/js/",
        version: true
    }).extend({
        LM: "LM"
    }).use(['element', 'layer', 'LM'], function () {
        var $ = layui.jquery,
            element = layui.element,
            layer = layui.layer;
            LM.init(menus);


    });
</script>
</body>

