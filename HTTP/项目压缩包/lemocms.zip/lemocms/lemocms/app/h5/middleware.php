<?php
/**
 * lemocms
 * ============================================================================
 * 版权所有 2018-2027 lemocms，并保留所有权利。
 * 网站地址: https://www.lemocms.com
 * ----------------------------------------------------------------------------
 * 采用最新Thinkphp6实现
 * ============================================================================
 * Author: yuege
 * Date: 2019/8/2
 */
return [
//    // 全局请求缓存
////     \think\middleware\CheckRequestCache::class,
//    //  多语言加载
//     \think\middleware\LoadLangPack::class,
//    // Session初始化
    \think\middleware\SessionInit::class,
//    // 页面Trace调试
//    // \think\middleware\TraceDebug::class,
    //权限验证
    \app\h5\middleware\InAppCheck::class,
];
