<?php
namespace app\api\controller\v1;

use lemo\api\Token as T;

/**
 * 生成token
 */
class Token extends T
{

}