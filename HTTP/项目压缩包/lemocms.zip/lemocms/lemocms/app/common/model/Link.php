<?php


namespace app\common\model;


class Link extends Common {

    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

}
