<?php

namespace app\common\model;
class Config extends Common
{
    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

}