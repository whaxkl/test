<?php


namespace app\common\model;

use app\common\model\Common;
use app\common\model\Module as M;
use think\facade\Config;

class FieldType extends Common {

    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }



}
