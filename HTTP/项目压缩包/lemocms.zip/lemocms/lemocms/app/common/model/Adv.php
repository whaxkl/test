<?php


namespace app\common\model;

use app\common\model\Common;

class Adv extends Common {

    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

}
