<?php



namespace app\common\model;

class Common extends BaseModel {

    public function __construct(array $data = [])
    {
        parent::__construct($data);
    }

}