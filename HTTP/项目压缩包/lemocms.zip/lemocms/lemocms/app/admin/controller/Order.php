<?php


namespace app\admin\controller;
use http\Message;
use think\App;
use think\facade\Db;
use think\facade\Lang;
use think\facade\Request;
use think\facade\View;
use lemo\helper\TreeHelper;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Worksheet\PageSetup;
use PhpOffice\PhpSpreadsheet\Cell\DataType;
use PhpOffice\PhpSpreadsheet\Style\Fill;
use PhpOffice\PhpSpreadsheet\Style\Color;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Style\Border;
use PhpOffice\PhpSpreadsheet\Style\NumberFormat;
use Overtrue\Pinyin\Pinyin;
use lemo\helper\SignHelper;
use think\facade\Session;
use app\admin\model\AuthGroup;
class Order extends Base
{
    public function __construct(App $app)
    {
        parent::__construct($app);
    }

    public function index()
    {
        $info = Session::get('admin');
        $info = json_decode($info,TRUE);
        if(Request::isPost()){
            $keys = Request::post('keys','','trim');
            $date = Request::post('date','','trim');
            $gift_card = Request::post('gift_card','','trim');
            $condition = Request::post('condition','','trim');
            $is_liar = Request::post('is_liar','','trim');
            $message = Request::post('message','','trim');
            $homepage_name = Request::post('homepage_name','','trim');
            $guest_name = Request::post('guest_name','','trim');
            $order_status = Request::post('order_status','','trim');
            $content = Request::post('content','','trim');
            $is_leave_comments = Request::post('is_leave_comments','','trim');
            $order_number = Request::post('order_number','','trim');
            $number = Request::post('total','','trim');
            $page = Request::post('page') ? Request::post('page') : 1;

            $number = (int)$number;
//             0 等于 1大于 3小于
            if($condition == '')
            {
                $to['con']  = '>='.'0';
            }
            if($condition == '0')
            {
                $to['con'] = '='.$number;
            }
            if($condition == '1')
            {
                $to['con'] = '>='.$number;
            }
            if($condition == '2')
            {
                $to['con'] = '<'.$number;
            }


            $auth_username = $info['username'];
            $auth_company = $info['company'];

            if($info['group_id'] == 2)
            {
                $where[] = ['username','=',$auth_username];
            }else {
                $where = [];
            }
            if($info['group_id'] == 1)
            {
                $company = [];
            }else if($info['group_id'] == 4 || $info['group_id'] == 2){
                $company[] = ['company','=',$auth_company];
            }
            if($order_status == '')
            {
                $status = [];
            }else{
                $status[] = ['order_status','=',$order_status];
            }
            $list = Db::name('order')
                ->join('lm_order_schedule_total t','lm_order.id = t.order_id')
                ->join('lm_order_message_progress p','lm_order.id = p.order_id')
                ->join('lm_order_status s','lm_order.order_status = s.id')
                ->field('lm_order.*,t.total,p.message,s.title as shipment')
                ->where('lm_order.order_number','like','%'.$order_number.'%')
                ->where('lm_order.keywords','like','%'.$keys.'%')
                ->where('lm_order.gift_card','like','%'.$gift_card.'%')
                ->where('lm_order.date','like','%'.$date.'%')
                ->where('lm_order.homepage_name','like','%'.$homepage_name.'%')
                ->where('lm_order.is_leave_comments','like','%'.$is_leave_comments.'%')
                ->where('lm_order.guest_name','like','%'.$guest_name.'%')
                ->where('lm_order.content','like','%'.$content.'%')
                ->where($status)
                ->where('p.message','like','%'.$message.'%')
                ->where('lm_order.is_liar','like','%'.$is_liar.'%')
                ->where('total'.$to['con'])
                ->where($where)
                ->where($company)
                ->where('lm_order.delete_status',1)
                ->order('lm_order.id desc')
                ->paginate(['list_rows' => $this->pageSize, 'page' => $page])
                ->toArray();
           // foreach ($list['data'] as $key => $vo)
            //{
              //  if($vo['is_liar'] == 1)
                //{
                  //  $list['data'][$key]['is_liar'] = '不是骗子';
                //}else if($vo['is_liar'] == 2)
               // {
                 //   $list['data'][$key]['is_liar'] = '骗子';
               // }
           // }
            return $result = ['code'=>0,'msg'=>lang('get info success'),'data'=>$list['data'],'count'=>$list['total']];

            }
        $shipment_status = Db::name('order_status')->select()->toArray();
        $param = [
            'shipment_status'=>$shipment_status
        ];
        View::assign($param);
        return View::fetch();
    }

    public function add()
    {
        if(Request::isPost()) {
            $data = Request::post();
            $message['message'] = $data['message'];
            $message['createtime'] = date('Y-m-d H:i:s');
            unset($data['message']);
            $data['createtime'] = date('Y-m-d H:i:s');
            Db::startTrans();
            try {
                $res = Db::name('order')->insert($data);
                $id = Db::name('order')->getLastInsID();
                $message['order_id'] = $id;
                $pa['order_id'] = $id;
                $pa['total'] = 0;
                $pa['createtime'] = date('Y-m-d H:i:s');
                Db::name('order_schedule_total')->save($pa);
                Db::name('order_message_progress')->save($message);

                Db::commit();
            }catch (\Exception $e)
            {
                Db::rollBack();
                $this->error($e->getMessage());
            }
            if ($res) {
                $this->success(lang('添加成功！'));
            } else {
                $this->error(lang('添加失败！'));

            }
        }else{
            $ArticleCate = Db::name('order_status')->where('status',1)->select()->toArray();
            $user = Db::name('admin')->where('status',1)->select()->toArray();
            $params['name'] = 'container';
            $params['content'] = '';
            $view = [
                'info' => '',
                'ArticleCate' => $ArticleCate,
                'user' => $user,
                'title' => lang('add'),
                'ueditor'=>build_ueditor($params),
            ];
            View::assign($view);
            return View::fetch('add');
        }
    }

    public function edit()
    {
        if(Request::isPost()){
            $data = Request::post();
            $id = $data['id'];
            if(!$id){
                $this->error(lang('invalid data'));
            }
            $message['message'] = $data['message'];
            $message['updatetime'] = date('Y-m-d H:i:s');
            unset($data['message']);
            $data['updatetime'] = date('Y-m-d H:i:s');
            Db::startTrans();
            try {
                $res = Db::name('order')->where('id',$id)->update($data);
                $message['order_id'] = $id;
                Db::name('order_message_progress')->where('order_id',$id)->update($message);

                Db::commit();
            }catch (\Exception $e)
            {
                Db::rollBack();
                $this->error($e->getMessage());
            }
            if ($res) {
                $this->success(lang('更新成功！'));
            } else {
                $this->error(lang('更新失败！'));
            }
        }else{
            $id =  Request::get('id');
            $info = Db::name('order')
                ->field('lm_order.*,lm_order_message_progress.message')
                ->join('lm_order_message_progress','lm_order.id = lm_order_message_progress.order_id')
                ->where('lm_order.id',$id)
                ->find();
            $ArticleCate = Db::name('order_status')->where('status',1)->select()->toArray();
            $user = Db::name('admin')->where('status',1)->select()->toArray();
            $params['name'] = 'container';
            $params['content'] = $info['content'];
            $view = [
                'info' => $info,
                'ArticleCate' => $ArticleCate,
                'user' => $user,
                'title' => lang('edit'),
                'ueditor'=>build_ueditor($params),
            ];
            View::assign($view);
            return View::fetch('add');
        }
    }

    public function delete()
    {
        if(Request::isPost())
        {
            $id = Request::post('id');
            $param['delete_status'] = 0;
            $param['deltime'] = date('Y-m-d H:i:s');
            $result = Db::name('order')->where('id',$id)->update($param);
            if($result)
            {
                $this->success('删除成功！');
            }else{
                $this->error('删除失败！');
            }
        }
    }

    public function order_status()
    {
        if(Request::isPost()){
            $keys = Request::post('keys','','trim');
            $page = Request::post('page') ? Request::post('page') : 1;
            $list = Db::name('order_status')
                ->where('title','like','%'.$keys.'%')
                ->paginate(['list_rows' => $this->pageSize, 'page' => $page])
                ->toArray();
            return $result = ['code'=>0,'msg'=>lang('get info success'),'data'=>$list['data'],'count'=>$list['total']];

        }
        return View::fetch();
    }

    public function shipmentAdd(){
        if(Request::isPost()) {
            $data = Request::post();
            $data['createtime'] = date('Y-m-d H:i:s');
            $res = \app\common\model\OrderStatus::create($data);
            if ($res) {
                $this->success(lang('add success'));
            } else {
                $this->error(lang('add fail'));

            }
        }else{
            $view = [
                'info' => '',
                'title' =>lang('add'),
            ];
            View::assign($view);
            return View::fetch('shipment_add');
        }
    }

    public function shipmentEdit(){
        if(Request::isPost()){
            $data = Request::post();
            $data['updatetime'] = date('Y-m-d H:i:s');
            if(!$data['id']){
                $this->error(lang('invalid data'));
            }

            $res = \app\common\model\OrderStatus::update($data);
            if($res){
                $this->success(lang('edit success'));
            }else{
                $this->error(lang('edit fail'));

            }
        }else{
            $id =  Request::get('id');
            $info = \app\common\model\OrderStatus::find($id);

            $view = [
                'info' => $info,
                'title' => lang('edit'),
            ];
            View::assign($view);
            return View::fetch('shipment_add');
        }
    }

    public function cateDel(){

        if(Request::isPost())
        {
            $id = Request::post('id');
            $result = Db::name('order_status')->where('id',$id)->delete();
            if($result)
            {
                $this->success('删除成功！');
            }else{
                $this->error('删除失败！');
            }
        }
    }


    public function cateState(){
        $data =  Request::post();
        $id = Request::post('id');
        if (empty($id)) {
            $this->error(lang('data not exist'));
        }
        $info  = \app\common\model\OrderStatus::find($id);
        $status = $info['status'] == 1 ? 0 : 1;
        $info->status = $status;
        $info->save();
        $this->success(lang('edit success'));

    }







    public function total()
    {
        $id = Request::get('id');
        if (empty($id)) {
            $this->error('data not exist');
        }
        $date['order_id'] = $id;
        $date['createtime'] = date('Y-m-d H:i:s');
        $num = Db::name('order_schedule_total')->where('order_id',$id)->field('total')->find();
        $result = Db::name('order_collection_schedule')->save($date);
        if($result)
        {
            $num['total'] = $num['total'] + 1;
            $num['updatetime'] = date('Y-m-d H:i:s');
            $res = Db::name('order_schedule_total')->where('order_id',$id)->update($num);
            if($res)
            {
                $this->success('催评成功！',url('index'));
            }
        }


    }

    /* 订单导出
     * @throws \PhpOffice\PhpSpreadsheet\Exception
     * @throws \PhpOffice\PhpSpreadsheet\Writer\Exception
     * lm_order -> 订单列表
     * lm_order_schedule_total -> 订单催收总数
     * lm_order_collection_schedule -> 订单催评进度
     * lm_order_message_progress -> 订单留言进度
     */

    public function export()
    {
//        $starttime = Request::get('starttime') ? Request::get('starttime') : '';
//        $endtime   = Request::get('endtime') ? Request::get('endtime') : '';
        $data = Db::name('order')
            ->join('lm_order_schedule_total t','lm_order.id = t.order_id')
            ->join('lm_order_message_progress p','lm_order.id = p.order_id')
            ->field('lm_order.*,t.total,p.message')
            ->where('lm_order.delete_status',1)
//            ->where('lm_order.createtime','between',[$starttime,$endtime])
            ->order('lm_order.id desc')
            ->select()
            ->toArray();
        if(empty($data))
        {
            $this->error('你要导出的数据是空的哇！',url('index'));
        }
        $title = [
            'id','date','homepage_name','username', 'guest_name',
            'is_liar','order_number', 'order_status','content','keywords',
            'gift_card','is_leave_comments', 'delete_status','createtime',
            'updatetime','deltime','total','message'
        ];

        $spreadsheet = new Spreadsheet();
        $worksheet = $spreadsheet->getActiveSheet();
        foreach ($title as $key => $value) {
            $worksheet->setCellValueByColumnAndRow($key+1, 1, $value);
        }

        $row = 2; //从第二行开始
        foreach ($data as $item) {
            $column = 1;
            foreach ($item as $value) {
                $worksheet->setCellValueByColumnAndRow($column, $row, $value);
                $column++;
            }
            $row++;
        }

        $fileName = date('YmdHis');
        $fileType = 'Xlsx';

        //1.下载到服务器
        //$writer = IOFactory::createWriter($spreadsheet, 'Xlsx');
        //$writer->save($fileName.'.'.$fileType);

        //2.输出到浏览器
        $writer = IOFactory::createWriter($spreadsheet, 'Xlsx'); //按照指定格式生成Excel文件
        $this->excelBrowserExport($fileName, $fileType);
        $writer->save('php://output');
    }

    public function import()
    {
        $info = Session::get('admin');
        $info = json_decode($info,TRUE);
        $file_size = $_FILES['file']['size'];
        if ($file_size > 5 * 1024 * 1024) {
            $this->error('文件大小不能超过5M');
            exit();
        }

        //限制上传表格类型
        $fileExtendName = substr(strrchr($_FILES['file']["name"], '.'), 1);
        //application/vnd.ms-excel  为xls文件类型
        if ($fileExtendName != 'xlsx') {
            $this->error('必须为excel表格，且必须为xlsx格式！');
            exit();
        }

        if (is_uploaded_file($_FILES['file']['tmp_name'])) {
            // 有Xls和Xlsx格式两种
            $objReader = IOFactory::createReader('Xlsx');

            $filename = $_FILES['file']['tmp_name'];
            $objPHPExcel = $objReader->load($filename);  //$filename可以是上传的表格，或者是指定的表格
            $sheet = $objPHPExcel->getSheet(0);   //excel中的第一张sheet
            $highestRow = $sheet->getHighestRow();       // 取得总行数
            $highestColumn = $sheet->getHighestColumn();   // 取得总列数
            //循环读取excel表格，整合成数组。如果是不指定key的二维，就用$data[i][j]表示。
            $pinyin = new Pinyin();
            Db::startTrans();
            try {
                for ($j = 2; $j <= $highestRow; $j++)
                {
                    $data[$j - 2] = [
                        'id' => $objPHPExcel->getActiveSheet()->getCell("A" . $j)->getValue(),
                        'homepage_name' => $objPHPExcel->getActiveSheet()->getCell("B" . $j)->getValue(),
                        'date' => $objPHPExcel->getActiveSheet()->getCell("C" . $j)->getValue(),
                        'username' => $objPHPExcel->getActiveSheet()->getCell("D" . $j)->getValue(),
                        'guest_name' => $objPHPExcel->getActiveSheet()->getCell("E" . $j)->getValue(),
                        'is_liar' => $objPHPExcel->getActiveSheet()->getCell("F" . $j)->getValue(),
                        'order_number' => $objPHPExcel->getActiveSheet()->getCell("G" . $j)->getValue(),
                        'order_status' => $objPHPExcel->getActiveSheet()->getCell("H" . $j)->getValue(),
                        'content' => $objPHPExcel->getActiveSheet()->getCell("I" . $j)->getValue(),
                        'keywords' => $objPHPExcel->getActiveSheet()->getCell("J" . $j)->getValue(),
                        'gift_card' => $objPHPExcel->getActiveSheet()->getCell("K" . $j)->getValue(),
                        'is_leave_comments' => $objPHPExcel->getActiveSheet()->getCell("L" . $j)->getValue(),
                        'delete_status' => $objPHPExcel->getActiveSheet()->getCell("M" . $j)->getValue(),
                        'createtime' => $objPHPExcel->getActiveSheet()->getCell("N" . $j)->getValue(),
                        'updatetime' => $objPHPExcel->getActiveSheet()->getCell("O" . $j)->getValue(),
                        'deltime' => $objPHPExcel->getActiveSheet()->getCell("P" . $j)->getValue(),
                        'total' => $objPHPExcel->getActiveSheet()->getCell("Q" . $j)->getValue(),
                        'message' => $objPHPExcel->getActiveSheet()->getCell("R" . $j)->getValue(),
                    ];
                    if (empty($data[$j - 2]['username']))
                    {
                        throw new \Exception('操作者姓名不能为空！');
                    }
                    $time = date('Y-m-d H:i:s');
                    $params['total'] = $data[$j-2]['total'];
                    $params['createtime'] = $time;
                    $params['updatetime'] = $time;
                    $arr['message'] = $data[$j-2]['message'];
                    $arr['createtime'] = $time;
                    $arr['updatetime'] = $time;
                    //查询用户组用户
                    $user = Db::name('admin')->field('username')->select()->toArray();
                    $user = array_column($user, 'username');
                    unset($data[$j-2]['id'],$data[$j-2]['total'],$data[$j-2]['message']);
                    $data[$j-2]['username'] = str_replace('-','',$pinyin->permalink($data[$j - 2]['username']));
                    if (!in_array($data[$j-2]['username'], $user)) {
                        $param['username'] = $data[$j-2]['username'];
                        $param['password'] = $param['username'] . '123456';
                        $param['password'] = password_hash($param['password'], PASSWORD_BCRYPT, SignHelper::passwordSalt());
                        $param['mdemail'] = 0;
                        $param['group_id'] = 2;
                        $param['status'] = 1;
                        $param['company'] = $info['company'];
                        $param['create_time'] = time();
                        $param['update_time'] = time();
                        Db::name('admin')->save($param);
//                        $insert = Db::name('admin')->getLastInsID();
//                        $insert_array[] = $insert;
                    }
                    $data[$j-2]['company'] = $info['company'];
//                    dump($data[$j-2]);die;
                    $result = Db::name('order')->save($data[$j - 2]);
                    $id = Db::name('order')->getLastInsID();
                    $params['order_id'] = $id;
                    $arr['order_id'] = $id;

                    if($result == true)
                    {
                        Db::name('order_schedule_total')->save($params);
                        Db::name('order_message_progress')->save($arr);
                    }
                }
                Db::commit();
            } catch (\Exception $e) {
                Db::rollBack();
                $this->error($e->getMessage(), url('index'));
            }
//            dump($insert_array);
//            $insert_user = Db::name('admin')->where('id','in',$insert_array)->field('username')->select()->toArray();
//            dump($insert_user);die;
            if ($result == true) {
                $this->success('导入成功！', url('index'));
            }
        }
    }

        function excelBrowserExport($fileName, $fileType)
        {

            //文件名称校验
            if (!$fileName) {
                trigger_error('文件名不能为空', E_USER_ERROR);
            }

            //Excel文件类型校验
            $type = ['Excel2007', 'Xlsx', 'Excel5', 'xls'];
            if (!in_array($fileType, $type)) {
                trigger_error('未知文件类型', E_USER_ERROR);
            }

            if ($fileType == 'Excel2007' || $fileType == 'Xlsx') {
                header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
                header('Content-Disposition: attachment;filename="' . $fileName . '.xlsx"');
                header('Cache-Control: max-age=0');
            } else {
                header('Content-Type: application/vnd.ms-excel');
                header('Content-Disposition: attachment;filename="' . $fileName . '.xls"');
                header('Cache-Control: max-age=0');
            }
        }
    }
