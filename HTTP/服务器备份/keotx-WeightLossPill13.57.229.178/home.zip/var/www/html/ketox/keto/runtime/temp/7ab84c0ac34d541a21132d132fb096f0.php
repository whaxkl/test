<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:60:"E:\job\ketox\public/../application/front\view\user\shop.html";i:1571297806;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
    <title>Keto Weight Loss</title>
    <meta name="language" content="English">
    <meta name="copyright" content="Keto Weight Loss">
    <meta name="description" content="Rated #1 Keto Supplement Worldwide. 90-Day Money Back Guarantee On All Purchases.">
    <meta name="og:type" content="website">
    <meta name="og:description" content="Rated #1 Keto Supplement Worldwide. 90-Day Money Back Guarantee On All Purchases.">
    <meta name="og:image" content="/static/front/image/ketoweightloss_banner.jpg">
    <meta name="og:site_name" content="Keto Weight Loss">
    <meta name="og:locale" content="en_US">
    <link rel="apple-touch-icon" sizes="180x180" href="/static/front/image/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/static/front/image/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/static/front/image/favicon-16x16.png">
    <link rel="manifest" href="/assets/favicon/site.webmanifest">
    <link rel="shortcut icon" href="/static/front/image/favicon.ico">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-config" content="/assets/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="/static/front/css/bootstrap-4.3.0.min.css">
    <link rel="stylesheet" href="/static/front/css/fontawesome-all-5.7.1.min.css">
    <link rel="stylesheet" href="/static/front/css/defaults.css">
    <link rel="stylesheet" href="/static/front/css/global.css">
    <link rel="stylesheet" href="/static/front/css/font-futura.min.css">
    <link rel="stylesheet" href="/static/front/css/font-gilroy.min.css">
    <link rel="stylesheet" href="/static/front/css/flags32-iso-3166-1-alpha-2.min.css">
    <style type="text/css">
        #main-header{
            background: url('http://54.188.24.4:8080/static/front/image/shop.png') center/auto 80% no-repeat,
            url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;

        }
        #main-header .mh-part-2 .mh-list li.list-icon-feature-belly::before {
            background-image: url('http://54.188.24.4:8080/static/front/image/icon_feature_belly.svg');
        }

        #main-header .mh-part-2 .mh-list li.list-icon-feature-apple::before {
            background-image: url('http://54.188.24.4:8080/static/front/image/icon_feature_apple.svg');
        }

        #main-header .mh-part-2 .mh-list li.list-icon-feature-man::before {
            background-image: url('http://54.188.24.4:8080/static/front/image/icon_feature_man.svg');
        }

        #main-header .mh-part-2 .mh-list li.list-icon-feature-pill-bottle::before {
            background-image: url('http://54.188.24.4:8080/static/front/image/icon_feature_pill_bottle.svg');
        }

        #main-header .mh-part-2 .mh-list li.list-icon-feature-face-hands::before {
            background-image: url('http://54.188.24.4:8080/static/front/image/icon_feature_face_hands.svg');
        }
        #panel-bg-bonding{
            background-image: url('http://54.188.24.4:8080/static/front/image/panel_bg_bonding.jpg');
        }
        #panel-proven-results {
            background: linear-gradient(rgba(94, 191, 187, 0.7), rgba(94, 191, 187, 0.7)),
            url('http://54.188.24.4:8080/static/front/image/panel_proven_results_bg.jpg') center/auto 150% no-repeat;
        }
        #panel-no-strict-dieting{
            background: linear-gradient(rgba(38, 94, 133, 0.7), rgba(38, 94, 133, 0.7)),
            url('http://54.188.24.4:8080/static/front/image/panel_no_strict_dieting_bg.jpg') center/auto 150% no-repeat;
        }
        #panel-easy-to-use{
            background: linear-gradient(rgba(38, 94, 133, 0.7), rgba(38, 94, 133, 0.7)),
            url('http://54.188.24.4:8080/static/front/image/panel_easy_to_use_bg.jpg') center/auto 150% no-repeat;
        }
        #panel-keto-for-you{
            background: linear-gradient(rgba(94, 191, 187, 0.7), rgba(94, 191, 187, 0.7)),
            url('http://54.188.24.4:8080/static/front/image/panel_keto_for_you_bg.jpg') center/auto 150% no-repeat;
        }
        #panel-bg-confident{
            background-image: url('http://54.188.24.4:8080/static/front/image/panel_bg_confident.jpg');
        }
        #panel-bg-be-active{
            background-image: url('http://54.188.24.4:8080/static/front/image/panel_bg_girl.jpg');
        }
        #panel-what-is-bhb{
            background: url('http://54.188.24.4:8080/static/front/image/panel_why_is_bhb_bg.jpg') no-repeat;
            background-size:cover;
        }
        #panel-bg-be-happy{
            background-image: url('http://54.188.24.4:8080/static/front/image/panel_bg_happy.jpg');
        }
        #panel-about-us{
            background: linear-gradient(rgba(38, 94, 133, 0.7), rgba(38, 94, 133, 0.7)),
            url('http://54.188.24.4:8080/static/front/image/panel_bg_about_us.jpg') center/auto 150% no-repeat;
        }
        .vitangel-bg{
            background-image: url('http://54.188.24.4:8080/static/front/image/vita_angels.jpg');
        }
        @media (min-width: 576px) and (max-width: 767px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;

            }
        }
        @media (min-width: 992px) and (max-width: 1199px){
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') center/auto 74% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (min-width: 768px) and (max-width: 991px){
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') center/auto 77% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (min-width: 576px) and (max-width: 767px){
            #main-header .mh-part-1:before {
                background-image: url('http://54.188.24.4:8080/static/front/image/shop.png');
            }
        }
        @media (max-width: 575px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') 56px 60px/auto 28% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (max-width: 444px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') 8px 31px/auto 29% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (max-width: 413px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') 31px 28px/auto 27% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (max-width: 374px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') 9px 25px/auto 29% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (max-width: 360px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') 39px 21px/auto 29% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
        @media (max-width: 340px) {
            #main-header{
                background: url('http://54.188.24.4:8080/static/front/image/shop.png') 20px 21px/auto 29% no-repeat,
                url('http://54.188.24.4:8080/static/front/image/bg.png') center/auto 50% no-repeat;
            }
        }
    </style>	<link rel="stylesheet" href="/static/front/css/lander.css">
</head>
<body data-spy="scroll" data-target="#page-nav" data-page-lang="en">
<nav id="page-nav" class="navbar fixed-top navbar-expand-lg navbar-light">
    <div class="container">
        <a class="navbar-brand" href="javascript:location.reload();">
            <img src="/static/front/image/logo.png" alt="Keto Weight Loss logo" width="100px">
        </a>
        <a id="order_now" href="/front/User/index"
           class="order-btn font-weight-bold px-4 flex-column" role="button" style="display:none;width:160px;">
            <div style="height:33px;" class="nav-btn_color text-center">ORDER NOW</div>
            <div class="text-center shipping-text">Ships Worldwide</div>
        </a>
        <a id="free_shipping" href="#" class="order-btn font-weight-bold px-4 d-flex flex-column" role="button" style="width:130px;">
            <div class="row pr-5" style="border: 1px solid rgba(0,0,0,.1); border-radius:.25rem">
                <div class="col-6 px-0">
                    <div style="margin-right:-5px;" class="text-center"><ul class="f32 m-0 p-0" style="height:33px;">
                        <li class="flag us m-0 p-0"></li></ul>
                    </div>
                </div>
                <div class="col-6 px-0 text-left">
                    <div class="text-center shipping-text pt-1" style="line-height:12px;padding-left:6px;">
                        <span style="font-size:12px;font-weight:normal">Free</span> <span style="font-weight:normal">Shipping</span>							</div>

                </div>
            </div>
        </a>
        <button id="page-nav-mobile-toggler" class="navbar-toggler" type="button" data-toggle="collapse"
                data-target="#page-nav-navbar" aria-controls="page-nav-navbar" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div id="page-nav-navbar" class="collapse navbar-collapse">
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="#panel-how-keto-works" class="nav-link anchor-link text-uppercase">How it Works</a>
                </li>
                <li class="nav-item">
                    <a href="#panel-customer-reviews" class="nav-link anchor-link text-uppercase">Reviews</a>
                </li>
                <li class="nav-item">
                    <a href="#panel-what-is-bhb" class="nav-link anchor-link text-uppercase">Ingredients</a>
                </li>
                <li class="nav-item">
                    <a href="#panel-about-us" class="nav-link anchor-link text-uppercase">About Us</a>
                </li>
                <li class="nav-item">
                    <a href="/front/User/index" class="nav-link text-uppercase">Buy Now <i class="fas fa-shopping-cart"></i></a>
                </li>
            </ul>
        </div>
    </div>
</nav>
<main>
    <div class="custom-tmp-promo-banner" style="width:100%;position:fixed;z-index:10;">
        <div class="py-2 my-auto text-center" style="background-color:rgba(4, 60, 137, 1);color:white;
        font-weight:bold;padding-left:2px!important;padding-right:2px !important;">
            Limited Time: Enter Special Code 'FREEMONTH' At Checkout For 1 Additional Free Bottle Supply of Keto
        </div>
    </div>
    <div class="custom-tmp-promo-banner" style="width:100%;visibility:hidden;">
        <div class="py-2 my-auto text-center" style="background-color:rgba(4, 60, 137, 1);color:white;
        font-weight:bold;padding-left:2px!important;padding-right:2px !important;">
            Limited Time: Enter Special Code 'FREEMONTH' At Checkout For 1 Additional Free Bottle Supply of Keto
        </div>
    </div>
    <section id="main-header">
        <div class="container main-header-container-patch">
            <div class="row">
                <div class="mh-part-2 col-12 col-md-5 order-2 order-md-1 mt-1 mt-sm-0 py-4 pb-md-2 pb-lg-5 mt-lg-3">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="mh-title-2 mb-0 mt-1">
                                Super Charge your
                                <br>Weight&dash;Loss Goals&excl;
                            </h2>
                        </div>
                        <div class="mh-list-holder col-10 col-sm-7 col-md-12 pr-0">
                            <ul class="mh-list mt-2 mb-1 mb-sm-2 px-0 pt-md-2">
                                <li class="list-icon-feature-belly">Fat Block &amp; Burner</li>
                                <li class="list-icon-feature-apple">Appetite Control</li>
                                <li class="list-icon-feature-man">Metabolism Boost</li>
                                <li class="list-icon-feature-pill-bottle">Detox Naturally &amp; Safely</li>
                                <li class="list-icon-feature-face-hands">Revitalize Energy &amp; Mood</li>
                            </ul>
                        </div>
                        <div class="mh-i-icons mh-i-certifications col-8 mt-2 mt-lg-4 mt-xl-5 d-none d-xl-block">
                            <div class="row align-items-center text-center no-gutters">
                                <div class="col pr-2">
                                    <img src="/static/front/image/icon_made_in_usa.svg" alt="Made in USA">
                                </div>
                                <div class="col pr-2">
                                    <img src="/static/front/image/icon_gmp.svg" alt="GMP certified">
                                </div>
                                <div class="col pr-2">
                                    <img src="/static/front/image/icon_iso_9001.svg" alt="ISO 9001">
                                </div>
                                <div class="col pr-2">
                                    <img src="/static/front/image/icon_fssai.svg" alt="FSSAI">
                                </div>
                            </div>
                        </div>
                        <div class="mh-icons mh-icons-smallest col-12 col-sm-5 col-md-12 mt-xl-5">
                            <div class="row">
                                <div class="mh-i-icons mh-i-certifications col-12  col-md-10 mt-sm-2 mt-md-4 d-xl-none">
                                    <div class="row align-items-center text-center no-gutters d-flex justify-content-center">
                                        <div class="col-2 col-sm-3 pb-1 pb-sm-0">
                                            <img src="/static/front/image/icon_made_in_usa.svg" class="img-fluid"  alt="Made in USA">
                                        </div>
                                        <div class="col-2 col-sm-3 pb-1 pb-sm-0">
                                            <img src="/static/front/image/icon_gmp.svg" class="img-fluid" alt="GMP certified">
                                        </div>
                                        <div class="col-2 col-sm-3 pb-1 pb-sm-0">
                                            <img src="/static/front/image/icon_iso_9001.svg" class="img-fluid" alt="ISO 9001">
                                        </div>
                                        <div class="col-2 col-sm-3">
                                            <img src="/static/front/image/icon_fssai.svg" class="img-fluid" alt="FSSAI">
                                        </div>
                                    </div>
                                </div>
                                <div class="mh-i-icons mh-i-nutritional col-12 d-none d-sm-block d-md-none">
                                    <div class="row align-items-center text-center no-gutters mt-2 mt-xl-3">
                                        <div class="col-12 mb-2">
                                            <div class="row no-gutters">
                                                <div class="col d-none d-sm-inline">
                                                </div>
                                                <div class="col">
                                                    <img src="/static/front/image/icon_nutrition_gluten_free.svg" alt="Vegetarian">
                                                </div>
                                                <div class="col">
                                                    <img src="/static/front/image/icon_nutrition_all_natural.svg" alt="Gluten free">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="row no-gutters">
                                                <div class="col">
                                                    <img src="/static/front/image/icon_nutrition_dairy_free.svg" alt="Dairy free">
                                                </div>
                                                <div class="col">
                                                    <img src="/static/front/image/icon_nutrition_gmo_free.svg" alt="GMO free">
                                                </div>
                                                <div class="col">
                                                    <img src="/static/front/image/icon_nutrition_soy_free.svg" alt="Soy free">
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="mh-icons col-12 mt-3 d-sm-none mt-xl-5">
                            <div class="row">
                                <div class="mh-i-icons mh-i-nutritional col-12">
                                    <div class="row d-flex justify-content-center">
                                        <div class="col-2 px-1 px-sm-3 text-center ">
                                            <img src="/static/front/image/icon_nutrition_gluten_free.svg" alt="Vegetarian">
                                            <div>Gluten Free</div>
                                        </div>
                                        <div class="col-2 px-1 px-sm-3 text-center  ">
                                            <img src="/static/front/image/icon_nutrition_all_natural.svg" alt="Gluten free">
                                            <div>100% Natural</div>
                                        </div>
                                        <div class="col-2 px-1 px-sm-3 text-center ">
                                            <img src="/static/front/image/icon_nutrition_dairy_free.svg" alt="Dairy free">
                                            <div>Dairy Free</div>
                                        </div>
                                        <div class="col-2 px-1 px-sm-3 text-center ">
                                            <img src="/static/front/image/icon_nutrition_gmo_free.svg" alt="GMO free">
                                            <div>GMO Free</div>
                                        </div>
                                        <div class="col-2 px-1 px-sm-3 text-center ">
                                            <img src="/static/front/image/icon_nutrition_soy_free.svg" alt="Soy free">
                                            <div>Soy Free</div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mh-part-1 col-12 col-md-5 offset-md-2 order-1 order-md-2 mb-4 mb-sm-0 pt-2 pt-sm-4 pb-4 pb-md-2 pb-lg-5 pr-3 mt-lg-3 text-right">
                    <h2 class="mh-title-1 text-secondary mb-md-3 mb-lg-5">
                        Maintain Ketosis.<br>
                        Burn Fat Fast.<br>
                        Increase Energy.
                    </h2>
                    <a href="/front/User/index" class="btn btn-dark btn-lg btn-shop-now text-uppercase" role="button">Order Now &gt;&gt;</a>
                    <p class="mh-money-back-guarantee-label mb-0">&lpar;90&dash;Day Money Back Guarantee&excl;&rpar;</p>
                    <div class="mh-icons mt-md-4 mt-lg-5">
                        <div class="row">
                            <div class="mh-i-icons mh-i-nutritional col-12 d-none d-md-block">
                                <div class="row align-items-center text-center no-gutters mt-3 mb-md-1 mt-lg-4 mt-xl-2 mt-xl-3 d-flex justify-content-end">
                                    <div class="col-12 offset-4 offset-xl-0 col-xl-12 mb-2 mb-xl-0">
                                        <div class="row no-gutters d-flex justify-content-end">
                                            <div class="col-2">
                                                <img src="/static/front/image/icon_nutrition_gluten_free.svg" alt="Vegetarian">
                                                <div>Gluten-Free</div>
                                            </div>
                                            <div class="col-2">
                                                <img src="/static/front/image/icon_nutrition_all_natural.svg" alt="Gluten free">
                                                <div>100% Natural</div>
                                            </div>
                                            <div class="col-2">
                                                <img src="/static/front/image/icon_nutrition_dairy_free.svg" alt="Dairy free">
                                                <div>Dairy-Free</div>
                                            </div>
                                            <div class="col-2">
                                                <img src="/static/front/image/icon_nutrition_gmo_free.svg" alt="GMO free">
                                                <div>GMO-Free</div>
                                            </div>
                                            <div class="col-2">
                                                <img src="/static/front/image/icon_nutrition_soy_free.svg" alt="Soy free">
                                                <div>Soy-Free</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <section class="container container-patch">
        <div class="row color-box py-5">
            <div class="col">
                <h2 class="text-center pb-4">Live a Healthy Lifestyle Free From:</h2>
                <div class="row d-flex justify-content-center" style="font-size:18px;">
                    <div class="col-10 col-sm-5 col-md-4">
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle"></i> Fatigue, Low Energy</li>
                            <li><i class="fas fa-check-circle"></i> Insomnia</li>
                            <li><i class="fas fa-check-circle"></i> Belly, Waist, Flabby Arms</li>
                            <li class="d-block d-sm-none"><i class="fas fa-check-circle"></i> Stubborn, Unwanted Fat</li>
                            <li class="d-block d-sm-none"><i class="fas fa-check-circle"></i> Anxiety or Depression, Stress</li>
                            <li class="d-block d-sm-none"><i class="fas fa-check-circle"></i> Slow Digestive System</li>
                        </ul>
                    </div>
                    <div class="col-sm-5 col-md-4 d-none d-sm-inline">
                        <ul class="list-unstyled">
                            <li><i class="fas fa-check-circle"></i> Stubborn, Unwanted Fat</li>
                            <li><i class="fas fa-check-circle"></i> Anxiety or Depression, Stress</li>
                            <li><i class="fas fa-check-circle"></i> Slow Digestive System</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="container container-patch">
        <div class="row justify-content-center pt-5 pb-3">
            <div class="col-6 col-sm-4 text-center col-md-auto align-self-center">
                <img src="/static/front/image/KWL_CognitiveBottle.png" alt="" class="img-fluid bottle-img-special bottle-img-special-1">
            </div>
            <div class="col-12 col-sm-8 text-center text-sm-left">
                <div class="">
                    <header class="ps-header text-black">
                        <h2 class="ps-header-title">COGNITIVE NOOTROPICS / ENERGY BOOST</h2>
                        <hr class="ps-header-title-line ml-sm-0">
                    </header>
                </div>
                <p class="text-black">
                    Improves your mood, increases your alertness and enhances your mental
                    performance.
                    <br><br>
                    <b style="color:#1daabb;">Our formula is designed to enhance your "happy hormone" to help avoid the
                        Keto Flu symptoms.
                    </b>
                </p>
            </div>
        </div>
        <div class="row justify-content-center py-3">
            <div class="col-6 col-sm-4 text-center col-md-auto align-self-center">
                <img src="/static/front/image/shop.png" alt="" class="img-fluid bottle-img-special bottle-img-special-1">
            </div>
            <div class="col-12 col-sm-8 text-center text-sm-left">
                <div class="">
                    <header class="ps-header text-black">
                        <h2 class="ps-header-title">KETO GOBHB</h2>
                        <hr class="ps-header-title-line ml-sm-0">
                    </header>
                </div>
                <p class="text-black">
                    Help suppress appetite and increase energy levels, by utilizing bodyfat for
                    fuel, as opposed to glucose from carbohydrates.
                    <br><br>
                    <b style="color:#1daabb;">On the Keto Diet? Help kickstart your body into ketosis with our Go BHB
                        formula.
                    </b>
                </p>
            </div>
        </div>
        <div class="row justify-content-center py-3">
            <div class="col-6 col-sm-4 text-center col-md-auto align-self-center">
                <img src="/static/front/image/KetoWeightLoss_MCTPowder_Label.png" alt="" class="img-fluid bottle-img-special bottle-img-special-2">
            </div>
            <div class="col-12 col-sm-8 text-center text-sm-left">
                <div class="">
                    <header class="ps-header text-black">
                        <h2 class="ps-header-title">MCT &amp; COLLAGEN PEPTIDES POWDER</h2>
                        <hr class="ps-header-title-line ml-sm-0">
                    </header>
                </div>
                <p class="text-black">
                    Collagen is the most abundant protein in the human body that improves
                    your skin, nails and strengthens bones, joints and ligaments. While MCTs
                    are metabolized into ketones, increasing your energy.
                    <br><br>
                    <b style="color:#af6b58;">Our powder is an essential supplement to the Keto Diet as it combines MCT
                        with collagen for a ketogenic diet approved protein source that ensures
                        you are getting the vital collagen peptides.
                    </b>
                </p>
            </div>
        </div>
        <div class="row justify-content-center py-3">
            <div class="col-6 col-sm-4 text-center col-md-auto align-self-center">
                <img src="/static/front/image/KWL_Omega3_Bottle.png" alt="" class="img-fluid bottle-img-special bottle-img-special-1">
            </div>
            <div class="col-12 col-sm-8 text-center text-sm-left">
                <div class="">
                    <header class="ps-header text-black">
                        <h2 class="ps-header-title">KETO OPTIMIZED OMEGA 3</h2>
                        <hr class="ps-header-title-line ml-sm-0">
                    </header>
                </div>
                <p class="text-black">
                    Our doctor formulated OMEGA 3 provides exceptional potency and purity of
                    specialized, natural Omega-3 EFAs containing high-dose EPA and DHA in a
                    delicious citrus softgel.
                    <br><br>
                    A perfect pair with the Keto Diet. Omega 3 EFAs are the "good fats"
                    critical for human health and normal body function. The modern Western
                    Diet is out of "fat balance" and is low in Omega 3 EFAs.z
                    <br><br>
                    <b style="color:#1daabb;">Those on a Keto Diet can be even more out of fat
                        balance and sabotage their weight results!
                    </b>
                </p>
            </div>
        </div>
    </section>
    <section id="panel-why-keto" class="py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col">
                    <article>
                        <div class="ps-header-holder text-center">
                            <div class="row align-items-center center">
                                <div class="col">
                                    <header class="ps-header text-black">
                                        <h2 class="ps-header-title">Why KETO&quest;</h2>
                                        <hr class="ps-header-title-line">
                                    </header>
                                </div>
                            </div>
                        </div>
                        <div class="ps-body text-center px-sm-3 px-2">
                            <p>
                                KETO is a breakthrough way to fat‐burn for the everyday men and women on the go, busy moms, career‐focused worker bees, fitness lovers, and high‐performance athletes of all ages.
                            </p>
                            <p>
                                Our premium‐grade, natural extracts facilitate healthy rapid fat loss, elevate physical performance, contribute to greater mental clarity, improve mood by boosting feel‐good hormones, reduce stress by suppressing stress hormones like cortisol, and promote general well‐being and optimal health.
                            </p>
                            <p>
                                Our unique formula, that is made in the USA, puts your body into Ketosis quickly and easily.
                            </p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <div class="two-by-two-panel-section-holder container container-patch">
        <div class="row">
            <div id="panel-proven-results" class="col-12 col-sm-6 pr-1 py-4 py-md-5">
                <div class="container text-center py-4 py-md-5 h-100">
                    <header class="ps-header text-white">
                        <h2 class="ps-header-title">It has proven results</h2>
                    </header>

                    <div class="ps-body text-white">
                        <p>
                            Over 185,000 happy customers have already seen amazing results and benefits of KETO. Step up and get closer to your weight goals using KETO. It’s a great chance to join us now and witness the power of KETO.
                        </p>
                    </div>
                </div>
            </div>
            <div id="panel-no-strict-dieting" class="col-12 col-sm-6 pl-1 py-4 py-md-5">
                <div class="container text-center py-4 py-md-5 h-100">
                    <header class="ps-header text-white">
                        <h2 class="ps-header-title">NO STRICT DIETING</h2>
                    </header>

                    <div class="ps-body text-white">
                        <p>
                            You don’t have to worry about having a hard time dieting to lose weight. You can enjoy the amazing results without strict dieting and enjoy your favorite foods! Keto Weight loss is compatible with all diets and lifestyles.
                        </p>
                    </div>
                </div>
            </div>
            <div id="panel-easy-to-use" class="col-12 col-sm-6 pr-1 py-0 py-sm-1">
                <div class="container text-center py-4 py-md-5 h-100">
                    <header class="ps-header text-white">
                        <h2 class="ps-header-title">IT’S SO EASY TO USE</h2>
                    </header>

                    <div class="ps-body text-white">
                        <p>
                            There’s definitely no complicated diet program with KETO and you also don’t need to make special blends everyday. You will love to simply take 1 premium quality supplement, 2 capsules in the morning with a warm cup of lemon water, and lose weight as easy as 1‐2‐3!
                        </p>
                    </div>
                </div>
            </div>
            <div id="panel-keto-for-you"  class="col-12 col-sm-6 pl-1 py-0 py-sm-1">
                <div class="container text-center py-4 py-md-5 h-100">
                    <header class="ps-header text-white">
                        <h2 class="ps-header-title">KETO IS FOR YOU</h2>
                    </header>

                    <div class="ps-body text-white">
                        <p>
                            KETO is a breakthrough fat‐burning system for EVERYONE that need help with Fitness. You could be everyday woman on the go, busy moms, career‐focused worker bees, fitness lovers, and high‐performance athletes…
                        </p>
                    </div>
                </div>
            </div>

        </div>
    </div>
    <section id="panel-why-keto-works" class="py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col">
                    <article>
                        <div class="ps-header-holder text-center py-2">
                            <div class="row align-items-center center">
                                <div class="col">
                                    <header class="ps-header text-black">
                                        <h2 class="ps-header-title">Why it works&quest;</h2>
                                        <hr class="ps-header-title-line">
                                    </header>
                                </div>
                            </div>
                        </div>
                        <div class="ps-body text-center px-sm-3 px-2">
                            <p>
                                KETO is a breakthrough way to fat-burn for the everyday men and women on the go, busy moms, career-focused worker bees, fitness lovers, and high-performance athletes of all ages.
                            </p>
                            <p>
                                Our premium-grade, natural extracts facilitate healthy rapid fat loss, elevate physical performance, contribute to greater mental clarity, improve mood by boosting feel-good hormones, reduce stress by suppressing stress hormones like cortisol, and promote general well-being and optimal health.
                            </p>
                            <p>
                                Our unique vegetarian formula, that is made in the USA, puts your body into Ketosis quickly and easily. 100% Natural, Organic, and the first ever Keto supplement available.
                            </p>
                            <a href="/front/User/index" class="order-btn font-weight-bold px-4 nav-btn_color my-0 py-2" role="button">ORDER NOW</a>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section id="panel-bg-be-active" class="panel-section-bg-image container-fluid"></section>
    <div id="panel-how-keto-works" class="container container-patch">
        <div class="row ">
            <div class="col text-center">
                <header class="ps-header text-black">
                    <h2 class="ps-header-title">How it works&quest;</h2>
                    <hr class="ps-header-title-line">
                </header>
            </div>
        </div>
        <div class="row d-flex ps-body">
            <div class="col-12 col-md-6 mb-2 d-flex px-1">
                <div class="px-5 box panel-light">
                    <h1>1.</h1>
                    <p>
                        KETO is a weight-loss system that merges the synergistic power of 3 natural, plant‐based supplements. Thermogenic ingredients in this concentrated proprietary formula are scientifically proven to boost your metabolism so that you burn calories and fat quicker.
                    </p>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-2 d-flex px-1">
                <div class="px-5 box panel-medium">
                    <h1>2.</h1>
                    <p>
                        We combined these with BHB (Beta‐Hydroxybutyrate): This is a unique ingredient, that immediately puts your body into Ketosis, removing all of your excess weight.
                    </p>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-2 d-flex px-1">
                <div class="px-5 box panel-dark">
                    <h1>3.</h1>
                    <p>
                        Ketosis is a state that your body enters to uses excess fat for energy instead of carbohydrates. This results in rapid removal of excess weight, and also increases energy, reduced hunger and appetite, better mental focus. while still eating your favorite foods.
                    </p>
                </div>
            </div>
            <div class="col-12 col-md-6 mb-2 d-flex px-1">
                <div class="px-5 box panel-light">
                    <h1>4.</h1>
                    <p>
                        Our unique formula, that is made in the USA, puts your body into Ketosis quickly and easily.
                    </p>
                </div>
            </div>
        </div>
    </div>
    <section id="panel-customer-reviews" class="panel-section py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col">
                    <article>
                        <header class="ps-header text-black">
                            <h1 class="ps-header-title">See what some<br>of our customers are saying</h1>
                            <hr class="ps-header-title-line border-black ml-0">
                        </header>

                        <div class="ps-body text-black">
                            <div class="row">
                                <div class="col-12 col-sm-6 col-lg-3">
                                    <blockquote class="blockquote ps-review">
                                        <p class="mb-2">
                                            I gained so much weight the last few years and was at a point in my life that I realized something had to be done. Tried so many different diets and finally found KetoWeightLoss. It changed my life for the better&excl;
                                        </p>
                                        <footer class="blockquote-footer">
                                            Leslie L.
                                            <span class="text-nowrap">
													&nbsp;
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													&nbsp;
												</span>
                                            <br class="d-none d-lg-block">
                                            <cite class="text-bright-green font-weight-bold text-nowrap">Verified Buyer</cite>
                                            <br><small>&lpar;Results may vary from person to person.&rpar;</small>
                                        </footer>
                                    </blockquote>
                                </div>
                                <div class="col-12 col-sm-6 col-lg-3">
                                    <blockquote class="blockquote ps-review">
                                        <p class="mb-2">
                                            If you’re looking to lose weight fast and have more energy to do all the things you love to do, I highly recommend Keto Weight Loss! It’s good for you and for your overall well being. You must try this product right away&excl;
                                        </p>
                                        <footer class="blockquote-footer">
                                            Christine W.
                                            <span class="text-nowrap">
													&nbsp;
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													&nbsp;
												</span>
                                            <br class="d-none d-lg-block">
                                            <cite class="text-bright-green font-weight-bold text-nowrap">Verified Buyer</cite>
                                            <br><small>&lpar;Results may vary from person to person.&rpar;</small>
                                        </footer>
                                    </blockquote>
                                </div>
                                <div class="col-12 col-sm-6 col-lg-3">
                                    <blockquote class="blockquote ps-review">
                                        <p class="mb-2">
                                            Keto Weight Loss is a life saver! It’s giving me so much energy to work and live my life to the fullest! I’m able to do all the things I want to do, instead of coming up with excuses. I can eat whatever I want when I want&excl;
                                        </p>
                                        <footer class="blockquote-footer">
                                            Sonny P.
                                            <span class="text-nowrap">
													&nbsp;
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													&nbsp;
												</span>
                                            <br class="d-none d-lg-block">
                                            <cite class="text-bright-green font-weight-bold text-nowrap">Verified Buyer</cite>
                                            <br><small>&lpar;Results may vary from person to person.&rpar;</small>
                                        </footer>
                                    </blockquote>
                                </div>
                                <div class="col-12 col-sm-6 col-lg-3">
                                    <blockquote class="blockquote ps-review">
                                        <p class="mb-2">
                                            Keto Weight Loss thought me to love myself again! I used to be self conscious about my weight, wouldn’t look at myself in the mirror. But after trying out Keto Weight Loss, I started losing weight fast! I started looking and feel better&excl;
                                        </p>
                                        <footer class="blockquote-footer">
                                            Lianne T.
                                            <span class="text-nowrap">
													&nbsp;
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													<i class="fas fa-star"></i>
													&nbsp;
												</span>
                                            <br class="d-none d-lg-block">
                                            <cite class="text-bright-green font-weight-bold text-nowrap">Verified Buyer</cite>
                                            <br><small>&lpar;Results may vary from person to person.&rpar;</small>
                                        </footer>
                                    </blockquote>
                                </div>
                            </div>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section style="display:none;">
        <div class="container pb-3">
            <div class="row">
                <div class="col-4 px-0">
                    <img src="/static/front/image/img1.jpg" class="img-fluid w-100"/>
                </div>
                <div class="col-4 px-0">
                    <img src="/static/front/image/img2.jpg" class="img-fluid w-100"/>
                </div>
                <div class="col-4 px-0">
                    <img src="/static/front/image/img3.jpg" class="img-fluid w-100"/>
                </div>
            </div>
            <div class="row">
                <div class="col-4 px-0">
                    <img src="/static/front/image/img4.jpg" class="img-fluid w-100"/>
                </div>
                <div class="col-4 px-0">
                    <img src="/static/front/image/img5.jpg" class="img-fluid w-100"/>
                </div>
                <div class="col-4 px-0">
                    <img src="/static/front/image/img6.jpg" class="img-fluid w-100"/>
                </div>
            </div>
        </div>
    </section>
    <section class="vitangel-bg">
        <img src="/static/front/image/vita_angels.jpg" class="img-fluid d-block d-sm-none" alt="vita-angel-kid">
        <div class="container">
            <div class="row vitangel">
                <div class="col-12 col-md-6">
                    <h2 class="mt-5" >Proud Supporter of</h2>
                    <img src="/static/front/image/vita-angel.png" class="img-fluid" alt="vita-angel">
                    <p class="mt-md-4">
                        With your purchase, we provide a child in need with a 6 month dose of essential vitamins. Every purchase you make provides a 1-for-1 Vitamin Grant through our partnership with Vitamin Angels.
                    </p>
                </div>
            </div>
        </div>
    </section>

    <section id="panel-dont-miss" class="py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col">
                    <article>
                        <div class="ps-body text-center px-sm-3 px-2">
                            <h2 class="my-4">Don’t miss this opportunity to conquer your weight loss goals and achieve your absolute best version of you!</h2>
                            <h2>We’ve got some essentials you’ll need to make that possible…Using this effective fitness system to gear up your healthy lifestyle is as easy as 1, 2, 3…</h2>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section id="panel-what-is-bhb">
        <div class="container container-patch">
            <div class="row">
                <div class="text-left col-12 col-lg-6">
                    <article>
                        <div class="ps-header-holder py-2 px-sm-3 px-2">
                            <div class="row align-items-left">
                                <div class="col">
                                    <header class="ps-header">
                                        <h2 class="ps-header-title">What is BHB&quest;</h2>
                                    </header>
                                </div>
                            </div>
                        </div>
                        <div class="ps-body px-sm-3 px-2">
                            <p>
                                Understanding BHB is essential to joining the ketogenetic diet and remaining in ketosis. So what is BHB exactly? BHB (Beta‐Hydroxybutyrate) is an organic compound and is considered one of the “physiological” ketone bodes produced and burned in our cells.
                            </p>
                            <p>
                                The best way to increase production of endogenous BHB is to reach a state of nutritional ketosis by reducing carbohydrate intake or fasting.
                            </p>
                            <p>
                                Endogenous ketones are produced by the body naturally through a low-carb diet or fasting. The process for creating endogenous BHB is called ketogenesis.
                            </p>
                            <p>
                                To provide a quicker alternative to natural ketone production, there are exogenous BHB ketones which can be consumed through supplements. Exogenous ketones come from an external source since they’re not produced in the body.
                            </p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section id="panel-bg-be-happy" class="panel-section-bg-image container-fluid"></section>
    <section id="panel-where-to-start" class="py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col-12">
                    <div class="ps-header-holder">
                        <div class="row align-items-center text-center">
                            <div class="col">
                                <header class="ps-header text-black text-center">
                                    <h2 class="ps-header-title">Where to Start&excl;</h2>
                                    <hr class="ps-header-title-line">
                                </header>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-12 col-lg-6">
                    <article>
                        <div class="col text-center">
                            <img class="ps-image img-fluid d-lg-none" src="/static/front/image/shop.png" alt="Keto bottle">
                        </div>
                        <div class="ps-body text-black px-4">
                            <p class="text-bold">
                                Following a Ketogenic diet, supplemented with our BHB supplement is the best way to start getting your body in ketosis and start feeling the effects of being Keto Friendly&excl;
                            </p>
                            <ul>
                                <li>Reducing feelings of hunger</li>
                                <li>Improving mental performance</li>
                                <li>Increasing physical performance</li>
                                <li>Longer lasting energy</li>
                                <li>Decreasing the amount of time it takes for your body to enter ketosis</li>
                                <li>Helping reduce the &ldquo;low-carb flu&rdquo; symptoms</li>
                            </ul><br>
                            <a href="/front/User/index" class="order-btn nav-btn_color font-weight-bold px-4 my-0 py-2" role="button">SHOP NOW</a>
                        </div>
                    </article>

                </div>
                <div class="col-12 col-lg-4 offset-lg-2 d-none d-lg-block text-center align-self-center">
                    <img class="ps-image img-fluid" src="/static/front/image/shop.png" alt="Keto bottle" style="max-height:350px;">
                </div>
            </div>
        </div>
    </section>
    <section id="panel-quality-guarantee" class="py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col-12 col-lg-6">
                    <article>
                        <div class="ps-header-holder">
                            <div class="row align-items-center">
                                <header class="ps-header">
                                    <h2 class="ps-header-title text-white  px-4">Quality Guarantee</h2>
                                </header>
                            </div>
                        </div>

                        <div class="ps-body text-white px-4">
                            <p>
                                All KETO products are manufactured and packaged in the USA and undergo rigorous quality assurance procedures to ensure the highest quality. We are committed to providing state&dash;of&dash;the&dash;art nutraceuticals to support your optimal health and well&dash;being.
                            </p>
                            <p>
                                All supplements are: &lpar;1&rpar; Produced in a FDA&dash;Registered, BMP and CSI&dash;Certified facility. &lpar;2&rpar; Free of fillers, binders and artificial ingredients. &lpar;3&rpar; Made of natural and pure botanicals and premium&dash;grade ingredients.
                            </p>
                        </div>
                    </article>
                </div>

                <div class="col-12 col-lg-6 text-center align-self-center">
                    <img class="ps-image img-fluid" src="/static/front/image/quality_icons.png" alt="Quality icons">
                </div>

            </div>
        </div>
    </section>
    <section id="panel-money-back-guarantee" class="py-4 py-md-5">
        <div class="container container-patch">
            <div class="row">
                <div class="col">
                    <article>
                        <div class="ps-header-holder">
                            <div class="row align-items-start">
                                <div class="col-12 text-center">
                                    <img class="ps-image img-fluid" src="/static/front/image/money_back_guarantee.svg" alt="Money back guarantee" style="max-width: 120px">
                                </div>
                                <div class="col-12 text-center">
                                    <header class="ps-header text-black">
                                        <h2 class="ps-header-title">90 Day Money Back Guarantee</h2>
                                        <hr class="ps-header-title-line">
                                    </header>
                                </div>

                            </div>
                        </div>

                        <div class="ps-body text-black px-4">
                            <p>
                                Through years of tedious work in trying to find weight loss in an all natural supplement, we finally accomplished this dream by creating KETO. Our nutritionist&rsquo;s field and weight loss group managed to develop a product that we&rsquo;re proud to offer.
                            </p>
                            <p>
                                We keep this integrity alive by offering a 90&dash;day money back guarantee if for any reason you are not completely satisfied.
                            </p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <section id="panel-about-us" class="pt-5 px-0">
        <div class="container container-patch">
            <div class="row">
                <div class="text-left col-12 col-lg-6 text-white">
                    <article>
                        <div class="ps-header-holder py-2 px-sm-3 px-2">
                            <header class="ps-header">
                                <h2 class="ps-header-title">About us</h2>
                            </header>
                        </div>
                        <div class="ps-body px-sm-3 px-2">
                            <p>We are Keto.</p>
                            <p>
                                It’s as Simple as that! We wanted to find a simple solution to help reach Ketosis and we found a simple way to do so! Whatever your lifestyle may be, KETO can easily be a part of it.
                            </p>
                            <p>
                                We believe in healthy living, including a balanced diet and an active lifestyle. Whether your new to the Ketogenic diet or not, our team is here to help you reach your goals!
                            </p>
                            <p><b>Questions? Comments?</b></p>
                            <p>We love to hear from you!</p>
                            <p>
                                If you need to contact us with questions, feedback, testimonial or a suggestion, please send an email to <a href="mailto: care@ketoweightloss.com" class="text-white">care@ketoweightloss.com</a>. You can also reach us by Toll-Free Keto Weightloss <a href="tel:8553328007" class="text-white">855-332-8007</a>.
                            </p>
                        </div>
                    </article>
                </div>
            </div>
        </div>
    </section>
    <footer>
        <div class="container pt-5">
            <div class="row">
                <div class="col-12 col-sm-3 d-none d-sm-block">
                    <img src="/static/front/image/logo_square.png" alt="" width="100%"
                         style="margin-top:-30px;">
                </div>
                <div class="col-12 col-sm-3 d-block d-sm-none">
                    <img src="/static/front/image/logo_horizontal.png" alt="" width="100%"
                         style="margin-top:-30px;">
                </div>
                <div class="col-12 col-sm-2 pt-3 pt-sm-0 nav-b text-md-center text-center
					d-none d-md-block">
                    <h3 class="mb-0" style="font-size:18px;">Main Menu</h3>
                    <a href="#panel-how-keto-works" style="text-decoration: none;
						color:black;font-size:14px;">How it works</a> <br>
                    <a href="#panel-customer-reviews" style="text-decoration: none;
						color:black; font-size:14px;">Reviews</a> <br>
                    <a href="#panel-what-is-bhb" style="text-decoration: none; color:black;
						font-size:14px;">Ingredients</a> <br>
                    <a href="#panel-about-us" style="text-decoration: none; color:black;
						font-size:14px;">About us</a> <br>
                    <a href="/front/User/index" style="text-decoration: none; color:black;
						font-size:14px;">Buy Now</a> <br>
                    <span class="text-nowrap">
						<button type="button" class="btn btn-link p-0 border-0"
                                data-toggle="modal" data-target="#terms-privacy-modal"
                                data-modal-source="/front/user/terms #page-content" data-modal-title="Terms
								 and Conditions" style="text-decoration: none; color:black;
								 font-size:14px;">Terms and Conditions </button>
                        <button class="btn btn-link p-0 border-0" style="text-decoration:none;color:black;
								 cursor:default;"></button><br>
                        <button type="button" class="btn btn-link p-0 border-0" data-toggle="modal"
                                data-target="#terms-privacy-modal" data-modal-source="/privacy/ #page-content"
                                data-modal-title="Privacy" style="text-decoration: none; color:black;
                                font-size:14px;">Privacy Policy</button></span>
                </div>
                <div class="col-12 col-sm-4 pt-2 pt-sm-0 nav-b">
                    <h3 class="mb-0" style="font-size:18px;">Reach Us</h3>
                    <table class="footer-phone-table table table-borderless table-sm  mb-0"
                           style="font-size:14px;">
                        <tbody>
                        <tr>
                            <td class="text-left">United States / Canada</td>
                            <td><a class="text-reset" href="tel:18553328007">+18553328007</a></td>
                        </tr>
                        <tr>
                            <td class="text-left">Germany</td>
                            <td><a class="text-reset" href="tel:498007233956">+498007233956</a></td>
                        </tr>
                        <tr>
                            <td class="text-left">New Zealand</td>
                            <td><a class="text-reset" href="tel:64800423752">+64800423752</a></td>
                        </tr>
                        <tr>
                            <td class="text-left">United Kingdom</td>
                            <td><a class="text-reset" href="tel:448000318088">+448000318088</a></td>
                        </tr>
                        <tr>
                            <td class="text-left">Australia</td>
                            <td><a class="text-reset" href="tel:611800958312">+611800958312</a></td>
                        </tr>
                        <tr>
                            <td class="text-left">Ireland</td>
                            <td><a class="text-reset" href="tel:3531800903419">+3531800903419</a></td>
                        </tr>
                        </tbody>
                    </table>
                </div>
                <div class="col-12 col-sm-3 nav-b pt-2 pt-sm-0">
                    <h3 class="mb-0" style="font-size:18px;">Our Offices</h3>
                    <span style="font-size:14px;">
							<b>USA:</b>
							325 N. St. Paul Street, Dallas, Texas 75201, USA<br>
						</span>
                </div>
            </div>
        </div>
    </footer>
</main>
<div id="terms-privacy-modal" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="terms-privacy-modal-title" aria-hidden="true">
    <div class="modal-dialog modal-xl modal-dialog-scrollable" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 id="terms-privacy-modal-title" class="modal-title">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body"></div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script src="/static/front/js/jquery-3.3.1.min.js"></script>
<script src="/static/front/js/popper-1.14.7.min.js"></script>
<script src="/static/front/js/bootstrap-4.3.0.min.js"></script>
<script src="/static/front/js/smooth-scroll.js"></script>
<script type="text/javascript">
    initializeSmoothScroll('.anchor-link', function(){
        $('#page-nav-mobile-toggler[aria-expanded="true"]').click();
    });
    $('#terms-privacy-modal').on('show.bs.modal', function (event) {
        var button = $(event.relatedTarget);
        $(this).find('.modal-body').load(button.data('modal-source'));
        $('#terms-privacy-modal-title').text(button.data('modal-title'));
    });
    (function () {
        let scroll_offset = $('#page-nav').outerHeight();
        $('body').attr('data-offset', scroll_offset+1);
        $('.anchor-link').attr('data-offset-top', scroll_offset);
    })();
    $(window).scroll(function() {
        if ($(this).scrollTop()>200) {
            $('#free_shipping').hide().removeClass('d-flex');
            $('#order_now').show().addClass('d-flex');
        } else {
            $('#order_now').hide().removeClass('d-flex');
            $('#free_shipping').show().addClass('d-flex');
        }
    });
</script>
</body>
</html>