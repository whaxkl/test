<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:59:"E:\ketox\public/../application/front\view\user\privacy.html";i:1569815401;}*/ ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
    <title>Keto Weight Loss</title>

    <!-- Analytics -->
    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=UA-134138007-3"></script>
    <script type="text/javascript">
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-134138007-3', {
            'linker': {
                'domains': ['learnketo.com', 'ketojourney.com']
            }
        });
    </script>

    <!-- Global site tag (gtag.js) - Google Ads: 755611757 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-755611757"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'AW-755611757');
    </script>

    <!-- Global site tag (gtag.js) - Google Ads: 748591489 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-748591489"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'AW-748591489');
    </script>

    <!-- Global site tag (gtag.js) - Google Ads: 732077409 -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=AW-732077409"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'AW-732077409');
    </script>

    <!-- Bing -->
    <script>
        (function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"12001843"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");
    </script>
    <!-- Meta Tags -->
    <meta name="language" content="English">
    <meta name="copyright" content="Keto Weight Loss">
    <meta name="description" content="Rated #1 Keto Supplement Worldwide. 90-Day Money Back Guarantee On All Purchases.">

    <!-- Open Graph -->
    <meta name="og:type" content="website">
    <meta name="og:description" content="Rated #1 Keto Supplement Worldwide. 90-Day Money Back Guarantee On All Purchases.">
    <meta name="og:image" content="https://d3ok9e5g4qczz5.cloudfront.net/assets/img/ketoweightloss_banner.jpg">
    <meta name="og:site_name" content="Keto Weight Loss">
    <meta name="og:locale" content="en_US">

    <!-- Favicons -->
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/favicon/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/favicon/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/favicon/favicon-16x16.png">
    <link rel="manifest" href="/assets/favicon/site.webmanifest">
    <link rel="shortcut icon" href="/assets/favicon/favicon.ico">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-config" content="/assets/favicon/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">

    <!-- Plugins -->
    <link rel="stylesheet" href="https://d3ok9e5g4qczz5.cloudfront.net/assets/css/bootstrap-4.3.0.min.css">
    <link rel="stylesheet" href="/assets/css/fontawesome-all-5.7.1.min.css">

    <!-- Custom Styles -->
    <link rel="stylesheet" href="https://d3ok9e5g4qczz5.cloudfront.net/assets/css/defaults.css">
    <link rel="stylesheet" href="https://d3ok9e5g4qczz5.cloudfront.net/assets/css/global.css">	<link rel="stylesheet" href="https://d3ok9e5g4qczz5.cloudfront.net/assets/css/page/privacy.css">
</head>
<body >

<div id="page-content" class="container">
    <div class="row">
        <div class="col">
            <article>
                <div class="body field">
                    <h2>
                        Web Site Terms and Conditions of Use</h2>
                    <h3>
                        1. Terms</h3>
                    <p>By accessing this web site, you are agreeing to be bound by these web site Terms and Conditions of Use, applicable laws and regulations and their compliance. If you disagree with any of the stated terms and conditions, you are prohibited from using or accessing this site. The materials contained in this site are secured by relevant copyright and trade mark law.</p>
                    <h3>
                        2. Use License</h3>
                    <ol type="a">
                        <li>
                            Permission is allowed to temporarily download one duplicate of the materials (data or programming) on KWL Wellness Inc&rsquo;s site for individual and non-business use only. This is the just a permit of license and not an exchange of title, and under this permit you may not:<p></p>
                            <ol type="i">
                                <li>modify or copy the materials;</li>
                                <li>use the materials for any commercial use , or for any public presentation (business or non-business);</li>
                                <li>attempt to decompile or rebuild any product or material contained on KWL Wellness Inc&rsquo;s site;</li>
                                <li>remove any copyright or other restrictive documentations from the materials; or</li>
                                <li>transfer the materials to someone else or even “mirror” the materials on other server.</li>
                            </ol>
                        </li>
                        <li>
                            This permit might consequently be terminated if you disregard any of these confinements and may be ended by Keto Weight Loss whenever deemed. After permit termination or when your viewing permit is terminated, you must destroy any downloaded materials in your ownership whether in electronic or printed form.</li>
                    </ol>
                    <h3>
                        3. Disclaimer</h3>
                    <ol type="a">
                        <li>
                            The materials on KWL Wellness Inc&rsquo;s site are given “as is”. Keto Weight Loss makes no guarantees, communicated or suggested, and thus renounces and nullifies every single other warranties, including without impediment, inferred guarantees or states of merchantability, fitness for a specific reason, or non-encroachment of licensed property or other infringement of rights. Further, Keto Weight Loss does not warrant or make any representations concerning the precision, likely results, or unwavering quality of the utilization of the materials on its Internet site or generally identifying with such materials or on any destinations connected to this website.</li>
                    </ol>
                    <h3>
                        4. Constraints</h3>
                    <p>In no occasion should Keto Weight Loss or its suppliers subject for any harms (counting, without constraint, harms for loss of information or benefit, or because of business interference,) emerging out of the utilization or powerlessness to utilize the materials on KWL Wellness Inc&rsquo;s Internet webpage, regardless of the possibility that Keto Weight Loss or a Keto Weight Loss approved agent has been told orally or in written of the likelihood of such harm. Since a few purviews don’t permit constraints on inferred guarantees, or impediments of obligation for weighty or coincidental harms, these confinements may not make a difference to you.</p>
                    <h3>
                        5. Amendments and Errata</h3>
                    <p>The materials showing up on KWL Wellness Inc&rsquo;s site could incorporate typographical, or photographic mistakes. Keto Weight Loss does not warrant that any of the materials on its site are exact, finished, or current. Keto Weight Loss may roll out improvements to the materials contained on its site whenever without notification. Keto Weight Loss does not, then again, make any dedication to update the materials.</p>
                    <h3>
                        6. Links</h3>
                    <p>Keto Weight Loss has not checked on the majority of the websites or links connected to its website and is not in charge of the substance of any such connected webpage. The incorporation of any connection does not infer support by Keto Weight Loss of the site. Utilization of any such connected site is at the user’s own risk.</p>
                    <h3>
                        7. Site Terms of Use Modifications</h3>
                    <p>Keto Weight Loss may update these terms of utilization for its website whenever without notification. By utilizing this site you are consenting to be bound by the then current form of these Terms and Conditions of Use.</p>
                    <h3>
                        8. Governing Law</h3>
                    <p>Any case identifying with KWL Wellness Inc&rsquo;s site should be administered by the laws of the country of Weight Loss Keto Weight Loss State without respect to its contention of law provisions.</p>
                    <p>General Terms and Conditions applicable to Use of a Web Site.</p>
                    <h2>
                        Privacy Policy</h2>
                    <p>Your privacy is critical to us. Likewise, we have built up this Policy with the end goal you should see how we gather, utilize, impart and reveal and make utilization of individual data. The following blueprints our privacy policy.</p>
                    <ul>
                        <li>
                            Before or at the time of collecting personal information, we will identify the purposes for which information is being collected.</li>
                        <li>
                            We will gather and utilization of individual data singularly with the target of satisfying those reasons indicated by us and for other good purposes, unless we get the assent of the individual concerned or as required by law.</li>
                        <li>
                            We will just hold individual data the length of essential for the satisfaction of those reasons.</li>
                        <li>
                            We will gather individual data by legal and reasonable means and, where fitting, with the information or assent of the individual concerned.</li>
                        <li>
                            Personal information ought to be important to the reasons for which it is to be utilized, and, to the degree essential for those reasons, ought to be exact, finished, and updated.</li>
                        <li>
                            We will protect individual data by security shields against misfortune or burglary, and also unapproved access, divulgence, duplicating, use or alteration.</li>
                        <li>
                            We will promptly provide customers with access to our policies and procedures for the administration of individual data.</li>
                    </ul>
                    <p>We are focused on leading our business as per these standards with a specific end goal to guarantee that the privacy of individual data is secure and maintained.</p>
                </div>
            </article>
        </div>
    </div>
</div>
</body>
</html>