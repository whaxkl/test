﻿
// js语言包

var lang = new Array;
lang['ok'] = 'determine';
lang['ts'] = 'prompt';
lang['ip'] = 'IP information';
lang['esc'] = 'cancel';
lang['add'] = 'add';
lang['edit'] = 'Modify the';
lang['code'] = 'code';
lang['show'] = 'To view';
lang['send'] = 'push';
lang['save'] = 'save';
lang['copy'] = 'copy';
lang['error'] = 'System error';
lang['error_admin'] = 'System crashed, please check the error log';
lang['member'] = 'The user information';
lang['paylog'] = 'Transaction records';
lang['todoing'] = 'The execution result';
lang['logout'] = 'Are you sure you want to quit?';
lang['htmlfile'] = 'Generate static pages';
lang['protocol'] = 'User registration agreement';
lang['unloadtips'] = 'The data is not saved. Are you sure you want to leave?';


// 日期类型语言包
var finecms_datepicker_lang = {
    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    daysShort: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    daysMin:  ["Day", "one", "two", "three", "four", "five", "six", "day"],
    months: ["Month", "February", "march", "April", "may", "June", "July", "August", "September", "October", "November", "December"],
    monthsShort: ["Month", "February", "march", "April", "may", "June", "July", "August", "September", "October", "November", "December"],
    today: "Today",
    clear: "clear",
    titleFormat: "MM yyyy"
};

var finecms_datetimepicker_lang = {
    days: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    daysShort: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"],
    daysMin:  ["Day", "one", "two", "three", "four", "five", "six", "day"],
    months: ["Month", "February", "march", "April", "may", "June", "July", "August", "September", "October", "November", "December"],
    monthsShort: ["Month", "February", "march", "April", "may", "June", "July", "August", "September", "October", "November", "December"],
    today: "Today",
    suffix: [],
    meridiem: []
};

