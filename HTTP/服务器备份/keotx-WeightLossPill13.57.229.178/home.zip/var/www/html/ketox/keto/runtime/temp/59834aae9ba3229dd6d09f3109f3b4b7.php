<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:57:"E:\ketox\public/../application/front\view\user\terms.html";i:1569823846;}*/ ?>
<body>
<div id="page-content" class="container">
    <div class="row">
        <div class="col">
            <article>
                <div class="body field">
                    <h2>Terms and Conditions</h2>
                    <p>&nbsp;</p>
                    <p>By ordering any of our products, you agree to be bound by these terms &amp; conditions.</p>
                    <p>By placing an order at KWL Wellness Inc, you warrant that you are at least 18 years old or have parents&rsquo; permission to purchase from us.</p>
                    <p>All personal information you provide us with or that we obtain will be handled by KWL Wellness Inc as responsible for the personal information.</p>
                    <p>Events outside KWL Wellness Inc&rsquo;s control shall be considered force majeure.</p>
                    <p>The price applicable is that set at the date on which you place your order.</p>
                    <p>All pricing stated is inclusive of shipping costs.</p>
                    <p>Card information is transmitted over secure SSL encryption and is not stored.</p>
                    <p>&nbsp;</p>

                    <h3>Terms &amp; Conditions</h3>
                    <p>&nbsp;</p>
                    <p>This page contains the terms &amp; conditions. Please read these terms &amp; conditions carefully before ordering any products from us. You should understand that by ordering any of our products, you agree to be bound by these terms &amp; conditions.</p>
                    <p>&nbsp;</p>
                    <p>By placing an order at KWL Wellness Inc, you warrant that you are at least 18 years old (or have parents&rsquo; permission to purchase from us) and accept these terms &amp; conditions which shall apply to all orders placed or to be placed at KWL Wellness Inc for the sale and supply of any products. None of these terms &amp; conditions affect your statutory rights. No other terms or changes to the terms &amp; conditions shall be binding unless agreed in writing signed by us.</p>
                    <p>&nbsp;</p>
                    <p>All personal information you provide us with or that we obtain will be handled by KWL Wellness Inc as responsible for the personal information. The personal information you provide will be used to ensure deliveries to you, the credit assessment, to provide offers and information on our catalog to you. The information you provide is only available to KWL Wellness Inc and will not be shared with other third parties. You have the right to inspect the information held about you. You always have the right to request KWL Wellness Inc to delete or correct the information held about you. By accepting the KWL Wellness Inc Conditions, you agree to the above.</p>
                    <p>&nbsp;</p>

                    <h3>Force Majeure</h3>
                    <p>&nbsp;</p>
                    <p>Events outside KWL Wellness Inc&rsquo;s control, which is not reasonably foreseeable, shall be considered force majeure, meaning that KWL Wellness Inc is released from KWL Wellness Inc&rsquo;s obligations to fulfill contractual agreements. Example of such events are government action or omission, new or amended legislation, conflict, embargo, fire or flood, sabotage, accident, war, natural disasters, strikes or lack of delivery from suppliers. The force majeure also includes government decisions that affect the market negatively and products, for example, restrictions, warnings, ban, etc.</p>
                    <p>&nbsp;</p>

                    <h3>Payment</h3>
                    <p>&nbsp;</p>
                    <p>All products remain KWL Wellness Inc&rsquo;s property until full payment is made. The price applicable is that set at the date on which you place your order. Shipping costs and payment fees are recognized before confirming the purchase. If you are under 18 years old you must have parents&rsquo; permission to buy from KWL Wellness Inc.</p>
                    <p>&nbsp;</p>
                    <p>All transfers conducted through KWL Wellness Inc are handled and transacted through third party dedicated gateways to guarantee your protection. Card information is not stored and all card information is handled over SSL encryption. Please read the terms &amp; conditions for the payment gateway chosen for the transaction as they are responsible for the transactions made.</p>
                    <p>&nbsp;</p>

                    <h3>LOCAL TAXES</h3>
                    <p>&nbsp;</p>
                    <p>Please note that local charges (sales tax, customs duty) are included in displayed pricing.</p>
                    <p>&nbsp;</p>
                    <h3>Cookies</h3>
                    <p>&nbsp;</p>
                    <p>KWL Wellness Inc uses cookies according to the new Electronic Communications Act, which came into force on 25 July 2003. A cookie is a small text file stored on your computer that contains information that helps the website to identify and track the visitor. Cookies do no harm to your computer, consist only of text, can not contain viruses and occupies virtually no space on your hard drive. There are two types of cookies: &ldquo;Session Cookies&rdquo; and cookies that are saved permanently on your computer.</p>
                    <p>&nbsp;</p>
                    <p>The first type of cookie commonly used is &ldquo;Session Cookies&rdquo;. During the time you visit the website, our web server assigns your browser a unique identifier string so as not to confuse you with other visitors. A &ldquo;Session Cookie&rdquo; is never stored permanently on your computer and disappears when you close your browser. To use KWL Wellness Inc without troubles you need to have cookies enabled.</p>
                    <p>&nbsp;</p>
                    <p>The second type of cookie saves a file permanently on your computer. This type of cookie is used to track how visitors move around on the website. This is only used to offer visitors better services and support. The text files can be deleted. On KWL Wellness Inc we use this type of cookie to keep track of your shopping cart and to keep statistics of our visitors. The information stored on your computer is only a unique number, without any connection to personal information.</p>
                    <p>&nbsp;</p>
                    <h3>Additional Information</h3>
                    <p>&nbsp;</p>
                    <p>KWL Wellness Inc reserves the right to amend any information, including but not limited to prices, technical specifications, terms of purchase and product offerings without prior notice. At the event of when a product is sold out, KWL Wellness Inc has the right to cancel the order and refund any amount paid in the best way. KWL Wellness Inc shall also notify the customer of equivalent replacement products if available.</p>
                    <p>&nbsp;</p>
                    <p>All inquiries: <a href="mailto:care@ketoweightloss.com" target="_blank">care@ketoweightloss.com</a></p>
                    <p>&nbsp;</p>
                    <h3>RETURN POLICY</h3>
                    <p>&nbsp;</p>
                    <p>You are entitled to a full refund within 90 days of your purchase, as outlined in our 90-Day Money Back Guarantee. Please note that the product must be returned either used or unused bottles.</p>
                    <p>&nbsp;</p>
                    <h3>ARBITRATION &amp; CLASS ACTION WAIVER</h3>
                    <p>&nbsp;</p>
                    <p>EXCEPT WHERE PROHIBITED BY LAW, YOU AGREE THAT ANY CLAIM THAT YOU MAY HAVE AGAINST KWL Wellness Inc, OR ITS PARENTS, SUBSIDIARIES, AFFILIATES, OWNERS, EMPLOYEES, AND/OR REPRESENTATIVES, MAY ONLY BE PURSUED AND BROUGHT IN FINAL AND BINDING CONFIDENTIAL ARBITRATION. YOU ACKNOWLEDGE AND AGREE THAT YOU ARE WAIVING THE RIGHT TO A TRIAL BY JURY. YOU AGREE THAT YOU MAY ONLY BRING A CLAIM IN YOUR INDIVIDUAL CAPACITY AND NOT AS A PLAINTIFF (LEAD OR OTHERWISE) OR CLASS MEMBER IN ANY PURPORTED CLASS OR REPRESENTATIVE PROCEEDING. YOU FURTHER AGREE THAT THE ARBITRATOR MAY NOT CONSOLIDATE PROCEEDINGS OR CLAIMS OR OTHERWISE PRESIDE OVER ANY FORM OF A REPRESENTATIVE OR CLASS PROCEEDING.</p>
                    <p>&nbsp;</p>
                    <p>This arbitration provision sets forth the terms and conditions of our agreement to final and binding confidential arbitration and is governed by and enforceable under the Federal Arbitration Act (the &ldquo;FAA&rdquo;), 9 U.S.C. &sect;&sect; 1-16, as amended. In the event you elect to proceed with binding arbitration, you shall provide written notice to KWL Wellness Inc by registered or certified mail and shall describe in such notice, with reasonable particularity, the nature and basis of such claim and the total amount of the claim. The written notice shall be sent to: 1128 Gunter Street, Unit G Austin, TX 78702. If the parties are unable to resolve the dispute arising from the claim by good faith negotiations within the thirty (30)-day period following receipt of the written notice, either party may initiate binding arbitration pursuant to the terms and conditions set forth herein.</p>
                    <p>&nbsp;</p>
                    <p>The arbitration will be governed by the Commercial Dispute Resolution Procedures and the Supplementary Procedures for Consumer Related Disputes (collectively, &ldquo;AAA Rules&rdquo;) of the American Arbitration Association (&ldquo;AAA&rdquo;) and will be administered by the AAA. If the AAA is unavailable or refuses to arbitrate the parties&rsquo; dispute for any reason, the arbitration shall be administered and conducted by a widely-recognized arbitration organization that is mutually agreeable to the parties, but neither party shall unreasonably withhold their consent. The AAA Rules are available online at www.adr.org. Unless otherwise agreed, the arbitration shall take place in the capital city of the state in which the consumer resides, but may proceed telephonically in the event the total amount of the claim does not exceed $2,500 U.S. dollars (if the claimant so chooses).</p>
                    <p>&nbsp;</p>
                    <p>Separate and apart from the agreement to arbitrate set forth above and to the extent permitted by law, you hereby independently (i) waive any right to bring or participate in any class action against KWL Wellness Inc and (ii) acknowledge that this class action waiver is material and essential to the arbitration of any disputes between the parties and non-severable from the agreement to arbitrate claims.</p>
                    <p>&nbsp;</p>
                    <h3>MINIMUM ADVERTISED PRICE</h3>
                    <p>&nbsp;</p>
                    <p>Minimum advertised prices are established by KWL Wellness Inc to keep the brand strong and not to dilute the brand.</p>
                    <p>&nbsp;</p>
                    <p>Minimum advertised price must be no less than the current listed price on www.KWL Wellness Inc.com for any products to be sold in third party websites.</p>
                    <p>The minimum advertised price for KWL Wellness Inc Base is $54.95 USD.</p>
                    <p>There is no limit to a maximum advertised price.</p>
                    <p>MAP pricing is set by KWL Wellness Inc and subject to change without notice.</p>
                    <p>The MAP policy applies to all advertisements of NPI products in any and all media, including, but not limited to, flyers, posters, coupons, mailers, inserts, newspapers, magazines, catalogs, mail order catalogs, email news letters, email solicitations, Internet or similar electronic media, television, radio, and public signage.</p>
                    <p>The MAP policy is not applicable to any in-store advertising that is displayed only in the store and not distributed to any customer(s).</p>
                    <p>MAP applies only to advertised prices and does not apply to the price at which the products are actually sold or offered for sale to an individual consumer within the dealer&rsquo;s retail location or over the telephone. KWL Wellness Inc dealers and sales representatives remain free to sell these products at any prices they choose.</p>
                </div>
            </article>
        </div>
    </div>
</div>
</body>