<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:57:"E:\ketox\public/../application/front\view\user\index.html";i:1569834979;}*/ ?>
<!DOCTYPE html>
<html lang="en"><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no, user-scalable=no">
    <title>Keto Weight Loss</title>
    <script type="text/javascript" async="" src="/static/front/js/ec.js">
    </script><script type="text/javascript" async="" src="/static/front/txt/f.txt">
    </script><script type="text/javascript" async="" src="/static/front/js/analytics.js">
    </script><script src="/static/front/js/bat.js" async=""></script>
    <script type="text/javascript">
        window.dataLayer = window.dataLayer || [];
        function gtag(){dataLayer.push(arguments);}
        gtag('js', new Date());
        gtag('config', 'UA-134138007-3', {
            'linker': {
                'domains': ['learnketo.com', 'ketojourney.com']
            }
        });
    </script>
    <meta name="language" content="English" id="ddd">
    <meta name="copyright" content="Keto Weight Loss">
    <meta name="description" content="Rated #1 Keto Supplement Worldwide. 90-Day Money Back Guarantee On All Purchases.">
    <meta name="og:type" content="website">
    <meta name="og:description" content="Rated #1 Keto Supplement Worldwide. 90-Day Money Back Guarantee On All Purchases.">
    <meta name="og:image" content="/static/front/image/ketoweightloss_banner.jpg">
    <meta name="og:site_name" content="Keto Weight Loss">
    <meta name="og:locale" content="en_US">
    <link rel="apple-touch-icon" sizes="180x180" href="/static/front/image/apple-touch-icon.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/static/front/image/favicon-32x32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/static/front/image/favicon-16x16.png">
    <link rel="manifest" href="/static/front/txt/site.webmanifest">
    <link rel="shortcut icon" href="/static/front/image/favicon.ico">
    <meta name="msapplication-TileColor" content="#ffffff">
    <meta name="msapplication-config" content="/static/front/txt/browserconfig.xml">
    <meta name="theme-color" content="#ffffff">
    <link rel="stylesheet" href="/static/front/css/bootstrap-4.3.0.min.css">
    <link rel="stylesheet" href="/static/front/css/fontawesome-all-5.7.1.min.css">
    <link rel="stylesheet" href="/static/front/css/defaults.css">
    <link rel="stylesheet" href="/static/front/css/global.css">	<link rel="stylesheet" href="/static/front/css/fancybox-3.5.6.min.css">
    <link rel="stylesheet" href="/static/front/css/animate-3.7.0.min.css">
    <link rel="stylesheet" href="/static/front/css/holdon.min.css">
    <link rel="stylesheet" href="/static/front/css/checkout_special.css">
    <link rel="stylesheet" href="/static/front/css/font-gilroy.min.css">
    <style type="text/css">
        @media (min-width: 768px) {
            body,
            html{
                background-image: url('http://www.whaxkl.com/static/front/image/checkout-bg.jpg');
            }
            .fa{display:none !important;}
        }
    </style>
    </head>
<body data-page-lang="en">
<section class="container">
    <div class="row h-100 pt-2">
        <div class="col-12 my-auto">
            <img src="/static/front/image/e33a6fa0045b460.png" class="img-fluid">
        </div>
    </div>
    <div class="row h-100 mt-2 py-2 free-shipping-text-container">
        <div class="col-12 text-left my-auto text-center pl-0">
            <img src="/static/front/image/checkmark.png" width="30">
            <span class="text-black approved approved-text" style="font-weight:bold;">You have been Approved for Free Shipping</span>
            <br>
        </div>
    </div>
    <div class="row custom-checkout-promo-banner">
        <div class="col-12 py-2 my-auto text-center" style="background-color:rgba(4, 60, 137, 1);color:white;font-weight:bold;font-size:14px;padding-left:2px!important;padding-right:2px !important;">
            Enter Special Code 'FREEMONTH' At Checkout For 1 Additional Free Bottle Supply
        </div>
    </div>
    <div class="row h-100 pt-2">
        <div class="col-md-2 col-3 my-auto px-1">
            <img src="/static/front/image/moneyback-guarantee.svg" class="img-fluid">
        </div>
        <div class="col-md-10 col-9 my-auto px-1">
            <h6 style="margin-bottom:4px;"><b style="font-size:14px;">100% MONEY BACK GUARANTEE</b></h6>
            <p style="font-size:0.70rem;">
                <b>
                    <span style="font-weight:900;">Our Promise: Easy Refund and Pick Up</span> - If you don't lose weight, simply call us and we will give you a full 100% hassle-free refund. We stand behind our product. <br> <i style="color:orange;">Try it, Risk Free.</i>
                </b>
            </p>
        </div>
    </div>
    <div class="row mb-2 justify-content-center align-items-center">
        <div class="col-3">
            <img src="/static/front/image/va_logo.png" class="img-fluid ">
        </div>
        <div class="col pl-0" style="font-size:0.7rem; line-height: 1.5;">
            <span class="p-0">Upon placing your order, <span style="font-weight:900;">We will donate a 6-Month Supply of Essential Vitamins to a Child with malnutrition</span>, through our 1-For-1 Grant partnership with Vitamin Angels.</span>
        </div>
    </div>
</section>
<section id="promo-code-section" class="promo-code-section container py-2">
    <div class="promo-code-part form-row justify-content-center">
        <div class="col-auto flex-fill">
            <input id="promo-code" type="text" class="form-control" placeholder="Enter Special Discount Code.">
        </div>
        <div class="col-auto">
            <button id="btn-apply-promo" type="button" class="btn btn-info">Apply</button>
        </div>
    </div>
    <div id="promo-response-holder" class="promo-code-part row d-none">
        <div class="col">
            <p id="promo-response" class="font-weight-bold my-2 text-center">Success: +1 Free Bottle Supply Added</p>
        </div>
    </div>
</section>
<section class="container px-2 pb-2">
    <div class="text-center">
        <div id="product-1" class="product-element" data-product-id="buy3">
            <img src="/static/front/image/package_buy3_selected.jpg" class="img-fluid">
        </div>
        <div id="product-2" class="product-element" data-product-id="buy2">
            <img src="/static/front/image/package_buy2.jpg" class="img-fluid">
        </div>
        <div id="product-3" class="product-element" data-product-id="buy1">
            <img src="/static/front/image/package_buy1.jpg" class="img-fluid">
        </div>
    </div>
</section>
<section class="container">
    <div class="row px-2">
        <div id="formtop" class="col-12 border p-3 text-center">
            <b class="text-black text-uppercase">Where do we ship your KETO?</b>
        </div>
        <div id="formbottom" class="col-12 border p-3">
            <form action="" class="message"  method="post" name="myform" id="myform">
                <input name="isform" type="hidden" value="1">
                <input name="csrf_test_name" type="hidden" value="05e22eae351e4f9e6936be8ed912ea5e">
                <input id="special-coupon-applied" type="hidden" name="special_coupon_applied" value="0">
                <input id="product-id" class="bn" type="hidden" name="bn" value="">
                <div class="form-row">
                    <div class="col-md-6 mb-2 pb-1">
                        <input type="text" class="form-control" name="fn" id="validationCustom01" placeholder="First name" required="" value="">
                        <div class="invalid-feedback">
                            Please enter your first name.
                        </div>
                    </div>
                    <div class="col-md-6 mb-2 pb-1">
                        <input type="text" class="form-control" name="ln" id="validationCustom02" placeholder="Last name" required="" value="">
                        <div class="invalid-feedback">
                            Please enter your last name.
                        </div>
                    </div>
                </div>
                <div class="form-row">
                    <div class="col-md-6 mb-2 pb-1">
                        <select class="form-control" id="country" name="country" required="">
                            <option value="" disabled="" selected="">Select Country</option>
                            <option value="AF">Afghanistan</option>
                            <option value="AX">Åland Islands</option>
                            <option value="AL">Albania</option>
                            <option value="DZ">Algeria</option>
                            <option value="AS">American Samoa</option>
                            <option value="AD">Andorra</option>
                            <option value="AO">Angola</option>
                            <option value="AI">Anguilla</option>
                            <option value="AQ">Antarctica</option>
                            <option value="AG">Antigua and Barbuda</option>
                            <option value="AR">Argentina</option>
                            <option value="AM">Armenia</option>
                            <option value="AW">Aruba</option>
                            <option value="AU">Australia</option>
                            <option value="AT">Austria</option>
                            <option value="AZ">Azerbaijan</option>
                            <option value="BS">Bahamas (the)</option>
                            <option value="BH">Bahrain</option>
                            <option value="BD">Bangladesh</option>
                            <option value="BB">Barbados</option>
                            <option value="BY">Belarus</option>
                            <option value="BE">Belgium</option>
                            <option value="BZ">Belize</option>
                            <option value="BJ">Benin</option>
                            <option value="BM">Bermuda</option>
                            <option value="BT">Bhutan</option>
                            <option value="BO">Bolivia (Plurinational State of)</option>
                            <option value="BQ">Bonaire, Sint Eustatius and Saba</option>
                            <option value="BA">Bosnia and Herzegovina</option>
                            <option value="BW">Botswana</option>
                            <option value="BV">Bouvet Island</option>
                            <option value="BR">Brazil</option>
                            <option value="IO">British Indian Ocean Territory (the)</option>
                            <option value="BN">Brunei Darussalam</option>
                            <option value="BG">Bulgaria</option>
                            <option value="BF">Burkina Faso</option>
                            <option value="BI">Burundi</option>
                            <option value="CV">Cabo Verde</option>
                            <option value="KH">Cambodia</option>
                            <option value="CM">Cameroon</option>
                            <option value="CA">Canada</option>
                            <option value="KY">Cayman Islands (the)</option>
                            <option value="CF">Central African Republic (the)</option>
                            <option value="TD">Chad</option>
                            <option value="CL">Chile</option>
                            <option value="CN">China</option>
                            <option value="CX">Christmas Island</option>
                            <option value="CC">Cocos (Keeling) Islands (the)</option>
                            <option value="CO">Colombia</option>
                            <option value="KM">Comoros (the)</option>
                            <option value="CD">Congo (the Democratic Republic of the)</option>
                            <option value="CG">Congo (the)</option>
                            <option value="CK">Cook Islands (the)</option>
                            <option value="CR">Costa Rica</option>
                            <option value="CI">Côte d'Ivoire</option>
                            <option value="HR">Croatia</option>
                            <option value="CU">Cuba</option>
                            <option value="CW">Curaçao</option>
                            <option value="CY">Cyprus</option>
                            <option value="CZ">Czechia</option>
                            <option value="DK">Denmark</option>
                            <option value="DJ">Djibouti</option>
                            <option value="DM">Dominica</option>
                            <option value="DO">Dominican Republic (the)</option>
                            <option value="EC">Ecuador</option>
                            <option value="EG">Egypt</option>
                            <option value="SV">El Salvador</option>
                            <option value="GQ">Equatorial Guinea</option>
                            <option value="ER">Eritrea</option>
                            <option value="EE">Estonia</option>
                            <option value="SZ">Eswatini</option>
                            <option value="ET">Ethiopia</option>
                            <option value="FK">Falkland Islands (the) [Malvinas]</option>
                            <option value="FO">Faroe Islands (the)</option>
                            <option value="FJ">Fiji</option>
                            <option value="FI">Finland</option>
                            <option value="FR">France</option>
                            <option value="GF">French Guiana</option>
                            <option value="PF">French Polynesia</option>
                            <option value="TF">French Southern Territories (the)</option>
                            <option value="GA">Gabon</option>
                            <option value="GM">Gambia (the)</option>
                            <option value="GE">Georgia</option>
                            <option value="DE">Germany</option>
                            <option value="GH">Ghana</option>
                            <option value="GI">Gibraltar</option>
                            <option value="GR">Greece</option>
                            <option value="GL">Greenland</option>
                            <option value="GD">Grenada</option>
                            <option value="GP">Guadeloupe</option>
                            <option value="GU">Guam</option>
                            <option value="GT">Guatemala</option>
                            <option value="GG">Guernsey</option>
                            <option value="GN">Guinea</option>
                            <option value="GW">Guinea-Bissau</option>
                            <option value="GY">Guyana</option>
                            <option value="HT">Haiti</option>
                            <option value="HM">Heard Island and McDonald Islands</option>
                            <option value="VA">Holy See (the)</option>
                            <option value="HN">Honduras</option>
                            <option value="HK">Hong Kong</option>
                            <option value="HU">Hungary</option>
                            <option value="IS">Iceland</option>
                            <option value="IN">India</option>
                            <option value="ID">Indonesia</option>
                            <option value="IR">Iran (Islamic Republic of)</option>
                            <option value="IQ">Iraq</option>
                            <option value="IE">Ireland</option>
                            <option value="IM">Isle of Man</option>
                            <option value="IL">Israel</option>
                            <option value="IT">Italy</option>
                            <option value="JM">Jamaica</option>
                            <option value="JP">Japan</option>
                            <option value="JE">Jersey</option>
                            <option value="JO">Jordan</option>
                            <option value="KZ">Kazakhstan</option>
                            <option value="KE">Kenya</option>
                            <option value="KI">Kiribati</option>
                            <option value="KP">Korea (the Democratic People's Republic of)</option>
                            <option value="KR">Korea (the Republic of)</option>
                            <option value="KW">Kuwait</option>
                            <option value="KG">Kyrgyzstan</option>
                            <option value="LA">Lao People's Democratic Republic (the)</option>
                            <option value="LV">Latvia</option>
                            <option value="LB">Lebanon</option>
                            <option value="LS">Lesotho</option>
                            <option value="LR">Liberia</option>
                            <option value="LY">Libya</option>
                            <option value="LI">Liechtenstein</option>
                            <option value="LT">Lithuania</option>
                            <option value="LU">Luxembourg</option>
                            <option value="MO">Macao</option>
                            <option value="MK">Macedonia (the former Yugoslav Republic of)</option>
                            <option value="MG">Madagascar</option>
                            <option value="MW">Malawi</option>
                            <option value="MY">Malaysia</option>
                            <option value="MV">Maldives</option>
                            <option value="ML">Mali</option>
                            <option value="MT">Malta</option>
                            <option value="MH">Marshall Islands (the)</option>
                            <option value="MQ">Martinique</option>
                            <option value="MR">Mauritania</option>
                            <option value="MU">Mauritius</option>
                            <option value="YT">Mayotte</option>
                            <option value="MX">Mexico</option>
                            <option value="FM">Micronesia (Federated States of)</option>
                            <option value="MD">Moldova (the Republic of)</option>
                            <option value="MC">Monaco</option>
                            <option value="MN">Mongolia</option>
                            <option value="ME">Montenegro</option>
                            <option value="MS">Montserrat</option>
                            <option value="MA">Morocco</option>
                            <option value="MZ">Mozambique</option>
                            <option value="MM">Myanmar</option>
                            <option value="NA">Namibia</option>
                            <option value="NR">Nauru</option>
                            <option value="NP">Nepal</option>
                            <option value="NL">Netherlands (the)</option>
                            <option value="NC">New Caledonia</option>
                            <option value="NZ">New Zealand</option>
                            <option value="NI">Nicaragua</option>
                            <option value="NE">Niger (the)</option>
                            <option value="NG">Nigeria</option>
                            <option value="NU">Niue</option>
                            <option value="NF">Norfolk Island</option>
                            <option value="MP">Northern Mariana Islands (the)</option>
                            <option value="NO">Norway</option>
                            <option value="OM">Oman</option>
                            <option value="PK">Pakistan</option>
                            <option value="PW">Palau</option>
                            <option value="PS">Palestine, State of</option>
                            <option value="PA">Panama</option>
                            <option value="PG">Papua New Guinea</option>
                            <option value="PY">Paraguay</option>
                            <option value="PE">Peru</option>
                            <option value="PH">Philippines (the)</option>
                            <option value="PN">Pitcairn</option>
                            <option value="PL">Poland</option>
                            <option value="PT">Portugal</option>
                            <option value="PR">Puerto Rico</option>
                            <option value="QA">Qatar</option>
                            <option value="RE">Réunion</option>
                            <option value="RO">Romania</option>
                            <option value="RU">Russian Federation (the)</option>
                            <option value="RW">Rwanda</option>
                            <option value="BL">Saint Barthélemy</option>
                            <option value="SH">Saint Helena, Ascension and Tristan da Cunha</option>
                            <option value="KN">Saint Kitts and Nevis</option>
                            <option value="LC">Saint Lucia</option>
                            <option value="MF">Saint Martin (French part)</option>
                            <option value="PM">Saint Pierre and Miquelon</option>
                            <option value="VC">Saint Vincent and the Grenadines</option>
                            <option value="WS">Samoa</option>
                            <option value="SM">San Marino</option>
                            <option value="ST">Sao Tome and Principe</option>
                            <option value="SA">Saudi Arabia</option>
                            <option value="SN">Senegal</option>
                            <option value="RS">Serbia</option>
                            <option value="SC">Seychelles</option>
                            <option value="SL">Sierra Leone</option>
                            <option value="SG">Singapore</option>
                            <option value="SX">Sint Maarten (Dutch part)</option>
                            <option value="SK">Slovakia</option>
                            <option value="SI">Slovenia</option>
                            <option value="SB">Solomon Islands</option>
                            <option value="SO">Somalia</option>
                            <option value="ZA">South Africa</option>
                            <option value="GS">South Georgia and the South Sandwich Islands</option>
                            <option value="SS">South Sudan</option>
                            <option value="ES">Spain</option>
                            <option value="LK">Sri Lanka</option>
                            <option value="SD">Sudan (the)</option>
                            <option value="SR">Suriname</option>
                            <option value="SJ">Svalbard and Jan Mayen</option>
                            <option value="SE">Sweden</option>
                            <option value="CH">Switzerland</option>
                            <option value="SY">Syrian Arab Republic (the)</option>
                            <option value="TW">Taiwan (Province of China)</option>
                            <option value="TJ">Tajikistan</option>
                            <option value="TZ">Tanzania, the United Republic of</option>
                            <option value="TH">Thailand</option>
                            <option value="TL">Timor-Leste</option>
                            <option value="TG">Togo</option>
                            <option value="TK">Tokelau</option>
                            <option value="TO">Tonga</option>
                            <option value="TT">Trinidad and Tobago</option>
                            <option value="TN">Tunisia</option>
                            <option value="TR">Turkey</option>
                            <option value="TM">Turkmenistan</option>
                            <option value="TC">Turks and Caicos Islands (the)</option>
                            <option value="TV">Tuvalu</option>
                            <option value="UG">Uganda</option>
                            <option value="UA">Ukraine</option>
                            <option value="AE">United Arab Emirates (the)</option>
                            <option value="GB">United Kingdom of Great Britain and Northern Ireland (the)</option>
                            <option value="UM">United States Minor Outlying Islands (the)</option>
                            <option value="US">United States of America (the)</option>
                            <option value="UY">Uruguay</option>
                            <option value="UZ">Uzbekistan</option>
                            <option value="VU">Vanuatu</option>
                            <option value="VE">Venezuela (Bolivarian Republic of)</option>
                            <option value="VN">Viet Nam</option>
                            <option value="VG">Virgin Islands (British)</option>
                            <option value="VI">Virgin Islands (U.S.)</option>
                            <option value="WF">Wallis and Futuna</option>
                            <option value="EH">Western Sahara*</option>
                            <option value="YE">Yemen</option>
                            <option value="ZM">Zambia</option>
                            <option value="ZW">Zimbabwe</option>
                        </select>
                        <div class="invalid-feedback">
                            Please provide a valid country.
                        </div>
                    </div>
                    <div class="col-md-6 mb-2 pb-1">
                        <div id="state-container">
                            <select id="state" class="form-control" data-placement="auto left" title="State" name="state" autocomplete="address-level1">
                                <option value="CN-34">Anhui</option>
                                <option value="CN-92">Aomen</option>
                                <option value="CN-11">Beijing</option>
                                <option value="CN-50">Chongqing</option>
                                <option value="CN-35">Fujian</option>
                                <option value="CN-62">Gansu</option>
                                <option value="CN-44">Guangdong</option>
                                <option value="CN-45">Guangxi</option>
                                <option value="CN-52">Guizhou</option>
                                <option value="CN-46">Hainan</option>
                                <option value="CN-13">Hebei</option>
                                <option value="CN-23">Heilongjiang</option>
                                <option value="CN-41">Henan</option>
                                <option value="CN-42">Hubei</option>
                                <option value="CN-43">Hunan</option>
                                <option value="CN-32">Jiangsu</option>
                                <option value="CN-36">Jiangxi</option>
                                <option value="CN-22">Jilin</option>
                                <option value="CN-21">Liaoning</option>
                                <option value="CN-15">Nei Mongol</option>
                                <option value="CN-64">Ningxia</option>
                                <option value="CN-63">Qinghai</option>
                                <option value="CN-61">Shaanxi</option>
                                <option value="CN-37">Shandong</option>
                                <option value="CN-31">Shanghai</option>
                                <option value="CN-14">Shanxi</option>
                                <option value="CN-51">Sichuan</option><option value="CN-71">Taiwan</option><option value="CN-12">Tianjin</option><option value="CN-91">Xianggang</option><option value="CN-65">Xinjiang</option><option value="CN-54">Xizang</option><option value="CN-53">Yunnan</option><option value="CN-33">Zhejiang</option><option disabled="">──────────</option><option value="-">Other</option>
                            </select></div>
                    </div>
                    <div class="col-md-12 mb-2 pb-1">
                        <input type="text" class="form-control" name="address" id="validationCustom05" placeholder="Your Address" maxlength="63" required="" value="">
                        <div class="invalid-feedback">
                            Please provide a valid address.
                        </div>
                    </div>
                    <div class="col-md-12 mb-2 pb-1">
                        <input type="text" class="form-control" name="zpc" id="zip-code" placeholder="Zip / Postal code" value="">
                        <div class="invalid-feedback">
                            Please provide a valid Zip / Postal code.
                        </div>
                    </div>
                    <div class="col-md-6 mb-2 pb-1">
                        <input type="text" class="form-control" name="city" id="city" placeholder="City" value="">
                        <div class="invalid-feedback">
                            Please provide a valid city.
                        </div>
                    </div>
                    <div class="col-md-6 mb-2 pb-1">
                        <input type="email" pattern=".*@.*\..*" name="email" class="form-control" id="validationCustom09" placeholder="Email Address" required="" value="">
                        <div class="invalid-feedback">
                            Please provide a valid email address.
                        </div>
                    </div>
                    <div class="col-md-6 mb-3">
                        <input type="tel" pattern=".*" name="phone" class="form-control" id="validationCustom10" placeholder="Phone Number" value="">
                        <div class="invalid-feedback">
                            Please provide a valid phone number.
                        </div>
                    </div>
                    Our terms of payment are cash on delivery，please check the goods before payment done.
                    <div class="col-12">
                        <div class="col-12 text-center px-0">
                            <button type="button" class="submit-btn cstm-12 btn btn-dark btn-lg btn-shop-now mt-2" onclick="mys_ajax_submit('http://192.168.1.18:8080/add?s=form&c=gmbd&m=post', 'myform', '2000', 'http://www.whaxkl.com/front/User/index')" style="line-height:1;width:275px;">
                                <strong style="font-family:&#39;Gilroy-Bold&#39;;
										font-size:1.3rem">PLACE ORDER</strong><br>
                                <span style="font-size:1rem;">Get Your Package</span>
                            </button>
                            <br>
                            <span>256 bit secure form</span>
                        </div>
                    </div>
                </div>

                <input id="opt" type="hidden" name="opt" value="">
            </form>
        </div>
    </div>
</section>
<section class="my-4 container">
    <div class="row">
        <div class="col-12 col-sm-6 align-top">
            <img src="/static/front/image/privacy.png" class="img-fluid">
        </div>
        <div class="col-8 col-sm-6 pt-3 pt-sm-0 align-top">
            <img src="/static/front/image/partners.png" class="img-fluid">
        </div>
    </div>
</section>
<script src="/static/front/js/jquery-3.3.1.min.js"></script>

<script type="text/javascript">
    var ga_product_id_in_cart = '';
    var ga_promo_top_product = {"id":'buy3',"name":"Complete Package Plus","list_name":"special with discount","brand":"Keto Weight Loss","category":"Keto","list_position":1,"quantity":"6","price":"98.00"};
    var ga_promo_products = [{"id":'buy3',"name":"Complete Package Plus","list_name":"special with discount","brand":"Keto Weight Loss","category":"Keto","list_position":1,"quantity":"6","price":"98.00"},{"id":'buy2',"name":"Regular Package Plus","list_name":"special with discount","brand":"Keto Weight Loss","category":"Keto","list_position":2,"quantity":"4","price":"75.00"},{"id":'buy1',"name":"Basic Package Plus","list_name":"special with discount","brand":"Keto Weight Loss","category":"Keto","list_position":3,"quantity":"2","price":"49.95"}];

    function select_product(selected_id, callback){
        $('#product-id').val(selected_id);
        $('[data-product-id]').each(function(i, obj) {
            let prod_id = $(this).attr('data-product-id');
            let product_name = (prod_id == selected_id) ? 'package_'+prod_id+'_selected.jpg' : 'package_'+prod_id+'.jpg';
            $(this).children('img').attr('src',"/static/front/image/" + product_name);
        });
        if (typeof callback === 'function') { callback(); }
        if (ga_product_id_in_cart !== '') {
            gtag('event', 'remove_from_cart', {
                "items": [ { "id": ga_product_id_in_cart } ]
            });
        }
        ga_product_id_in_cart = selected_id;
        gtag('event', 'add_to_cart', {
            "items": [ { "id": ga_product_id_in_cart } ]
        });
    }

    function apply_special_promotion(){
        $('#product-1').attr('data-product-id', 'buy3');
        $('#product-2').attr('data-product-id', 'buy2');
        $('#product-3').attr('data-product-id', 'buy1');
        $('#special-coupon-applied').val('1');
        $('.promo-code-part').toggleClass('d-none');
    }

    select_product("buy3");
    (function() {
        'use strict';
        window.addEventListener('load', function() {
            var forms = document.getElementsByClassName('needs-validation');
            var validation = Array.prototype.filter.call(forms, function(form) {
                form.addEventListener('submit', function(event) {
                    if (form.checkValidity() === false) {
                        event.preventDefault();
                        event.stopPropagation();
                    }else{
                        HoldOn.open({
                            theme:'sk-fading-circle',
                            backgroundColor:'#FFFFFF',
                            textColor:'#000000'
                        });
                    }
                    form.classList.add('was-validated');
                }, false);
            });
        }, false);
    })();

    $('#btn-apply-promo').click(function(event) {
        let entered_promo_code = $('#promo-code').val().trim();
        $('#opt').val(entered_promo_code);
        if (entered_promo_code.length > 0) {
            apply_special_promotion();
            select_product(1233, function(){
                $('#product-1').addClass('animated pulse');
                smooth_scroll($(this), $('#promo-code-section'), null, 1000);
            });

            gtag('event', 'view_item_list', {
                "items": ga_promo_products
            });
            gtag('event', 'checkout_progress', {
                "items": [ ga_promo_top_product ],
                "coupon": entered_promo_code
            });
        }
    });

    $(document).ready(function(){
        $('#country').val("CN").change();
    });

    $('[data-product-id]').click(function(event) {
        select_product($(this).attr('data-product-id'));
        smooth_scroll($(this), $('#formtop'));
    });
</script>
<script src="/static/front/js/popper-1.14.7.min.js"></script>
<script src="/static/front/js/bootstrap-4.3.0.min.js"></script>
<script src="/static/front/js/smooth-scroll.js"></script>
<script src="/static/front/js/fancybox-3.5.6.min.js"></script>
<script src="/static/front/js/holdon.min.js"></script>
<script src="/static/front/js/country.js"></script>
<script type="text/javascript">var assets_path = 'http://ketox.jikeguan.com/static/assets/';var is_mobile_cms = '';</script>
<script src="/static/front/js/lang.js" type="text/javascript"></script>
<script src="/static/front/js/layer.js" type="text/javascript"></script>
<script src="/static/front/js/cms.js" type="text/javascript"></script>
</body></html>