<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/25
 * Time: 18:18
 */

namespace app\front\controller;

use think\Controller;
use think\Db;

class User extends Controller
{
    public function shop()
    {
        $verify = $this->ipVerify();
        if($verify === true) {
            return $this->fetch('shop');
        } else {
            $url = "http://localhost/index";
            header("Location: $url");
        }
    }
    public function index()
    {
        $verify = $this->ipVerify();
        if($verify === true) {
            return $this->fetch('index');
        } else {
            $url = "http://localhost/index";
            header("Location: $url");
        }
    }
    public function ipVerify(){
        require_once "../vendor/ip2region-master/Ip2Region.php";
        $ip = real_ip();
        $ip_path = new \Ip2Region();
        $info = $ip_path->btreeSearch($ip);
        $guge = "谷歌";
        $google  ="Google";
        $find_guge = stripos($info['region'], $guge);
        $google = stripos($info['region'], $google);
        if ($find_guge === false && $google === false) {
            return true;
        } else {
            return false;
        }
    }
    public function terms()
    {
        return view('terms');
    }
    public function privacy()
    {
        return view('privacy');
    }
    public function add(){
        header('Access-Control-Allow-Origin:*');
        $data = $this->request->request();
        /*$post_data = array(
            'isform' => $data['isform'],
            'csrf_test_name' => $data['csrf_test_name'],
            'special_coupon_applied' => $data['special_coupon_applied'],
            'bn' => $data['bn'],
            'fn' => $data['fn'],
            'ln' => $data['ln'],
            'country' => $data['country'],
            'state' => $data['state'],
            'address' => $data['address'],
            'zpc' => $data['zpc'],
            'city' =>$data['city'],
            'email' => $data['email'],
            'phone' => $data['phone'],
            'opt' => $data['opt'],
            //'host' => '192.168.1.18:8080'
        );*/
        $url = "http://54.187.192.81:8082/order.php";
        $data['host'] = real_ip();
        $data['createtime'] = date("Y-m-d H:i:s");
        $data = post_curl($url, $data);
        //$data = curl_setopt($url,CURLOPT_HTTPHEADER,$data);
        echo $data;
        die;
        $res = Db::table('information')->insert($array);
        if(!$res){
            return json(['code'=>-1,'data'=>'','msg'=>'break down']);
        }
        return json(['code'=>1,'data'=>'','msg'=>'success']);
    }
}