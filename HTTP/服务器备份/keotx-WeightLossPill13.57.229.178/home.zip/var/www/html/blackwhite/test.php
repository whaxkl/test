<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/25
 * Time: 18:18
 */
class Test
{
    public $blacklist = [];
    public $whitelist = [];
    /*
     * true 白名单
     * false 黑名单
     */
    public function ipVerify(){
        require "./ip2region-master/Ip2Region.php";
        $ip = $this->real_ip();
        $ip_path = new \Ip2Region();//'35.236.164.7'
        $info = $ip_path->btreeSearch($ip);
        $guge = "谷歌";
        $find_guge = stripos($info['region'], $guge);
        if(in_array($ip,$this->whitelist)) return true;
        if ($find_guge === false && !in_array($ip,$this->blacklist)) {
            return true;
        } else {
            return false;
        }
    }
    //获取浏览器ip地址
    public function real_ip(){
        static $realip;

        if ($realip !== NULL) {
            return $realip;
        }

        if (isset($_SERVER)) {
            if (isset($_SERVER['HTTP_X_FORWARDED_FOR'])) {
                $arr = explode(',', $_SERVER['HTTP_X_FORWARDED_FOR']);

                foreach ($arr as $ip) {
                    $ip = trim($ip);

                    if ($ip != 'unknown') {
                        $realip = $ip;
                        break;
                    }
                }
            }
            else if (isset($_SERVER['HTTP_CLIENT_IP'])) {
                $realip = $_SERVER['HTTP_CLIENT_IP'];
            }
            else if (isset($_SERVER['REMOTE_ADDR'])) {
                $realip = $_SERVER['REMOTE_ADDR'];
            }
            else {
                $realip = '0.0.0.0';
            }
        }
        else if (getenv('HTTP_X_FORWARDED_FOR')) {
            $realip = getenv('HTTP_X_FORWARDED_FOR');
        }
        else if (getenv('HTTP_CLIENT_IP')) {
            $realip = getenv('HTTP_CLIENT_IP');
        }
        else {
            $realip = getenv('REMOTE_ADDR');
        }

        preg_match('/[\\d\\.]{7,15}/', $realip, $onlineip);
        $realip = (!empty($onlineip[0]) ? $onlineip[0] : '0.0.0.0');
        return $realip;
    }
}