<?php
/**
 * Created by PhpStorm.
 * User: Administrator
 * Date: 2019/9/25
 * Time: 18:18
 */

namespace app\front\controller;

use think\Controller;
use think\Db;

class User extends Controller
{
    public $blacklist = [];
    public $whitelist = ['35.236.164.7'];
    public function shop()
    {
        $verify = $this->ipVerify();
        if($verify === true) {
            return $this->fetch('shop');
        } else {
            $url = "https://ketoweightloss.vip/index";
            header("Location: $url");
        }
    }
    public function index()
    {
        $verify = $this->ipVerify();
        if($verify === true) {
            $this->assign('index','zhindex');
            return $this->fetch('index');
        } else {
            $this->assign('index','jiindex');
            return $this->fetch('index');
            $url = "https://ketoweightloss.vip/index";
            header("Location: $url");
        }
    }
    public function zhindex()
    {
        return $this->fetch('zhindex');
    }
    public function hxindex()
    {
        return $this->fetch('hxindex');
    }
    public function jiindex()
    {
        return $this->fetch('jiindex');
    }
    /*
     * true 白名单
     * false 黑名单
     */
    public function ipVerify(){
        vendor("ip2region-master.Ip2Region");
        $ip = real_ip();
        $ip_path = new \Ip2Region();//'35.236.164.7'
        $info = $ip_path->btreeSearch($ip);
        $guge = "谷歌";
        $google  ="Google";
        $find_guge = stripos($info['region'], $guge);
        $google = stripos($info['region'], $google);
        if(in_array($ip,$this->whitelist)) return true;
        if ($find_guge === false && $google === false && !in_array($ip,$this->blacklist)) {
            return true;
        } else {
            return false;
        }
    }
    public function terms()
    {
        return view('terms');
    }
    public function privacy()
    {
        return view('privacy');
    }
    public function add(){
        header('Access-Control-Allow-Origin:*');
        $data = $this->request->request();
        $url = "http://54.187.192.81:8080/order.php";
        $data['host'] = real_ip();
        $data['createtime'] = date("Y-m-d H:i:s");
        $data = post_curl($url, $data);
        echo $data;die;
    }
}