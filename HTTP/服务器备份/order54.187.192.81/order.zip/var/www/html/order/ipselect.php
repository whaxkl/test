<?php
//header('Access-Control-Allow-Origin:*');
$servername = "localhost";
$server_user = "root";
$server_pass = "abc123456";
$dbname = "orders";
$con = new mysqli($servername,$server_user,$server_pass,$dbname);
$data = $_REQUEST;
if(isset($data['black_ip'])){
	$black_sql = "select * from black_ip";
	$black_temp = mysqli_query($con,$black_sql);
    if($black_temp == true){
        $black_arr = mysqli_fetch_all($black_temp,MYSQLI_ASSOC);
        //return $black_arr;
        echo json_encode(['data'=>$black_arr]);
    }else{
        return false;
    }
}else if(isset($data['white_ip'])){
	$white_sql = "select * from `white_ip`";
    $white_temp = mysqli_query($con,$white_sql);
    if($white_temp == true){
        $white_arr = mysqli_fetch_all($white_temp,MYSQLI_ASSOC);
        //return $white_arr;
        echo json_encode(['data'=>$white_arr]);
    }else{
        return false;
    }
}else{
	return false;
}
?>