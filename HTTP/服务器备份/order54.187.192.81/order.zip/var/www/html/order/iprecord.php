﻿<?php
	$servername = "localhost";
	$server_user = "root";
	$server_pass = "abc123456";
	$dbname = "orders";
	$con = new mysqli($servername,$server_user,$server_pass,$dbname);
	$data = $_REQUEST;
	$ip = $data['ip'];
	$ip_address = $data['ip_address'];
	$url = $data['url'];
	$ua = $data['ua'];
    $creat_time = $data['creat_time'];
	$black_sql = "insert into `ip_record`(ip,ip_address,url,ua,creat_time) values('{$ip}','{$ip_address}','{$url}','{$ua}','{$creat_time}')";
	mysqli_query($con,$black_sql);