﻿<?php
header('Access-Control-Allow-Origin:*');
$servername = "localhost";
$server_user = "root";
$server_pass = "abc123456";
$dbname = "orders";
$con = new mysqli($servername,$server_user,$server_pass,$dbname);
$black_sql = "select * from ip_trueman where ip_address not like '%谷歌%' order by id desc";
$access = mysqli_query($con,$black_sql);
$access_arr = mysqli_fetch_all($access,MYSQLI_ASSOC);
//var_dump($access_arr);die;
//return $white_arr;
echo json_encode(['code'=>0,'msg'=>'','limit'=>1000,'data'=>$access_arr,'count'=>100]);
