<?php
header('Access-Control-Allow-Origin:*');
header("Cache-Control:post-check=0,pre-check=0",false);
header("Pragma:no-cache");
require 'vendor/autoload.php';
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\IOFactory;
//ob_end_clean();
$servername = "localhost";
$server_user = "root";
$server_pass = "abc123456";
$dbname = "orders";
$con = new mysqli($servername,$server_user,$server_pass,$dbname);
$data = $_REQUEST['key'];
$limit = empty($_REQUEST['limit']) ? 10 : $_REQUEST['limit'];
$page = empty($_REQUEST['page']) ?1:$_REQUEST['page']-1;
if(isset($data['note'])){
    $ip = $data['ip'];
    $insert = "update ip_trueman set note='{$data['note']}' where ip='{$ip}'";
    mysqli_query($con,$insert);
}
$black_sql = "select * from ip_trueman where ip_address not like '%中国%' and ip!=''";
if(!empty($data['url'])){
    $black_sql.= " and url like '%{$data['url']}%'";

}
if(!empty($data['trueman_one']) && !empty($data['trueman_two'])){
    $black_sql.= " and trueman between {$data['trueman_one']} and {$data['trueman_two']}";
}else if(!empty($data['trueman_one'])){
    $black_sql.= " and trueman={$data['trueman_one']}";
}else if(!empty($data['trueman_two'])){
    $black_sql.= " and trueman={$data['trueman_two']}";
}
if(!empty($data['ip'])){
    $black_sql.= " and ip like '%{$data['ip']}%'";
}
if(!empty($data['date_one']) && !empty($data['date_two'])){
    $date_two = date("Y-m-d",strtotime("+1 day",strtotime($data['date_two'])));
    $black_sql.= " and creat_time between '{$data['date_one']}' and '{$date_two}'";
}else if(!empty($data['date_one'])){
    $black_sql.= " and creat_time like '%{$data['date_one']}%'";
}else if(!empty($data['date_two'])){
    $black_sql.= " and creat_time like '%{$data['date_two']}%'";
}
if(!empty($data['guge'])){
    $black_sql.= " and ip_address not like '%谷歌%'";
}
$black_sql.= " order by id desc";
/*$black_sql = "select * from ip_trueman where ip_address not like '%中国%' and ip!='' order by id desc limit 5";
if(!empty($data['url']) && !empty($data['trueman_one']) && !empty($data['trueman_two'])){
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and ip!='' and url like '%{$data['url']}%' and trueman between {$data['trueman_one']} and {$data['trueman_two']} order by id desc";
}else if(!empty($data['trueman_one']) && !empty($data['trueman_two'])){
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and ip!='' and trueman between {$data['trueman_one']} and {$data['trueman_two']} order by id desc";
}else if(!empty($data['url'])){
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and url like '%{$data['url']}%' order by id desc";
}else if(!empty($data['ip'])){
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and ip like '%{$data['ip']}%' order by id desc";
}else if(!empty($data['date_one']) && empty($data['date_two'])) {
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and creat_time like '%{$data['date_one']}%' order by id desc";
}else if(empty($data['date_one']) && !empty($data['date_two'])){
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and creat_time like '%{$data['date_two']}%' order by id desc";
}else if(!empty($data['date_one']) && !empty($data['date_two'])){
    $date_two = date("Y-m-d",strtotime("+1 day",strtotime($data['date_two'])));
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and creat_time between '{$data['date_one']}' and '{$date_two}' order by id desc";
}else if(!empty($data['guge'])){
    $black_sql = "select * from ip_trueman where ip_address not like '%中国%' and ip_address not like '%谷歌%' order by id desc";
}*/

//$black_sql = "select * from ip_trueman where ip_address not like '%中国%' order by id desc";
$access = mysqli_query($con,$black_sql);
$access_arr = mysqli_fetch_all($access,MYSQLI_ASSOC);
if(!empty($data['daochu'])){
    //echo '111';die;
    //var_dump($access_arr);die;
    //$title = ['id','creat_time','ip','trueman','source','ip_address','note','url','ua'];
    $title = ['id','ip','ip_address','url','ua','trueman','creat_time','note','source'];
    export($access_arr,$title);
    //require "https://admin.ketoweightloss.vip/test.php";
}else{
    $count = count($access_arr);
//$limit = ceil($count/10);
    echo json_encode(['code'=>0,'msg'=>'','limit'=>10,'data'=>$access_arr,'count'=>$count,'test'=>$_REQUEST]);
//echo json_encode(['code'=>0,'msg'=>'','limit'=>1000,'data'=>$access_arr,'count'=>100]);
}


function export($data,$title)
{
//        $starttime = Request::get('starttime') ? Request::get('starttime') : '';
//        $endtime   = Request::get('endtime') ? Request::get('endtime') : '';
    /*$data = Db::name('order')
        ->select()
        ->toArray();
    if(empty($data))
    {
        $this->error('你要导出的数据是空的哇！',url('index'));
    }
    $title = [
        'id','date' //具体字段根据自己需要来设置
    ];*/
    $spreadsheet = new Spreadsheet();
    $worksheet = $spreadsheet->getActiveSheet();
    foreach ($title as $key => $value) {
        $worksheet->setCellValueByColumnAndRow($key+1, 1, $value);
    }

    $row = 2; //从第二行开始
    foreach ($data as $item) {
        $column = 1;
        foreach ($item as $value) {
            $worksheet->setCellValueByColumnAndRow($column, $row, $value);
            $column++;
        }
        $row++;
    }
    $fileName = date('YmdHis');
    $fileType = 'Xlsx';
    excelBrowserExport($fileName, $fileType);
    $writer = IOFactory::createWriter($spreadsheet, 'Xlsx');//按照指定格式生成Excel文件

    //echo 1;die;
    return $writer->save('php://output');
}


function import()
{
    $info = Session::get('admin');
    $info = json_decode($info,TRUE);
    $file_size = $_FILES['file']['size'];
    if ($file_size > 5 * 1024 * 1024) {
        $this->error('文件大小不能超过5M');
        exit();
    }

    //限制上传表格类型
    $fileExtendName = substr(strrchr($_FILES['file']["name"], '.'), 1);
    //application/vnd.ms-excel  为xls文件类型
    if ($fileExtendName != 'xlsx') {
        $this->error('必须为excel表格，且必须为xlsx格式！');
        exit();
    }

    if (is_uploaded_file($_FILES['file']['tmp_name'])) {
        // 有Xls和Xlsx格式两种
        $objReader = IOFactory::createReader('Xlsx');

        $filename = $_FILES['file']['tmp_name'];
        $objPHPExcel = $objReader->load($filename);  //$filename可以是上传的表格，或者是指定的表格
        $sheet = $objPHPExcel->getSheet(0);   //excel中的第一张sheet
        $highestRow = $sheet->getHighestRow();       // 取得总行数
        $highestColumn = $sheet->getHighestColumn();   // 取得总列数
        //循环读取excel表格，整合成数组。如果是不指定key的二维，就用$data[i][j]表示。
        $pinyin = new Pinyin();
        Db::startTrans();
        try {
            for ($j = 2; $j <= $highestRow; $j++)
            {
                $data[$j - 2] = [
                    'id' => $objPHPExcel->getActiveSheet()->getCell("A" . $j)->getValue(),//这一个为参考，多字段可以按照这个继续添加即可
                ];
                if (empty($data[$j - 2]['id']))
                {
                    throw new \Exception('id不能为空！');
                }
                $result = Db::name('order')->save($data[$j - 2]);
            }
            Db::commit();
        } catch (\Exception $e) {
            Db::rollBack();
            $this->error($e->getMessage(), url('index'));
        }
        if ($result == true) {
            $this->success('导入成功！', url('index'));
        }
    }
}
function excelBrowserExport($fileName, $fileType)
{
    //ob_end_clean();
    //文件名称校验
    if (!$fileName) {
        trigger_error('文件名不能为空', E_USER_ERROR);
    }

    //Excel文件类型校验
    $type = ['Excel2007', 'Xlsx', 'Excel5', 'xls'];
    if (!in_array($fileType, $type)) {
        trigger_error('未知文件类型', E_USER_ERROR);
    }
    header('Content-Type: application/vnd.ms-excel;charset=UTF-8');
    if ($fileType == 'Excel2007' || $fileType == 'Xlsx') {
        header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
        header('Content-Disposition: attachment;filename="' . $fileName . '.xlsx"');
        header('Cache-Control: max-age=0');
    } else {
        header('Content-Type: application/vnd.ms-excel');
        header('Content-Disposition: attachment;filename="' . $fileName . '.xls"');
        header('Cache-Control: max-age=0');
    }
}
function execUpload($post_data, $url)
{
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_HEADER, false);
    //启用时会发送一个常规的POST请求，类型为：application/x-www-form-urlencoded，就像表单提交的一样。
    curl_setopt($ch, CURLOPT_POST, true);
    curl_setopt($ch, CURLOPT_BINARYTRANSFER, true);
    curl_setopt($ch, CURLOPT_POSTFIELDS, $post_data);
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $info = curl_exec($ch);
    curl_close($ch);
    return $info;
}