﻿<?php
    $servername = "localhost";
    $server_user = "root";
    $server_pass = "abc123456";
    $dbname = "orders";
    $con = new mysqli($servername,$server_user,$server_pass,$dbname);
    $data = $_REQUEST;
    $ip = $data['ip'];
    $ip_address = $data['ip_address'];
    $url = $data['url'];
    $ua = $data['ua'];
    $trueman = $data['trueman'];
    $creat_time = $data['creat_time'];
    $source = $data['source'];

    $select_sql = "select * from `ip_trueman` where ip='{$ip}'";
    $select = mysqli_query($con,$select_sql);
    $select_arr = mysqli_fetch_all($select,MYSQLI_ASSOC);
    if(empty($select_arr)){
        $note = "";
    }else{
        $note = isset($select_arr[0])?$select_arr[0]['note']:$select_arr['note'];
    }
    $black_sql = "insert into `ip_trueman`(ip,ip_address,url,ua,trueman,creat_time,note,source) values('{$ip}','{$ip_address}','{$url}','{$ua}','{$trueman}','{$creat_time}','{$note}','{$source}')";
    mysqli_query($con,$black_sql);
