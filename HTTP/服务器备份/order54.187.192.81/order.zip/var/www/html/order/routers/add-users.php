<?php
    include '../includes/connect.php';

    function number($length) {
        $result = '';

        for($i = 0; $i < $length; $i++) {
            $result .= mt_rand(0, 9);
        }

        return $result;
    }
    $username = $_POST['username'];
    $password1 = $_POST['password'];

     $hash = hash('sha256',$password1);
     function createSalt()
     {
         $test = md5(uniqid(rand(),TRUE));
         return substr($test,0,12);
     }
     $salt = createSalt();
     $password = hash('sha256',$salt.$hash);
     $name = $_POST['name'];
     $email = $_POST['email'];
     $role = $_POST['role'];
     $verified = $_POST['verified'];
     $deleted = $_POST['deleted'];
     $sql = "INSERT INTO users (username, password, name, email, role, verified, deleted, salt) VALUES ('$username', '$password', '$name', '$email', '$role', $verified, $deleted, '$salt')";
     if($con->query($sql)==true){
         $user_id =  $con->insert_id;
         $sql = "INSERT INTO wallet(customer_id) VALUES ($user_id)";
         if($con->query($sql)==true){
             $wallet_id =  $con->insert_id;
             $cc_number = number(16);
             $cvv_number = number(3);
             $sql = "INSERT INTO wallet_details(wallet_id, number, cvv) VALUES ($wallet_id, $cc_number, $cvv_number)";
             $con->query($sql);
         }
     }
//    if($con->query($sql) == true)
//    {
//        header("location: ../users.php");
//    }
header("location: ../users.php");
?>