<?php
$servername = "localhost";
$server_user = "root";
$server_pass = "abc123456";
$dbname = "orders";
$con = new mysqli($servername,$server_user,$server_pass,$dbname);
$data = $_REQUEST;
$black_status = true;
$white_status = true;
if(!empty($data['black_ip'])){
    $black = explode(',',$data['black_ip']);
    foreach ($black as $k=>$v){
        $sql = "delete from `white_ip` where ip='{$v}'";
        $sqlfalse = "delete from `black_ip` where ip='{$v}'";
        $con->query($sql);
        $con->query($sqlfalse);
    }
    $black_str = "";
    foreach ($black as $k=>$v){
        $black_str .= "('{$v}','{$_REQUEST['ip_address']}','{$_REQUEST['note']}','{$_REQUEST['url']}'),";
    }
    $black_str = substr($black_str,0,strlen($black_str)-1);
    $black_sql = "insert into `black_ip`(ip,ip_address,note,url) values {$black_str}";
    if($con->query($black_sql) == true){
        $black_status = true;
    }else{
        $black_status = false;
    }
}
if(!empty($data['white_ip'])){
    $white = explode(',',$data['white_ip']);
    foreach ($white as $k=>$v){
        $sql = "delete from `black_ip` where ip='{$v}'";
        $sqlfalse = "delete from `white_ip` where ip='{$v}'";
        $con->query($sql);
        $con->query($sqlfalse);
    }
    $white_str = "";
    foreach ($white as $k=>$v){
        $white_str .= "('{$v}','{$_REQUEST['ip_address']}','{$_REQUEST['note']}','{$_REQUEST['url']}'),";
    }
    $white_str = substr($white_str,0,strlen($white_str)-1);
    $white_sql = "insert into `white_ip`(ip,ip_address,note,url) values {$white_str}";
    if($con->query($white_sql) == true){
        $white_status = true;
    }else{
        $white_status = false;
    }
}
if(!$black_status){
    exit(json_encode(['code'=>-1,'msg'=>'添加黑名单失败!']));
}
if(!$white_status){
    exit(json_encode(['code'=>-1,'msg'=>'添加白名单失败!']));
}
exit(json_encode(['code'=>1,'msg'=>'添加成功!']));