<?php
include 'includes/connect.php';
include 'includes/wallet.php';

	if($_SESSION['customer_sid']==session_id())
	{
		?>
<!DOCTYPE html>
<html lang="en">

<head>
  <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1.0, user-scalable=no">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="msapplication-tap-highlight" content="no">
  <title>Past Orders</title>

  <!-- Favicons-->
  <link rel="icon" href="images/favicon/favicon-32x32.png" sizes="32x32">
  <!-- Favicons-->
  <link rel="apple-touch-icon-precomposed" href="images/favicon/apple-touch-icon-152x152.png">
  <!-- For iPhone -->
  <meta name="msapplication-TileColor" content="#00bcd4">
  <meta name="msapplication-TileImage" content="images/favicon/mstile-144x144.png">
  <!-- For Windows Phone -->


  <!-- CORE CSS-->
  <link href="css/materialize.min.css" type="text/css" rel="stylesheet" media="screen,projection">
  <link href="css/style.min.css" type="text/css" rel="stylesheet" media="screen,projection">
  <!-- Custome CSS-->
  <link href="css/custom/custom.min.css" type="text/css" rel="stylesheet" media="screen,projection">

  <!-- INCLUDED PLUGIN CSS ON THIS PAGE -->
  <link href="js/plugins/perfect-scrollbar/perfect-scrollbar.css" type="text/css" rel="stylesheet" media="screen,projection">
  <style>
      .select-wrapper span.caret{
          left: 160px;!important;
      }
      .select-wrapper input.select-dropdown{
          text-align: center;
          width: 170px;!inportant;
      }
      .href1{
          text-align: center;
          width: 70px;
          height: 30px;
          float: left;
          display: block;
          line-height: 30px;
          border: 1px solid #000000;
          border-radius: 6px;
          color: #333;
          margin-right: 100px;
      }
      .href1:hover{
          color: white;
          background:#A82128;
          border:1px solid #999;
      }
      .btn {
          display: inline-block;
          margin-left: 36px;
          background-image: linear-gradient(#ddd, #bbb);
          border: 1px solid rgba(0,0,0,.2);
          border-radius: .3em;
          box-shadow: 0 1px white inset;
          text-align: center;
          text-shadow: 0 1px 1px black;
          color:white;
          font-weight: bold;
      }
      .btn:active{
          box-shadow: .05em .1em .2em rgba(0,0,0,.6) inset;
          border-color: rgba(0,0,0,.3);
          background: #bbb;
      }
      .href{
          display:block;
          width:30px;
          height:30px;
          float: left;
          border:1px solid #000000;
          border-radius:3px;
          margin-right:5px;
          line-height:30px;
          text-align:center;
          color: #333333;
      }
      .href:hover{
          color: white;
          background:#A82128;
          border:1px solid #999;
      }
      .count{
          float: right;
          margin: 0;
          line-height: 2em;
          margin-right: 20px;
      }
      .list-table tr{
          border-bottom: 1px solid #cccccc;
      }
      .list-table tr td{
          text-align: center;
      }
      .list-table .content-td td{
          border-right: 1px solid #cccccc;
      }
      /*.list-table .content-td td:hover{*/
      /*    background: #999999;*/
      /*}*/
  </style>
</head>

<body>
  <!-- Start Page Loading -->
  <div id="loader-wrapper">
      <div id="loader"></div>
      <div class="loader-section section-left"></div>
      <div class="loader-section section-right"></div>
  </div>
  <!-- End Page Loading -->

  <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START HEADER -->
  <header id="header" class="page-topbar">
        <!-- start header nav-->
        <div class="navbar-fixed">
            <nav class="navbar-color">
                <div class="nav-wrapper">
                    <ul class="left">
                      <li><h1 class="logo-wrapper"><a href="orders.php" class="brand-logo darken-1"><img src="images/materialize-logo.png" alt="logo"></a> <span class="logo-text">Logo</span></h1></li>
                    </ul>
                    <!-- <ul class="right hide-on-med-and-down">
                        <li><a href="#"  class="waves-effect waves-block waves-light"><i class="mdi-editor-attach-money"><?php echo $balance;?></i></a>
                        </li>
                    </ul>						 -->
                </div>
            </nav>
        </div>
        <!-- end header nav-->
  </header>
  <!-- END HEADER -->

  <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START MAIN -->
  <div id="main">
    <!-- START WRAPPER -->
    <div class="wrapper">

      <!-- START LEFT SIDEBAR NAV-->
      <aside id="left-sidebar-nav">
        <ul id="slide-out" class="side-nav fixed leftside-navigation">
            <li class="user-details cyan darken-2">
            <div class="row">
                <div class="col col s4 m4 l4">
                    <img src="images/avatar.jpg" alt="" class="circle responsive-img valign profile-image">
                </div>
				<div class="col col s8 m8 l8">
                    <ul id="profile-dropdown" class="dropdown-content">
                        <li><a href="routers/logout.php"><i class="mdi-hardware-keyboard-tab"></i> Logout</a>
                        </li>
                    </ul>
                </div>
                <div class="col col s8 m8 l8">
                    <a class="btn-flat dropdown-button waves-effect waves-light white-text profile-btn" href="#" data-activates="profile-dropdown"><?php echo $name;?> <i class="mdi-navigation-arrow-drop-down right"></i></a>
                    <p class="user-roal"><?php echo $role;?></p>
                </div>
            </div>
            </li>
            <!-- <li class="bold"><a href="index.php" class="waves-effect waves-cyan"><i class="mdi-editor-border-color"></i> Order Food</a> -->
            </li>
                <li class="no-padding">
                    <ul class="collapsible collapsible-accordion">
                        <li class="bold"><a class="collapsible-header waves-effect waves-cyan active"><i class="mdi-editor-insert-invitation"></i> Orders</a>
                            <div class="collapsible-body">
                                <ul>
								<li class="<?php
								if(!isset($_GET['status'])){
										echo 'active';
									}?>
									"><a href="orders.php">All Orders</a>
                                </li>
								<?php
									$sql = mysqli_query($con, "SELECT DISTINCT status FROM orders  WHERE customer_id = $user_id;;");
									while($row = mysqli_fetch_array($sql)){
									if(isset($_GET['status'])){
										$status = $row['status'];
									}
                                    echo '<li class='.(isset($_GET['status'])?($status == $_GET['status'] ? 'active' : ''): '').'><a href="orders.php?status='.$row['status'].'">'.$row['status'].'</a>
                                    </li>';
									}
									?>
                                </ul>
                            </div>
                        </li>
                    </ul>
                </li>
        </ul>
        <a href="#" data-activates="slide-out" class="sidebar-collapse btn-floating btn-medium waves-effect waves-light hide-on-large-only cyan"><i class="mdi-navigation-menu"></i></a>
        </aside>
      <!-- END LEFT SIDEBAR NAV-->

      <!-- //////////////////////////////////////////////////////////////////////////// -->

      <!-- START CONTENT -->
      <section id="content">

        <!--breadcrumbs start-->
        <div id="breadcrumbs-wrapper">
          <div class="container">
            <div class="row">
              <div class="col s12 m12 l12">
                <h5 class="breadcrumbs-title">Past Orders</h5>
              </div>
            </div>
          </div>
        </div>
        <!--breadcrumbs end-->


        <!--start container-->
        <div class="container">
          <p class="caption">List of your past orders with details</p>
          <div class="divider"></div>
          <!--editableTable-->
<div id="work-collections" class="seaction">
    <?php
    if(isset($_GET['host'])){
        $host = $_GET['host'];
    }else{
        $host = '%';
    }
    $sql1 = mysqli_query($con, "SELECT host FROM order_list");
    while($row5 = mysqli_fetch_assoc($sql1)){
        $data[] = $row5;
    }
    foreach($data as $k =>$v)
    {
        $new_array[$v['host']] = $v;
    }
    $order_status = mysqli_query($con,"SELECT * FROM order_status");
    while($status = mysqli_fetch_assoc($order_status))
    {
        $new_order[] = $status;
    }
    $keyword = isset($_GET['keyword']) ? $_GET['keyword'] : '' ;
    $read = isset($_GET['deal']) ? $_GET['deal'] : '';
    $deal = isset($_POST['status']) ? $_POST['status'] : '';
    $id = isset($_POST['id']) ? $_POST['id'] : '';
    $sqll = mysqli_query($con,"update order_list set deal = '$deal' where id = '$id'");
    ?>
    <div class="box">
        <form action="orders.php" method="get">
            <select name="host">
                <option value="" disabled selected>选择节点</option>
                <?php foreach($new_array as $key=>$v){?>
                    <option value="<?php echo $v['host']?>" <?php if($host == $v['host']){ echo "selected='selected'";}?>><?php echo $v['host'];?></option>
                <?php }?>
            </select>
            <select name="deal">
                <option value="" disabled selected>选择查询订单状态</option>
                <?php foreach($new_order as $key=>$v){?>
                    <option value="<?php echo $v['id']?>" <?php if($read == $v['id']){ echo "selected='selected'";}?>><?php echo $v['title'];?></option>
                <?php }?>
            </select>
            <input type="text" placeholder="输入要查询的内容" value="<?php echo $keyword;?>" name="keyword" style="width: 170px;text-align: center;" onfocus="this.placeholder=''" onblur="this.placeholder='输入要搜索的内容'">
            <!-- <input type="submit" name="submit" value="查询"> -->
            <button type="submit" class="btn">查询</button>
        </form>
    </div>

                        <?php
                           echo '<div class="row"><div>
                           <h4 class="header">List</h4>';
                          echo '<table class="list-table" border="1" id="dataTable"  style=" border-collapse:collapse;border-spacing:0; border:1px  solid  #FFFFFF;margin-bottom: 25px;" >
                              <tr style="background:#A82128;color: #fff;border-bottom-width: 0;  text-align: center; height: 2.2rem;">
                                    <td width="5%">id</td>
                                    <td width="5%">Product</td>
                                    <td width="5%">Special_coupon_applied</td>
                                    <!-- <td width="5%">Csrf_test_name</td> -->
                                    <td width="5%">First Name</td>
                                    <td width="5%">Last Name</td>
                                    <td width="5%">Country</td>
                                    <td width="10%">City</td>
                                    <td width="10%">Address</td>
                                    <td width="10%">Email</td>
                                    <td width="5%">Phone</td>
                                    <td width="5%">Host</td>
                                    <td width="5%">Create Time</td>
                                    <td width="5%">Order Status</td>
                              </tr>';
                            $page = isset($_GET['p']) ? $_GET['p'] : 1;
                        $sqly = "select * from order_list where CONCAT(email,address,fn,ln,phone,city) like '%$keyword%' AND host like '%$host%' AND deal like '%$read%' order by id desc limit ".($page-1) * 10 .",10; ";
                        $sqlyyy = mysqli_query($con,$sqly);
                           while($row3 = mysqli_fetch_array($sqlyyy))
                           {
                               echo '<tr class="content-td" style="background: #e5efeb; text-align: center;height: 2.2rem;">';
                               echo '<td>'.$row3['id'].'</td>';
                               echo '<td>'.$row3['bn'].'</td>';
                               echo '<td>'.$row3['special_coupon_applied'].'</td>';
//                                echo '<td>'.$row3['csrf_test_name'].'</td>';
                               echo '<td>'.$row3['fn'].'</td>';
                               echo '<td>'.$row3['ln'].'</td>';
                               echo '<td>'.$row3['country'].'</td>';
                               echo '<td>'.$row3['city'].'</td>';
                               echo '<td>'.$row3['address'].'</td>';
                               echo '<td>'.$row3['email'].'</td>';
                               echo '<td>'.$row3['phone'].'</td>	';
                               echo '<td>'.$row3['host'].'</td>';
                               echo '<td>'.$row3['createtime'].'</td>';
                               echo '<td>
                                    <form action="all-orders.php" method="post">
                                        <input type="hidden" value='.$row3['id'].' name="id">
                                        <select name="status" id="">';
                               foreach($new_order as $key => $value){
                                   echo '<option value='.$value['id'].'';
                                   if($value['id'] == $row3['deal'])
                                   {
                                       echo " selected='selected'";
                                   }
                                   if($row3['deal'] == 1)
                                   {
                                       echo " disabled='disabled'";
                                   }
                                   echo '>'.$value['title'].'</option>';
                               }
                               echo '</select>
                                        <button type="submit" class="btn">提交</button>
                                    </form>
                                </p>							
                                </tr>';
                           }
                        echo '</table>';
                                $to_sql = "select count(*) from order_list where CONCAT(email,address,fn,ln,phone,city) like '%$keyword%' AND host like '%$host%' AND deal like '%$read%'";
                                $result = mysqli_query($con,$to_sql);
                                $row1 = mysqli_fetch_array($result);
                                $count = $row1[0];
                                $to_pages = ceil($count/10);
                                if($page <= 1){
                                    echo "<a class='href1' style='margin-left:575px;margin-right:30px;' href=\"javascript:goSort('p',1)\">上一页</a>";
                                    for($i=1;$i<=$to_pages;$i++)
                                    {
                                        echo "<a class='href' href=\"javascript:goSort('p',$i)\">$i</a>";
                                    }
                                }else{
                                    echo "<a class='href1' style='margin-left:575px;margin-right:30px;' href=\"javascript:goSort('p',$page-1)\">上一页</a>";
                                    for($i=1;$i<=$to_pages;$i++)
                                    {
                                        echo "<a class='href' href=\"javascript:goSort('p',$i)\">$i</a>";
                                    }
                                }

                                if ($page<$to_pages){
                                    echo "<a class='href1' style='margin-left:30px;' href=\"javascript:goSort('p',$page+1)\">下一页</a>";
                                }else{
                                    echo "<a class='href1' style='margin-left:30px;' href=\"javascript:goSort('p',$to_pages)\">下一页</a>";
                                }
                                echo "<p class='count'>共 <span style='color: red;'>$count</span> 条数据</p>";
                   ?>
					 </ul>
                </div>
              </div>
            </div>
        </div>
        <!--end container-->

      </section>
      <!-- END CONTENT -->
    </div>
    <!-- END WRAPPER -->

  </div>
  <!-- END MAIN -->



  <!-- //////////////////////////////////////////////////////////////////////////// -->

  <!-- START FOOTER -->
  <footer class="page-footer">
    <div class="footer-copyright">
      <div class="container">
        <span>Copyright © 2017 <a class="grey-text text-lighten-4" href="#" target="_blank">Students</a> All rights reserved.</span>
        <span class="right"> Design and Developed by <a class="grey-text text-lighten-4" href="#">Students</a></span>
        </div>
    </div>
  </footer>
    <!-- END FOOTER -->



    <!-- ================================================
    Scripts
    ================================================ -->

    <!-- jQuery Library -->
    <script type="text/javascript" src="js/plugins/jquery-1.11.2.min.js"></script>
    <!--angularjs-->
    <script type="text/javascript" src="js/plugins/angular.min.js"></script>
    <!--materialize js-->
    <script type="text/javascript" src="js/materialize.min.js"></script>
    <!--scrollbar-->
    <script type="text/javascript" src="js/plugins/perfect-scrollbar/perfect-scrollbar.min.js"></script>
    <!--plugins.js - Some Specific JS codes for Plugin Settings-->
    <script type="text/javascript" src="js/plugins.min.js"></script>
    <!--custom-script.js - Add your own theme custom JS-->
    <script type="text/javascript" src="js/custom-script.js"></script>
    <script type="text/javascript">

		function getQueryString(){
			var result = location.search.match(new RegExp("[\?\&][^\?\&]+=[^\?\&]+","g"));
			if(result == null){
				return "";
			}
			for(var i = 0; i < result.length; i++){
				result[i] = result[i].substring(1);
			}
			return result;
		}

		function funcUrlDel(name){
			var loca = window.location;
			var baseUrl = loca.origin + loca.pathname + "?";
			var query = loca.search.substr(1);
			if (query.indexOf(name)>-1) {
				var obj = {}
				var arr = query.split("&");
				for (var i = 0; i < arr.length; i++) {
					arr[i] = arr[i].split("=");
					obj[arr[i][0]] = arr[i][1];
				};
				delete obj[name];
				var url = baseUrl + JSON.stringify(obj).replace(/[\"\{\}]/g,"").replace(/\:/g,"=").replace(/\,/g,"&");
				return url
			};
		}

		function goSort(name,value){
			var url = window.location.href
			var string_array = getQueryString();
			var oldUrl = (document.URL.indexOf("")==-1)?document.URL+"":document.URL;
			var newUrl;
			if(string_array.length>0)//如果已经有筛选条件
			{
				var repeatField = false;
				for(var i=0;i<string_array.length;i++){
					if(!(string_array[i].indexOf(name)==-1)){
						repeatField = true;//如果有重复筛选条件，替换条件值
						if(url.indexOf('page')>=0)
						{
							oldUrl = funcUrlDel("page");
						}
						newUrl = oldUrl.replace(string_array[i],name+"="+value);
					}
				}
				//如果没有重复的筛选字段
				if(repeatField == false){
					if(url.indexOf('page')>=0)
					{
						oldUrl = funcUrlDel("page");
						newUrl = oldUrl+name+"="+value;
					}else{
						newUrl = oldUrl+"&"+name+"="+value;
					}
				}
			}else
			//跳转
			newUrl = oldUrl+"?"+name+"="+value;
			window.location.href = newUrl;
		}
    </script>
</body>

</html>
<?php
	}
	else
	{
		if($_SESSION['admin_sid']==session_id())
		{
			header("location:all-orders.php");
		}
		else{
			header("location:login.php");
		}
	}
?>