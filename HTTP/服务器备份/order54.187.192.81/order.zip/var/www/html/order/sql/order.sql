/*
MySQL Backup
Database: order
Backup Time: 2019-10-16 14:29:29
*/

SET FOREIGN_KEY_CHECKS=0;
DROP TABLE IF EXISTS `order`.`items`;
DROP TABLE IF EXISTS `order`.`order_details`;
DROP TABLE IF EXISTS `order`.`order_list`;
DROP TABLE IF EXISTS `order`.`order_status`;
DROP TABLE IF EXISTS `order`.`orders`;
DROP TABLE IF EXISTS `order`.`ticket_details`;
DROP TABLE IF EXISTS `order`.`tickets`;
DROP TABLE IF EXISTS `order`.`users`;
DROP TABLE IF EXISTS `order`.`wallet`;
DROP TABLE IF EXISTS `order`.`wallet_details`;
CREATE TABLE `items` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) NOT NULL,
  `price` int(11) NOT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
CREATE TABLE `order_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `order_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `item_id` (`item_id`),
  KEY `order_id` (`order_id`),
  CONSTRAINT `order_details_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `items` (`id`),
  CONSTRAINT `order_details_ibfk_2` FOREIGN KEY (`order_id`) REFERENCES `orders` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;
CREATE TABLE `order_list` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `isform` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `csrf_test_name` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `special_coupon_applied` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `bn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `fn` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `ln` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `country` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `state` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `zpc` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `city` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `email` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `phone` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `opt` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `host` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci DEFAULT NULL,
  `createtime` timestamp NULL DEFAULT NULL,
  `deal` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=44 DEFAULT CHARSET=utf8;
CREATE TABLE `order_status` (
  `id` int(11) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
CREATE TABLE `orders` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  `address` varchar(300) NOT NULL,
  `description` varchar(300) NOT NULL,
  `date` datetime DEFAULT NULL,
  `payment_type` varchar(16) NOT NULL DEFAULT 'Wallet',
  `total` int(11) NOT NULL,
  `status` varchar(25) NOT NULL DEFAULT 'Yet to be delivered',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `id` (`id`),
  KEY `customer_id` (`customer_id`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
CREATE TABLE `ticket_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `ticket_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `date` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `ticket_id` (`ticket_id`),
  KEY `user_id` (`user_id`),
  CONSTRAINT `ticket_details_ibfk_1` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`),
  CONSTRAINT `ticket_details_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
CREATE TABLE `tickets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `poster_id` int(11) NOT NULL,
  `subject` varchar(100) NOT NULL,
  `description` varchar(3000) NOT NULL,
  `status` varchar(8) NOT NULL DEFAULT 'Open',
  `type` varchar(30) NOT NULL DEFAULT 'Others',
  `date` datetime DEFAULT NULL,
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  KEY `poster_id` (`poster_id`),
  CONSTRAINT `tickets_ibfk_1` FOREIGN KEY (`poster_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `role` varchar(15) NOT NULL DEFAULT 'Customer',
  `name` varchar(15) NOT NULL,
  `username` varchar(64) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `password` varchar(128) CHARACTER SET latin1 COLLATE latin1_swedish_ci NOT NULL,
  `email` varchar(35) DEFAULT NULL,
  `verified` tinyint(1) NOT NULL DEFAULT '0',
  `deleted` tinyint(4) NOT NULL DEFAULT '0',
  `salt` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`),
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
CREATE TABLE `wallet` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `customer_id` (`customer_id`),
  UNIQUE KEY `id` (`id`),
  CONSTRAINT `wallet_ibfk_1` FOREIGN KEY (`customer_id`) REFERENCES `users` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
CREATE TABLE `wallet_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `wallet_id` int(11) NOT NULL,
  `number` varchar(16) NOT NULL,
  `cvv` int(3) NOT NULL,
  `balance` int(11) NOT NULL DEFAULT '2000',
  PRIMARY KEY (`id`),
  UNIQUE KEY `wallet_id` (`wallet_id`),
  UNIQUE KEY `id` (`id`),
  CONSTRAINT `wallet_details_ibfk_1` FOREIGN KEY (`wallet_id`) REFERENCES `wallet` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;
BEGIN;
LOCK TABLES `order`.`items` WRITE;
DELETE FROM `order`.`items`;
INSERT INTO `order`.`items` (`id`,`name`,`price`,`deleted`) VALUES (1, 'Item 1', 25, 1),(2, 'Item 2', 45, 0),(3, 'Item 3', 20, 0),(4, 'Item 4', 15, 1),(5, 'Item 5', 20, 0);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`order_details` WRITE;
DELETE FROM `order`.`order_details`;
INSERT INTO `order`.`order_details` (`id`,`order_id`,`item_id`,`quantity`,`price`) VALUES (1, 1, 2, 2, 90),(2, 1, 3, 3, 60),(3, 2, 2, 2, 90),(4, 2, 3, 2, 40),(5, 3, 2, 2, 90),(6, 3, 3, 2, 40),(7, 4, 2, 2, 90),(8, 4, 3, 2, 40),(9, 5, 2, 5, 225),(10, 5, 3, 2, 40),(11, 5, 5, 1, 20),(12, 6, 2, 5, 225),(13, 6, 3, 3, 60),(14, 6, 5, 2, 40);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`order_list` WRITE;
DELETE FROM `order`.`order_list`;
INSERT INTO `order`.`order_list` (`id`,`isform`,`csrf_test_name`,`special_coupon_applied`,`bn`,`fn`,`ln`,`country`,`state`,`address`,`zpc`,`city`,`email`,`phone`,`opt`,`host`,`createtime`,`deal`) VALUES (30, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy3', '111', '1034', 'CN', 'CN-43', '4105', '456', '456', '5112', '8+55', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(31, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy1', '111', '1034', 'CN', 'CN-43', '4105', '456', '456', '123132', '1111111111111', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(32, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy2', '111', '1034', 'CN', 'CN-43', '4105', '456', '456', '122', '4554', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(33, '1', '05e22eae351e4f9e6936be8ed912ea5e', '1', 'buy2', 'son', 'jack', 'CN', 'CN-34', '固戍', '518000', '深圳', '1361214503@qq.com', '105256525', '·123123', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(34, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy2', 'son', 'jack', 'CN', 'CN-34', '固戍', '518000', '深圳', '1361214503@qq.com', '105256525', '', '192.168.1.18:8081', '2019-10-08 18:49:25', '0'),(35, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy3', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳', '123456@qq.com', '105256525', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(36, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy2', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳', '1361214503@qq.com', '105256525', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(37, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy2', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳', '1361214503@qq.com', '105256525', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(38, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy3', 'son', 'jack', 'CN', 'CN-34', '测试地址', '518000', '广东', '1361214503@qq.com', '105256525', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(39, '1', '05e22eae351e4f9e6936be8ed912ea5e', '1', 'buy2', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳1111111', '1361214503@qq.com', '105256525', '12312321', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(40, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy3', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳qweqweqwe', '1361214503@qq.com', '105256525qweqw', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '0'),(41, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy1', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳1111111', '1361214503@qq.com', '105256525', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '1'),(42, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy3', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳1111111', '1361214503@qq.com', '10525652512321321', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '1'),(43, '1', '05e22eae351e4f9e6936be8ed912ea5e', '0', 'buy3', 'son', 'jack', 'CN', 'CN-34', '广东省深圳市南山区深大', '518000', '深圳1111111', '1361214503@qq.com', '105256525123123', '', '192.168.1.18:8080', '2019-10-08 18:49:25', '1');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`order_status` WRITE;
DELETE FROM `order`.`order_status`;
INSERT INTO `order`.`order_status` (`id`,`title`) VALUES (0, '未处理'),(1, '已处理');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`orders` WRITE;
DELETE FROM `order`.`orders`;
INSERT INTO `order`.`orders` (`id`,`customer_id`,`address`,`description`,`date`,`payment_type`,`total`,`status`,`deleted`) VALUES (1, 2, 'Address 2', 'Sample Description 1', '2017-03-28 17:32:41', 'Wallet', 150, 'Delivered', 0),(2, 2, 'New address 2', '', '2017-03-28 17:43:05', 'Wallet', 130, 'Cancelled by Customer', 1),(3, 3, 'Address 3', 'Sample Description 2', '2017-03-28 19:49:33', 'Cash On Delivery', 130, 'Yet to be delivered', 0),(4, 3, 'Address 3', '', '2017-03-28 19:52:01', 'Cash On Delivery', 130, 'Cancelled by Customer', 1),(5, 3, 'New Address 3', '', '2017-03-28 20:47:28', 'Wallet', 285, 'Paused', 0),(6, 3, 'New Address 3', '', '2017-03-30 00:43:31', 'Wallet', 325, 'Cancelled by Customer', 1);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`ticket_details` WRITE;
DELETE FROM `order`.`ticket_details`;
INSERT INTO `order`.`ticket_details` (`id`,`ticket_id`,`user_id`,`description`,`date`) VALUES (1, 1, 2, 'New Description for Subject 1', '2017-03-30 18:08:51'),(2, 1, 2, 'Reply-1 for Subject 1', '2017-03-30 19:59:09'),(3, 1, 1, 'Reply-2 for Subject 1 from Administrator.', '2017-03-30 20:35:39'),(4, 1, 1, 'Reply-3 for Subject 1 from Administrator.', '2017-03-30 20:49:35');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`tickets` WRITE;
DELETE FROM `order`.`tickets`;
INSERT INTO `order`.`tickets` (`id`,`poster_id`,`subject`,`description`,`status`,`type`,`date`,`deleted`) VALUES (1, 2, 'Subject 1', 'New Description for Subject 1', 'Answered', 'Support', '2017-03-30 18:08:51', 0);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`users` WRITE;
DELETE FROM `order`.`users`;
INSERT INTO `order`.`users` (`id`,`role`,`name`,`username`,`password`,`email`,`verified`,`deleted`,`salt`) VALUES (1, 'Administrator', 'Admin 1', 'root', '54d79d6bfbd7ed94dfb2d47d028d16efba5436a7f9811e93a36d652601681266', '', 1, 0, 'dee5f0fd9ee5'),(2, 'Customer', 'Customer 1', 'user1', 'd24aaa3660879254634ff66f0963d19a76183f1d7c9d0daa1a058b69f5eb4fc2', 'mail2@example.com', 1, 0, '2b2fd925ba2d'),(3, 'Customer', 'Customer 2', 'user2', 'fe09ad13de51d7dd05871084a3884ec957b2f573dd857fcf86134b2acb809f6d', 'mail3@example.com', 1, 0, '5d509b393a15'),(10, 'Administrator', 'Administrator', 'admin', '56b613384c82bef464e37a1b2da805fac00e08d00f563ca8c074aae12c11ffcb', 'none', 0, 0, 'a404d0e68b09'),(18, 'Customer', 'rooter', 'rooter', '23efda5d1d47ad6204a91d0face33b129e6c74e664e53ca43e72f1237d60206d', '123123123', 0, 0, '4404fc087cbf');
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`wallet` WRITE;
DELETE FROM `order`.`wallet`;
INSERT INTO `order`.`wallet` (`id`,`customer_id`) VALUES (13, 18);
UNLOCK TABLES;
COMMIT;
BEGIN;
LOCK TABLES `order`.`wallet_details` WRITE;
DELETE FROM `order`.`wallet_details`;
INSERT INTO `order`.`wallet_details` (`id`,`wallet_id`,`number`,`cvv`,`balance`) VALUES (13, 13, '638856732346512', 824, 2000);
UNLOCK TABLES;
COMMIT;
