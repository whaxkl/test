<?php
    header('Access-Control-Allow-Origin:*');
    include ('routers/arr.php');
    $servername = "localhost";
    $server_user = "root";
    $server_pass = "abc123456";
    $dbname = "orders";
    $con = new mysqli($servername,$server_user,$server_pass,$dbname);
    $data = file_get_contents('php://input');
    $data = get_object_vars(json_decode($data));
    $param['isform'] = $data['isform'];
    $param['csrf_test_name'] = $data['csrf_test_name'];
    $param['special_coupon_applied'] = $data['special_coupon_applied'];
    $param['bn'] = $data['bn'];
    $param['fn'] = $data['fn'];
    $param['ln'] = $data['ln'];
    $param['country'] = $data['country'];
    $param['state'] = $data['state'];
    $param['address'] = $data['address'];
    $param['zpc'] = $data['zpc'];
    $param['city'] = $data['city'];
    $param['email'] = $data['email'];
    $param['phone'] = $data['phone'];
    $param['opt'] = $data['opt'];
    $param['host'] = $data['host'];
    $param['createtime'] = $data['createtime'];
    $param['deal'] = 0;
foreach ($param as $k=>$v)
    {
        $k1[] = '`'.$k.'`';
        $v1[] = '"'.$v.'"';
    }
    $strv.=implode(',',$v1);
    $strk.=implode(",",$k1);
    $result = "INSERT INTO order_list($strk) values ($strv)";
    if($con->query($result) == true){
        exit(json_encode(['code'=>1,'msg'=>'Successful submission, we will ship as soon as possible!']));
    }else{
         exit(json_encode(['code'=>-1,'msg'=>'Submission error,please try for a later!']));
    }





















