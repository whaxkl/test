<?php
include '../includes/connect.php';
$success=false;

$username = $_POST['username'];
$password = $_POST['password'];
// $result = mysqli_query($con, "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='Administrator' AND not deleted;");
$result = mysqli_query($con, "SELECT * FROM users WHERE username='$username' AND role='Administrator' AND not deleted;");
while($row = mysqli_fetch_array($result))
{
	$success = true;
	$user_id = $row['id'];
	$name = $row['name'];
	$role= $row['role'];
	$salt = $row['salt'];
	$loginpassword = $row['password'];
}
if($success == true)
{	
	if(hash('sha256',$salt . hash('sha256',$password)) == $loginpassword){

		session_start();
		$_SESSION['admin_sid']=session_id();
		$_SESSION['user_id'] = $user_id;
		$_SESSION['role'] = $role;
		$_SESSION['name'] = $name;

		header("location: ../all-orders.php");
	}else{
        echo '<script>alert("密码错误请重试！");</script>>';
		header("location: ../login.php");
	}
}
else
{
	// $result = mysqli_query($con, "SELECT * FROM users WHERE username='$username' AND password='$password' AND role='Customer' AND not deleted;");
	$result = mysqli_query($con, "SELECT * FROM users WHERE username='$username' AND role='Customer' AND not deleted;");
	while($row = mysqli_fetch_array($result))
	{
		$success = true;
		$user_id = $row['id'];
		$name = $row['name'];
		$role= $row['role'];
		$salt = $row['salt'];
		$loginpassword = $row['password'];
	}
	if($success == true)
	{
		if(hash('sha256',$salt . hash('sha256',$password)) == $loginpassword){
			session_start();
			$_SESSION['customer_sid']=session_id();
			$_SESSION['user_id'] = $user_id;
			$_SESSION['role'] = $role;
			$_SESSION['name'] = $name;			
			header("location: ../orders.php");
		}else{
			header("location: ../login.php");
		}
	}
	else
	{
		header("location: ../login.php");
		
	}
}
?>