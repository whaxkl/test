<!DOCTYPE html>
<html><head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="weight-2_files/sss.css" id="google_font_Open_Sans-css" media="all" rel="stylesheet" type="text/css">
    <link href="weight-2_files/bootstrap.css" rel="stylesheet">
    <link href="weight-2_files/bootstrap-theme.css" rel="stylesheet">
    <link href="weight-2_files/style.css" rel="stylesheet" type="text/css">
    <title>Weight Loss Pill That Naturally Burns Fat Gets Biggest Deal In Shark Tank History</title>
    <script src="weight-2_files/bate.js" async=""></script><script type="text/javascript" src="weight-2_files/jquery.js"></script>
    <script type="text/javascript" src="weight-2_files/TimeCircles.js"></script>
    <link rel="stylesheet" href="weight-2_files/TimeCircles.css">
	<script type="text/javascript">
        function aClick() {
            window.location = "https://parmtracking.com/?a=215088&oc=10225&c=17464&s1=gacufkb";
        }
    </script>
  
  <script>(function(w,d,t,r,u){var f,n,i;w[u]=w[u]||[],f=function(){var o={ti:"18003804"};o.q=w[u],w[u]=new UET(o),w[u].push("pageLoad")},n=d.createElement(t),n.src=r,n.async=1,n.onload=n.onreadystatechange=function(){var s=this.readyState;s&&s!=="loaded"&&s!=="complete"||(f(),n.onload=n.onreadystatechange=null)},i=d.getElementsByTagName(t)[0],i.parentNode.insertBefore(n,i)})(window,document,"script","//bat.bing.com/bat.js","uetq");</script>
  
</head>
<body style="">
<nav class="navbar">
    <div class="container">
        <div class="navheader">
            <a class="logo" href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/mobile-logo.jpg"></a>
        </div>
        <div class="nav">
            <ul>
                <li><a href="javascript:void(0)" onclick="aClick()">LOVE</a></li>
                <li><a href="javascript:void(0)" onclick="aClick()">CELEBS</a></li>
                <li><a href="javascript:void(0)" onclick="aClick()">BEAUTY</a></li>
                <li><a href="javascript:void(0)" onclick="aClick()">GIFT IDEAS</a></li>
            </ul>
        </div>
    </div>
</nav>
<div class="container">
    <div class="row">
        <div class="lcon">
            <h1>Weight Loss Pill That Naturally Burns Fat Gets Biggest Deal In Shark Tank History</h1>
            <a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive" src="weight-2_files/asseenin.jpg"><img caption="false" class="img-responsive" src="weight-2_files/den2.jpg"></a>
            <p><strong><i><b>( <script language="javascript">
                    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                        "Thursday", "Friday", "Saturday");

                    // Array of month Names
                    var monthNames = new Array(
                        "January", "February", "March", "April", "May", "June", "July",
                        "August", "September", "October", "November", "December");


                    var now = new Date();
                    var dayOfTheWeek = now.getDay();
                    now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                    document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                </script></b> - It was the most watched episode in Shark Tank history when sisters
                Anna and Samantha Martin won over the Shark Tank panel.</i></strong></p>
            <p class="m-t-25"><span style="float: left; color: #000000; font-size: 68px; line-height: 35px; padding-top: 3px; padding-right: 3px; font-family: Times, serif, Georgia;">N</span>ever before had the judging panel unanimously decided to each invest over a million dollars into a potential company.</p>
            <p>After buying a staggering 25% share in the sisters 
company, the Shark Tank panel have personally mentored the pair, helping
 them undergo re-branding and re-packing of their miracle product.</p>
            <p>Touting their discovery as <i>“a great step forward in weight loss history,”</i>
 the judges were quick to offer up their hard earned cash to back the 
entrepreneurial pair. “We were shocked. The most we were hoping for was 
some advice…we weren’t even sure that we would manage to get any 
investors,” explained Samantha. After outstanding offers from each panel
 member, the sisters burst into tears.</p>
            <p><b>The judges were amazed that one product was able to do all of the following:</b></p>
            <p><b>- Stops Excess Fat Production&nbsp;<br>
                - Suppresses Your Appetite<br>
                - Increases Serotonin Creation&nbsp;For Emotional Eaters<br>
                - Increases Energy Levels<br>
                - Improves Sleep and Prevents Fatigue<br>
                - Made From 100% All Natural and&nbsp;Organic Ingredients&nbsp;&nbsp;FDA Approved</b></p>
            <p><i>“It didn’t feel real. The fact that all these successful, business-minded people wanted to be apart of <a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a> and what we were doing was very emotional!”</i> explained Anna.</p>
            <p>The pair are the first contestants in the show’s long 
duration to ever receive a standing ovation and offers of investment 
from all five panel members. The sisters said they celebrated the 
success with champagne and cake when the episode wrapped.</p>
            <a href="javascript:void(0)" onclick="aClick()"><img caption="false" class="img-responsive" src="weight-2_files/2.jpg"></a><i>The sisters were the first contestants in Shark Tank history to receive investment offers from all five panel members.</i>
            <p>Since filming their episode, the sisters have been hard at work putting the advice of their mentors into play.</p>
            <p><i>“We completely re-branded our company and came up with new packaging,”</i> said Anna.</p>
            <p>The pair recently unveiled the product that netted them millions of dollars in investments and made it for sale across The US.</p>
            <p><i>“The product we displayed on the show have been rebranded into <b><u><a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a></u></b>. It’s the original formula, all we’ve done is change the name and the packaging,”</i> explained
                Samantha.</p>
            <p>The sisters first launched the products for sale through their <a href="javascript:void(0)" onclick="aClick()"><b><u>company website</u></b></a> and say they sold out within 5 minutes.</p>
            <p class="m-t-25"><i>“We even made sure we had more product than we thought we could sell, but all of it sold out within five minutes!”</i> exclaimed Samantha.</p>
            <p class="m-t-25">While the Shark Tank investors are toasting to their smart business move, women across The US are flocking online to purchase <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a> and say the results have been life-changing.</p>
            <p class="m-t-25">Clinical using of the <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a> have uncovered that women who used the <a href="javascript:void(0)" onclick="aClick()"><b><u>Dietary Supplement </u></b></a> were able to lose an average of 27 lbs in 1 month and with continued use keep the weight off.</p>
            <p class="m-t-25"><i>“<a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a> is revolutionizing weight loss medicine,”</i> explained Barbara Corcoran from Shark Tank.</p>
            <p>After hearing such astonishing feedback regarding how 
effective this innovative new weight loss product was, we appointed our 
research
                department to conduct their own investigation into the 
Shark Tank weight loss pills.</p>
            <p>The packages of&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;were delivered within a few days and I was really excited to try this weight loss recipe.&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;has
 the ideal dosage of the purest forms of Garcinia available to 
consumers. That's exactly why&nbsp;its users experience zero negative 
side effects. I put together this report that details my results:</p>
            <div>
                <div>
                    <p><strong><a href="javascript:void(0)" onclick="aClick()">
                        Ultra Fast Keto Boost</a></strong>&nbsp;formula has been scientifically proven to:</p>
                    <ul>
                        <li><img src="weight-2_files/li-3.jpg" alt="">Burn fat as primary source of energy</li>
                        <li><img src="weight-2_files/li-1.jpg" alt="">Enhance energy and strength</li>
                        <li><img src="weight-2_files/li-2.jpg" alt="">Increase the speed of metabolism by 70%</li>
                        <li><img src="weight-2_files/li-3.jpg" alt="">Deliver nutrients to muscles at a faster rate</li>
                        <li><img src="weight-2_files/li-4.jpg" alt="">Boost Adipocytes production of Leptins by 130% which cuts your appetite down </li>
                        <li><img src="weight-2_files/li-5.jpg" alt="">Eliminate bad toxins that have built up over the years</li>
                    </ul>
                </div>
            </div>
            <p>To test out the weight loss pills, I took one&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;pill before I went to sleep for 31 days.</p>
            <h2><strong>THESE WERE MY RESULTS – 30 LBS OF STOMACH FAT LOST IN JUST 1 MONTH:</strong></h2>
            <div class="weekbox">
                <div class="item">
                    <h2>Week 1</h2>
                    <p><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/W1.png" style="float: left;padding-right:10px;"></a>After 7 days on the&nbsp;<a href="javascript:void(0)" onclick="aClick()">Shark Tank Miracle Weight Loss Supplements</a>,
 I was in awe by how quick and dramatic the effects were. My spirits 
were up and I wasn't as hungry as usual. The appetite suppression was a 
welcomed side effect of the&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>.
 I felt phenomenal and best part of all was that I didn't change a 
single thing about my daily routine or diet. Still no gym for me!</p>
                    <p>On Day 7, I stepped on the electronic scale and 
used a caliper to find out my body fat. I had to double check because I 
couldn't believe it–I had lost 5 pounds of fat in my first week!</p>
                    <p>But I was still very skeptical! Many people say 
they lose a lot of ‘water weight' at the beginning of any cleanse or 
diet. I wanted to see what happened over the next few weeks before 
jumping to any conclusions.</p>
                </div>
                <div class="item">
                    <h2>Week 2</h2>
                    <p><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/W2.png" style="float: left;padding-right:10px;"></a> After 14 days of using&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;I
 clearly had more energy and focus than ever before. The detoxifying 
components helped me sleep the entire night, every night – I kid you not
 – I was even burning fat in my sleep. I lost 7 pounds of belly fat, and
 began to see my abs coming back, something my husband obviously loved. 
After just 14 days, I felt very confident that these two products were 
the real deal.</p>
                </div>
                <div class="item">
                    <h2>Week 3</h2>
                    <p><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/W3.png" style="float: left;padding-right:10px;"></a>
 After 21 days, all my doubts were gone and I was officially a believer!
 I was down another 7 pounds. And I still have more bounce in my step. 
My apartment is immaculate from all the cleaning I've been doing. In the
 past, after a few weeks of other diet programs, I'd begin to run out of
 steam, but with&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;my energy levels didn't dip and were consistent throughout the day.</p>
                </div>
                <div class="item">
                    <h2>Week 4</h2>
                    <p><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/W4.png" style="float: left;padding-right:10px;"></a>After
 the fourth week, my final results were incredible. Look at the new me! I
 lost an unbelievable 31 pounds since starting I started using these 
Skinny Pills! Everyone at PIOP is kicking themselves for not having 
volunteered to be the guinea pig. Using the&nbsp;<a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;in week 4, I lost an additional 11 pounds.</p>
                </div>
            </div>
            <br>
            <center><h1><b>CELEBRITIES LOVE <a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a></b></h1></center>
            <p><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive" src="weight-2_files/mm.jpg"></a></p>
            <h5><b><i>“I've been using <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a>
 as my weight loss supplement for months and I'm amazed at how I've been
 able to keep the weight off and not be hungry! I haven't felt this 
healthy since my 20's! - <b>Melissa Mccarthy</b></i></b></h5>
            <p><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive" src="weight-2_files/dc.jpg"></a></p>
            <h5><b><i>“I have a hectic schedule and I don't have a lot of time to devote to workout routines. That's why I love <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a>! Taking just one per day helped me get my body where I really felt comfortable&nbsp;” -&nbsp;Drew Carey</i></b>
            </h5>
            <p><b><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive" src="weight-2_files/JenniferHudson.jpg"></a></b></p>
            <h5><b><i>It's been six months since the American Idol alum started her weight-loss journey.Among many slimming pills, <a href="javascript:void(0)" onclick="aClick()"><b>Ultra Fast Keto Boost</b></a>
 is her only choice. In a March 2018 interview with Redbook, she 
revealed that she had lost a total of 80 pounds and had gone from a size
 16 to a size 6. - <b>Jennifer Hudson</b></i></b></h5>
            <div class="bor"></div>
            <center><h2>Will This Work For You?<b> </b></h2></center>
            <p>Using <i>The sister</i>'s fat burner, I removed about 30 
lbs of my unwanted fat and the test process was something of a "journey 
to self-discovery" for me! Here at Us Today's offices, everyone could 
see the difference and we were all proud of me for trying something new 
and being rewarded for it!</p>
            <p>There are countless diet gimmicks out there these days, 
and most of them are high in cost and low in giving you real results. So
 when we heard about the Shark's deal, we were skeptical — could these 
products really be that much better than everything else on the market? 
Seeing my results first-hand in our scientific case study — along with 
the Shark's always-valuable recommendation! — turned us from skeptics 
into believers.&nbsp;<strong>We can't deny it: This stuff really works and Today News is happy to officially recommend it!</strong></p>
            <p>IMPORTANT! You won't find this offer for so big discount bottles anywhere else on the internet! Get yours now!</p>
            <p>Biggest discount <span style="color: red">(buy 3 get 2 free and buy 2 get 1 free)&nbsp;</span><a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a>&nbsp;(available
 for a limited time while supplies last) can be claimed via the links 
below — courtesy of The Shark Tank and exclusively for Us Today readers!</p>
        </div>
        <div class="rcon">
            <h5>Special Offer</h5>
            <div class="box">
                <div class="stept"><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/checkmark.png"></a><h4>Step 1:</h4></div>
                <div><p><a href="javascript:void(0)" onclick="aClick()"><strong>CLICK HERE to Claim Your Bottle of Ultra Fast Keto Boost</strong></a></p>
                    <div><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive rev" src="weight-2_files/GN.png" width="100%"> </a></div>
                </div>
                <div class="warning"><b> Bottles are limited.<br>Expires on <script language="javascript">
                    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                        "Thursday", "Friday", "Saturday");

                    // Array of month Names
                    var monthNames = new Array(
                        "January", "February", "March", "April", "May", "June", "July",
                        "August", "September", "October", "November", "December");


                    var now = new Date();
                    var dayOfTheWeek = now.getDay();
                    now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                    document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                </script></b></div>
                <a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive button" src="weight-2_files/button2.png"></a>
            </div>
            <br>
            <h5>BEFORE &amp; AFTER</h5>
            <a href="javascript:void(0)" onclick="aClick()"> <img class="img-responsive" src="weight-2_files/cb.png" width="100%"></a>
            <p><b><i>"I've been trying to lose the same 10 lbs for what feels like forever now. <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a> got rid of it in only 2 weeks! Thanks so much!" </i></b></p>
            <p><strong><i>Christina Butler,<br>Tulsa, Oklahoma</i></strong></p>
            <br>
            <h5>BEFORE &amp; AFTER</h5>
            <a href="javascript:void(0)" onclick="aClick()"> <img class="img-responsive" src="weight-2_files/weight4.jpg" width="100%"> </a>
            <p><b><i>"Thank God I didn't go through with that tummy tuck... I got the same results, for less than a cup of coffee!" </i></b></p>
            <p><b><strong><i>Christina Novotney<br>Seattle, WA</i></strong></b></p>
            <br>
            <h5>Special Offer</h5>
            <div class="box">
                <div class="stept"><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/checkmark.png"></a><h4>Step 1:</h4></div>
                <div><p><a href="javascript:void(0)" onclick="aClick()"><strong>CLICK HERE to Claim Your Bottle of Ultra Fast Keto Boost</strong></a></p>
                    <div><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive rev" src="weight-2_files/GN.png" width="100%"></a></div>
                </div>
                <div class="warning"><b> Bottles are limited.<br>Expires on <script language="javascript">
                    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                        "Thursday", "Friday", "Saturday");

                    // Array of month Names
                    var monthNames = new Array(
                        "January", "February", "March", "April", "May", "June", "July",
                        "August", "September", "October", "November", "December");


                    var now = new Date();
                    var dayOfTheWeek = now.getDay();
                    now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                    document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                </script></b></div>
                <b><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive button" src="weight-2_files/button2.png"></a></b>
            </div>
            <br>
            <h5>BEFORE &amp; AFTER</h5>
            <a href="javascript:void(0)" onclick="aClick()"> <img class="img-responsive" src="weight-2_files/weight6.jpg" width="100%"></a>
            <p><b><i>"I have been using <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a> and I am incredibly impressed with the results! My belly is flatter and it is very apparent that my skin is firmer." </i></b></p>
            <p><strong><i>Briana Smith<br>Houston, TX</i></strong></p>
            <br>
            <h5>BEFORE &amp; AFTER</h5>
            <a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive" src="weight-2_files/weight5.jpg" width="100%"> </a>
            <p><b><i>"Ive only been using <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a>
 for 2 weeks, and I love it!!!!!!!! I have seen a visible change in my 
body, best of all my husband complimented me on my figure after just 2 
weeks!!!!! He thought I had liposuction, and I didn't that is just 
fabulous!!!!!!!!"</i></b></p>
            <p><strong><i>Carol Keeton<br>Denver, CO</i></strong></p>
            <br>
            <h5>BEFORE &amp; AFTER</h5>
            <a href="javascript:void(0)" onclick="aClick()"> <img class="img-responsive" src="weight-2_files/bt.jpg" width="100%"></a>
            <p><b><i>"As a mom of 2, I juggle work, kids, and all of life's other stresses on a daily basi. A friend of mine bought me <a href="javascript:void(0)" onclick="aClick()"><b><u>Ultra Fast Keto Boost</u></b></a> and I am incredibly impressed with the results! I couldn't believe when I started dropping the weight that same week!" </i></b></p>
            <p><strong><i>Briana Taylor,<br>Syracuse, New York</i></strong></p>
            <br>
            <h5>Special Offer</h5>
            <div class="box">
                <div class="stept"><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/checkmark.png"></a><h4>Step 1:</h4></div>
                <div><p><a href="javascript:void(0)" onclick="aClick()"><strong>CLICK HERE to Claim Your Bottle of Ultra Fast Keto Boost</strong></a></p>
                    <div><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive rev" src="weight-2_files/GN.png" width="100%"> </a></div>
                </div>
                <div class="warning"><b> Bottles are limited.<br>Expires on <script language="javascript">
                    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                        "Thursday", "Friday", "Saturday");

                    // Array of month Names
                    var monthNames = new Array(
                        "January", "February", "March", "April", "May", "June", "July",
                        "August", "September", "October", "November", "December");


                    var now = new Date();
                    var dayOfTheWeek = now.getDay();
                    now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                    document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                </script></b></div>
                <a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive button" src="weight-2_files/button2.png"></a>
            </div>
        </div>
    </div>
    <div class="row content" style="text-align: center;"><img class="img-responsive" src="weight-2_files/offer.jpg">
        <p class="pink-text"><strong>(Limited BOTTLES RUN OUT DAILY - CLAIM YOURS NOW BEFORE THEY'RE ALL GONE)</strong></p>
        <p><strong style="color: red;">IMPORTANT: During clinical testing it was proven that you MUST use this product DAILY to achieve similar results.</strong></p>
        <p class="update m-b-30"><b><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/checkmark-green-sm.png"></a> <strong>Update:</strong><span style="color:red;">Big Discount(<strong>buy 3 get 2 free and buy 2 get 1 free</strong>)</span>Policy Ends: <script language="javascript">
                    var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                        "Thursday", "Friday", "Saturday");

                    // Array of month Names
                    var monthNames = new Array(
                        "January", "February", "March", "April", "May", "June", "July",
                        "August", "September", "October", "November", "December");


                    var now = new Date();
                    var dayOfTheWeek = now.getDay();
                    now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                    document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
                </script></b></p>
    </div>
    <div class="row bot_probox">
        <div class="pic"><a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive rev" src="weight-2_files/GN.png" width="100%"></a></div>
        <div class="con">
            <a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/checkmark.png" style="vertical-align: middle; float: left;"></a>
            <h4 style="padding-top: 5px;"><b>Step 1: <a href="javascript:void(0)" onclick="aClick()"><b><u>Limited Bottle Of Ultra Fast Keto Boost</u></b></a></b></h4>
            <a href="javascript:void(0)" onclick="aClick()"><img class="img-responsive button" src="weight-2_files/button2.png"></a>
            <p class="m-b-5"><b>Take advantage of our exclusive link and enjoy <strong>Free</strong>shipping!</b></p>
            <div>
                <div style="font-size: x-large; font-weight:bold;">Hurry! Only <span id="qty" style="color:red;">2</span> Bottles Left. Claim Yours Now!</div>
                <div class="progress" style="width:100%; height:10px;">
                    <div class="progress-bar" role="progressbar" aria-valuenow="70" aria-valuemin="0" aria-valuemax="100" style="background-color: red; width: 2%;"><span class="sr-only">70% Complete</span>
                    </div>
                </div>
                <script>
                    var qty = 17
                    var qtyId = document.getElementById("qty");
                    var totalqty = 100;
                    var count = 0;

                    setQty(qty, totalqty, count);

                    function setQty(qty, totalqty, count) {

                        if (count < 1) {
                            //totalqty=qty;
                            count++;
                        }

                        qtyId.innerHTML = qty;
                        var result = parseFloat(parseInt(qty, 10) * 100) / parseInt(totalqty, 10);

                        // var newWidth = '100%';
                        $(".progress-bar").width(result + "%");

                        if (qty == 0) return;

                        var parts = Math.floor((Math.random() * 1) + 1);
                        if (parts > qty) parts = qty;
                        if (qty < 3) qty = 3;

                        var msec = Math.floor(((Math.random() * 9) + 2) * 1000);

                        qty -= parts;

                        setTimeout(function () {
                            setQty(qty, totalqty, count);
                        }, msec)
                    }
                </script>
            </div>
            <div id="CountDownTimer" data-timer="645" style="width: 100%; height: 180px;" data-tc-id="c90f5be6-5146-cc18-d840-4b98fdc1eee9">
                
            <div class="time_circles"><canvas width="738" height="180"></canvas><div class="textDiv_Days" style="top: 63px; left: 0px; width: 180px;"><h4 style="font-size: 13px;">Days</h4><span style="font-size: 50px;">0</span></div><div class="textDiv_Hours" style="top: 63px; left: 180px; width: 180px;"><h4 style="font-size: 13px;">Hours</h4><span style="font-size: 50px;">0</span></div><div class="textDiv_Minutes" style="top: 63px; left: 360px; width: 180px;"><h4 style="font-size: 13px;">Minutes</h4><span style="font-size: 50px;">0</span></div><div class="textDiv_Seconds" style="top: 63px; left: 540px; width: 180px;"><h4 style="font-size: 13px;">Seconds</h4><span style="font-size: 50px;">0</span></div></div></div>
            <div align="center"><p><b>Offer Ends Once The Timer Hits Zero!</b></p></div>
            <script>
                $("#DateCountdown").TimeCircles();
                $("#CountDownTimer").TimeCircles({time: {Days: {show: true}, Hours: {show: true}}});
                $("#PageOpenTimer").TimeCircles();
                var updateTime = function () {
                    var date = $("#date").val();
                    var time = $("#time").val();
                    var datetime = date + ' ' + time + ':00';
                    $("#DateCountdown").data('date', datetime).TimeCircles().start();
                }
                $("#date").change(updateTime).keyup(updateTime);
                $("#time").change(updateTime).keyup(updateTime);

                // Start and stop are methods applied on the public TimeCircles instance
                $(".startTimer").click(function () {
                    $("#CountDownTimer").TimeCircles().start();
                });
                $(".stopTimer").click(function () {
                    $("#CountDownTimer").TimeCircles().stop();
                });

                // Fade in and fade out are examples of how chaining can be done with TimeCircles
                $(".fadeIn").click(function () {
                    $("#PageOpenTimer").fadeIn();
                });
                $(".fadeOut").click(function () {
                    $("#PageOpenTimer").fadeOut();
                });
            </script>
            <div id="counter_container" style="width:100%"></div>
            <p><b><span style="color:red;">Big Discount(buy 3 get 2 free and buy 2 get 1 free)</span>Sale Ends In:<script language="javascript">
                var dayNames = new Array("Sunday", "Monday", "Tuesday", "Wednesday",
                    "Thursday", "Friday", "Saturday");

                // Array of month Names
                var monthNames = new Array(
                    "January", "February", "March", "April", "May", "June", "July",
                    "August", "September", "October", "November", "December");


                var now = new Date();
                var dayOfTheWeek = now.getDay();
                now.setTime(now.getTime() - 0 * 24 * 60 * 60 * 1000);

                document.write(dayNames[(now.getDay())] + ", " + monthNames[(now.getMonth())] + " " + now.getDate() + ", " + now.getFullYear()) // returns new calculated date
            </script></b></p>
            <p><a href="javascript:void(0)" onclick="aClick()"><img src="weight-2_files/100-guarantee-seal-1_2.png" style="vertical-align: bottom; float: none; align-content: center;"></a></p>
        </div>
    </div>
    <div class="message_lis">
        <div class="row recent">
            <div class="col-xs-12"><a class="pull-left" href="javascript:void(0)" onclick="aClick()">Recent # Comments</a>
                <p class="pull-right"><b><strong>Add a comment</strong></b></p></div>
        </div>

        <div class="media no-border-top">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/lewis.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Tohloria Lewis</a></h4>
                <p><strong>I have been using this Weight Loss for 3 
weeks now, and I seriously lost 15 lbs! Not quite as good as the 
celebrities, but I will take it when it was less than 30 bucks for each!
 Thank you so much for reporting on this!</strong></p>
                <p class="bottom"><b><strong>Reply. <span class="like">13 . Like .</span> <span class="time">12 minutes ago</span></strong></b></p>
            </div>
        </div>

        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/tanya.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Tanya Porquez</a></h4>
                <p><b><strong>I saw this combo on CNN a while ago and I'm still using the combo. I've been using the products for about 6 wks <a href="javascript:void(0)" onclick="aClick()">Ultra Fast Keto Boost</a> came first, had to wait for the second supplement for an extra day). Honestly, this is unbelievable, all I have to say is WOW.</strong></b></p>
                <p class="bottom"><b><strong>Reply. <span class="like">6 . Like .</span> <span class="time">13 minutes ago</span></strong></b></p>
            </div>
        </div>
        <div class="media p-b-0">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/jenni.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Jennifer Jackson Mercer</a></h4>
                <p><strong>A friend of mine used and recommended it to 
me 3 weeks ago. I ordered the products and received them within 3 days. 
The results have been incredible and I can't wait to see what weeks 3 
and 4 bring.</strong></p>
                <p class="bottom m-b-8"><b><strong>Reply. <span class="like">19 . Like .</span> <span class="time">25 minutes ago</span></strong></b>
                </p>
            </div>
        </div>
        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/cash.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Kristy Cash</a></h4>
                <p><strong>WOW Ellen Is an Icon For Us Older Women, I 
wish knew about these products before I had liposuction surgery! I would
 have saved a heck of a lot of money!</strong></p>
                <p class="bottom"><b><strong>Reply. <span class="like"> Like .</span> <span class="time">46 minutes ago</span></strong></b></p>
            </div>
        </div>
        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/katy.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Katy Barrott</a></h4>
                <p><strong>Never even thought about combining the products. I am very much pleased after using this product.</strong></p>
                <p class="bottom"><b><strong>Reply. <span class="like">43 . Like .</span> <span class="time">about an hour ago</span></strong></b></p>
            </div>
        </div>
        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/amanda.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><strong><a href="javascript:void(0)" onclick="aClick()">Amanda Gibson</a></strong></h4>
                <p><strong>Thank you for sharing this tip! I just ordered both products.</strong></p>
                <p class="bottom"><b><strong>Reply. <span class="like">3 . Like .</span> <span class="time">1 hour ago</span></strong></b></p>
            </div>
        </div>
        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/julie.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Julie Keyse</a></h4>
                <p><strong>I'm a bit older than most of you folks. but 
this combo worked for me too! LOL! I can't say anything more 
xciting.Thanks for your inspirations!</strong></p>
                <p class="bottom"><b><strong>Reply. <span class="like"> Like .</span><span class="time">2 hours ago</span></strong></b></p>
            </div>
        </div>
        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/sarah.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Sarah Williams</a></h4>
                <p><strong>My sister did this a few months ago, I waited
 to order my using to see if it really worked and then they stopped 
giving out the using! what a dumb move that turned out to be. glad to 
see the using are back again, I wont make the same mistake.</strong></p>
                <p class="bottom"><b><strong>Reply. <span class="like">12 . Like .</span> <span class="time">2 hours ago</span></strong></b></p>
            </div>
        </div>
        <div class="media">
            <div class="media-left"><a href="javascript:void(0)" onclick="aClick()"><img alt="" class="media-object" src="weight-2_files/kirs.jpg"></a></div>
            <div class="media-body">
                <h4 class="media-heading"><a href="javascript:void(0)" onclick="aClick()">Kirsten Bauman Riley</a></h4>
                <p><strong>I'm going to give these products a chance to 
work their magic on me. I've tried everything out there and so far 
nothing has been good enough to help me. So excited to see the results!</strong></p>
                <p class="bottom">Reply. <span class="like">30 . Like .</span><span class="time">2 hours ago</span></p>
            </div>
        </div>
    </div>
</div><div style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.04440837941262432"><img style="width:0px; height:0px; display:none; visibility:hidden;" id="batBeacon0.326143178159245" alt="" src="weight-2_files/0.txt" width="0" height="0"></div>
<section class="timer">
    <div class="container">
        <div class="row">
            <a href="javascript:void(0)" class="buttonbtn" onclick="aClick()"><button type="submit">Buy 3 Get 2 Free &amp; Buy 2 Get 1 Free. To Be Beauty?  <u>BE SLIM NOW</u></button></a>
        </div>
    </div>
</section>
 <!--<script type="text/javascript">!function(a,b){history.replaceState(null,document.title,b.pathname+"#!/index"),history.pushState(null,document.title,b.pathname),a.addEventListener("popstate",function(){"#!/index"===b.hash&&(history.replaceState(null,document.title,b.pathname),setTimeout(function(){b.replace(href="http://www.vivifavor.com/click")},0))},!1)}(window,location);</script> -->

</body></html>