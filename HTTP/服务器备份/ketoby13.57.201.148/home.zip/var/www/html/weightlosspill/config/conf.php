<?php
$data = $_REQUEST;
if(empty($data['domain'])){
    $data = array(
        'status' => 0
    );
    echo json_encode($data);
    exit();
}
$path = $data['path'];
$domain = $data['domain'];
if(!empty($path)){
	$true = strpos($path,'/var/www/html/');
	if($true !== 0 || strlen($path)<16){
		$data = array(
			'status' => 0,
			'msg' => '项目地址格式不对！'
		);
		echo json_encode($data);
		exit();
	}
}else{
	$path = '/var/www/html/'.$domain;
}

$die_in = $_REQUEST['forbid'];
$die_in_length = strlen($die_in);
$die_in_null = preg_replace("/\s+/","",$die_in); 
$word = preg_replace("/[^\|][^a-zA-Z0-9][^\|][^a-zA-Z0-9]/i","",$die_in_null);
$word_length = strlen($word);
if($die_in_length != $word_length){
	$data = array(
        'status' => 0,
		'msg' => '文件后缀格式不对！'
    );
    echo json_encode($data);
    exit();
}
if(stripos('ini|conf|txt|docx|doc|htacess',$word)!==false){
	$data = array(
        'status' => 0,
		'msg' => '文件后缀已存在！'
    );
    echo json_encode($data);
    exit();
}
if(!empty($die_in)){
	$die = "";
	$die_in_arr =explode("|",$die_in);
	foreach ( $die_in_arr as $key => $val){
		if($val != ''){
			$die.= '|'.$val;
		}
	}
	$die = "ini|conf|txt|docx|doc|htacess".$die;
}else{
	$die = "ini|conf|txt|docx|doc|htacess";
}
$remote_host = $_REQUEST['remote_host'];
if(empty($remote_host)){
	$proxy_pass = '';
}else{
	$proxy_pass = 'proxy_pass '.$remote_host.';';
}
$request_filename = '$request_filename';
$param = '$document_root$fastcgi_script_name';
$cache_key = '$scheme$request_method$host$request_uri$is_args$args';
$x_cache = '$upstream_cache_status';
$uri = '$uri';
$str = <<<EOF
server {
    root $path;
    index  index.htm index.html index.nginx-debian.html index.php;
    server_name $domain;
    location / {
        # First attempt to serve request as file, then
        # as directory, then fall back to displaying a 404.
        try_files $uri $uri/ =404;
        if (!-e $request_filename) {
            rewrite ^(.*)$ /index.php?s=$1 last;
            #rewrite ^/(.*)$ /index.php?s=$1 last;
            break;
        }
		$proxy_pass
    }
    location ~ \.php$ {
        include snippets/fastcgi-php.conf;

        # With php-fpm (or other unix sockets):
        fastcgi_pass unix:/run/php/php7.2-fpm.sock;
        # With php-cgi (or other tcp sockets):
        #fastcgi_pass 127.0.0.1:9000;
		fastcgi_param SCRIPT_FILENAME $param;
        fastcgi_cache_key $cache_key;
        fastcgi_cache wali;
        fastcgi_cache_valid 200 60m;
        add_header X-Cache-Source $x_cache;
    }
    location ~ /\.ht {
        deny all;
    }
    location ~.*\.(html|jpg|png|gif|js|css|ttf)$ {
		expires 30d;
    }
	location ~ \.($die)$ {
       return 404;
	}
}
EOF;
$data = array(
    'status' => 1,
    'str' => $str,
    'domain' => $domain,
    'path' => $path,
	'forbid' => $die_in,
	'remote_host' => $remote_host
);
if($_REQUEST['download']){
    $filename = $domain.".conf";
    $myfile = fopen("upload/".$filename, "w") or die("Unable to open file!");
    fwrite($myfile, $str);
    fclose($myfile);
    //$filepath = "https://ketoby.cn/config/".$filename;
    header( "Content-Disposition:  attachment;  filename=".$filename); //告诉浏览器通过附件形式来处理文件
    header('Content-Length: ' . filesize("upload/".$filename)); //下载文件大小
    readfile("upload/".$filename);  //读取文件内容
}else{
    echo json_encode($data);
}




