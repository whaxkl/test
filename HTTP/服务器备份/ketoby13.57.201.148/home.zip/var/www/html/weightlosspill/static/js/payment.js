 $(".Table_Details").change(function (e) {
    $('html, body').animate({
        scrollTop: $(".scroll2").offset().top
    }, 2000);

});