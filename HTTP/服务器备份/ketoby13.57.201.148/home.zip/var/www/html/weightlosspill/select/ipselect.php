<?php
header("Access-Control-Allow-Origin: *");
require "../ip2region-master/Ip2Region.php";
$ip = $_REQUEST['ip'];
$ip_path = new \Ip2Region();
$info = $ip_path->btreeSearch($ip);
$urls = 'https://way.jd.com/RTBAsia/nht';
$params = array(
    'ip' => $ip,
    'appkey' => '0c9dcdb71a0bc11ff55e794ec2f6e2d3'
);
$zhenren = json_decode(wx_http_request($urls, $params),true);
$data = array(array(
    'ip' => $ip,
    'ip_address' => $info['region'],
    'trueman' => $zhenren['result']['data']['score']
));
echo json_encode(['code'=>0,'msg'=>'','limit'=>1000,'data'=>$data,'count'=>100]);
function wx_http_request($url, $params, $body="", $isPost=false, $isImage=false ) {
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    curl_setopt($ch, CURLOPT_URL, $url."?".http_build_query($params));
    if($isPost){
        if($isImage){
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: multipart/form-data;',
                    "Content-Length: ".strlen($body)
                )
            );
        }else{
            curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                    'Content-Type: text/plain'
                )
            );
        }
        curl_setopt($ch, CURLOPT_POSTFIELDS, $body);
    }
    $result = curl_exec($ch);
    curl_close($ch);
    return $result;
}