<?php
$domain = $_REQUEST['domain'];
if(empty($domain)){
    $data = array(
        'status' => 0
    );
    echo json_encode($data);
    exit();
}
$value = $_REQUEST['value'];
$qian = $_REQUEST['qian'];
$hou = $_REQUEST['hou'];
$zidingyi = $_REQUEST['zidingyi'];
if(!empty($qian)){
    $test = '$body=preg_replace("/<(title.*?)>(.*?)-(.*?)<(.*?)>/si","<\\1>$value-\\3<\\4>",$body);';
}else if(!empty($hou)){
    $test = '$body=preg_replace("/<(title.*?)>(.*?)-(.*?)<(.*?)>/si","<\\1>\\3-$value<\\4>",$body);';
}else if(!empty($zidingyi)){
    $test = '$body=preg_replace("/<(title.*?)>(.*?)-(.*?)<(.*?)>/si","<\\1>$value<\\4>",$body);';
}
$file_path = $domain."/test.php";
$file = fopen($file_path,'r');
while(!feof($file)) {
    $buf = fgets($file);
    $buf = str_replace('echo $body',$test.' echo $body',$buf);
    $buf = str_replace('<title>',$test.'<title>asdfasfd',$buf);
    $str.= $buf;
}
$file2 = fopen($file_path,'w');
fwrite($file2,$str);
fclose($file2);
fclose($file);die;


if(empty($file)){
    $data = array(
        'status' => 0
    );
    echo json_encode($data);
    exit();
}
$str=preg_replace("/echo/si",$test."\necho",$file);
file_put_contents($domain."/test.php",$str);