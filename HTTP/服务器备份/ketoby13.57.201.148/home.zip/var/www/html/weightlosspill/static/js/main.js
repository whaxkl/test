// Constants
var baseUrl = window.location.origin;
if (location.hostname === "localhost" || location.hostname === "127.0.0.1") {
    baseUrl = "http://localhost/simpleketosystem";
}
var carthook_url = "https://konsciousketo.com/a/secure/checkout/f6UtJbtINMraAzBQw1KC";
var form_data_key = 'serialized_value';
var current_step_key = 'current_step';

// Hash Functions
function gotoHash() {
    var destHash = window.location.hash;
    destHash = destHash.substring(1);
    var nextQuizIndex = getQuizIndexFromHash(destHash);

    $('body').removeClass();

    if (nextQuizIndex >= 0) { // quiz area
        $('body').addClass('stepping');

        $('#msform fieldset').hide();
        var strSelector = '#msform fieldset:eq(' + nextQuizIndex + ')';
        $(strSelector).show();

        if (!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))) { // if NOT mobile devices
            console.log("nextQuizIndex = " + nextQuizIndex);
            if (nextQuizIndex == 10) {
                $('.q-measure input[name="height_ft"]').focus();
            } else if (nextQuizIndex == 11) {
                $('.q-measure input[name="curr_weight_po"]').focus();
            }
        }
        $('body').addClass(('stepnum' + (nextQuizIndex + 1)));
    } else {
        if (destHash === "processing") { // processing area
            $('body').addClass('processing');
            ///+++
            if ($('.processing-area .button-area').css("visibility") == "hidden") {
                console.log("hidden!");
                playProcessing();
            }
        }
    }
}

window.onhashchange = function () {
    if (window.location.hash != '#undefined') {
        gotoHash();
    } else {
        history.pushState("", document.title, window.location.pathname);
        location.reload();
    }
};

function isNumberic(value) {
    return /^\d+$/.test(value);
}

function getQuizIndexFromHash(hash) {
    var returnVal = -1;
    if (isNumberic(hash) && hash > 0 && hash < 13) {
        returnVal = hash - 1;
    } else if (!hash || hash === '#undefined' || hash.length === 0) {
        returnVal = 0;
    }
    return returnVal;
}


$(document).ready(function () {

    // if quiz page
    if (!($('body').hasClass('email') ||
            $('body').hasClass('summary') ||
            $('body').hasClass('processing') ||
            $('body').hasClass('pricing') ||
            $('body').hasClass('mealplan') ||
            $('body').hasClass('recover'))
            ) {
        getClientIp();
        gotoHash();


        ///+++ last page retarget test 1
        /*
         if (window.location.href == baseUrl || window.location.href == baseUrl + "/") {
         var current_step = localStorage.getItem(current_step_key);
         if (current_step) {
         
         if (current_step == "#email") {
         window.location.href = baseUrl + '/email';
         } else if (current_step == "#summary") {
         window.location.href = baseUrl + '/summary';
         } else if (current_step == "#pricing") {
         window.location.href = baseUrl + '/pricing';
         } else {
         if (window.location.href != baseUrl + '/' + current_step) {
         window.location.href = baseUrl + current_step;
         }
         }
         }
         } else {
         var serialized_value = localStorage.getItem(form_data_key);
         if (serialized_value && serialized_value.length > 0) {
         serialized_value = JSON.parse(serialized_value);
         }
         console.log(serialized_value);
         populateForm();
         }
         */
        // last page retarget test end







    }

    // if processing page 
    if ($('body').hasClass('processing')) {
        $(document).scrollTop(0);
    }
    // if email page
    if ($('body').hasClass('email')) {
        localStorage.setItem(current_step_key, "#email");
        if (window.location.href.indexOf("/up6_subscription/") > -1) {
            $('body.email .input-area.name-input-area').css('display', 'flex');
        }
    }
    // if summary page
    if ($('body').hasClass('summary')) {
        if (window.location.href.indexOf("/up6_subscription/") > -1) {
            $('body.summary #whatyouget .text-area .item:nth-child(1) .item-texts .item-text-container span.title').text("A Personalized Keto Meal Plan:");
            $('body.summary #whatyouget .text-area .item:nth-child(1) .item-texts .item-text-container span:nth-child(2)').text("You get a comprehensive Keto Meal Plan designed specifically to fit YOUR body and Your health goals.");
        }
        var uid = getQueryString('uid');
        if (uid) {
            $.ajax({
                type: "POST",
                url: baseUrl + '/api/getquiz.php',
                data: {'uid': uid},
                dataType: "json",
                success: function (resp) {
                    console.log('getquiz.php resp!!!');
                    console.log(resp);
                    if (resp['quiz']) {
                        var strQuiz = resp['quiz'];
                        var objQuiz = JSON.parse(strQuiz);
                        startCalculation(false, objQuiz);
                    }
                    var email_data = [{"name": "email", "value": objQuiz['email']}];
//                    [{"name":"gender","value":"1"},{"name":"q_familiar","value":"2"},{"name":"beef","value":"1"},{"name":"asparagus","value":"1"},{"name":"q_activity","value":"3"},{"name":"q_tired","value":"3"},{"name":"goal_8","value":"1"},{"name":"input_term","value":"imperial"},{"name":"height_cm","value":""},{"name":"age_metric","value":""},{"name":"height_ft","value":"3"},{"name":"height_in","value":"45"},{"name":"age_imperial","value":"34"},{"name":"curr_weight_kg","value":""},{"name":"goal_weight_kg","value":""},{"name":"curr_weight_po","value":"345"},{"name":"goal_weight_po","value":"345"}]
                    localStorage.setItem(form_data_key, JSON.stringify(email_data));
                },
                error: function (xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText + ", Error: " + error;
                    alert('Error - ' + errorMessage);
                }
            });
        } else {
            startCalculation();
            localStorage.setItem(current_step_key, "#summary");///+++thinking
        }


    }

    // if pricing page
    if ($('body').hasClass('pricing')) {

        localStorage.setItem(current_step_key, "#pricing");

        var email = getQuizDataFromLocalStorage('email');
        console.log('email = ' + email);
        if (!email || email && email.length == 0) {
            window.location.href = baseUrl;
            alert("To process your custom meal plan please complete the quiz to select your preferences.");
        }
        if (window.location.href.indexOf("/up6_subscription/") > -1) {
            carthook_url = "https://konsciousketo.com/a/secure/checkout/GasWMIFDXX2cXIubk6Z9";
            $('body.pricing .whatyouget .lifetime-access.lifetime-access-2').text("Enjoy a Lifetime of Health. Just Click Below to Get Started!");            
            $('body.pricing section.faq .faq-content .panel:nth-child(1) p').text("Once you order today, you get instant access to easy-to-follow meal plans based on your nutritional requirements and goal weight. Each of the meals contained in your personalized Simple Keto System meal plan was designed by a professional chef and overseen by our keto nutritionist.");
            $('body.pricing section.faq .faq-content .panel:nth-child(2) p').text("It's important to understand everyone is different, and their levels of commitment are different as well. That being said, our goal was to make a meal plan is simple enough to get started, and delicious enough to stick with it long term. Each of the meals contains ingredients you’ve personally selected and are designed by our personal chef and nutritionist. We have heard from folks who have lost 2-4 pounds per week using our meal plan. Of course, your results will vary with your metabolism and specific goals. We’re confident once you claim your personalized Simple Keto System meal plan today - and enjoy each of the delicious meals, hitting your goal weight will be fun and enjoyable.");
            $('body.pricing section.faq .faq-content .panel:nth-child(3) p').text("If you begin losing weight faster than you feel comfortable, it’s really easy to adjust and slow the pace of weight loss down. Losing 1-2 pounds per week is a normal and healthy way to reach your weight loss goals. If you are losing weight faster than this, you may choose to only do 5 days on your Simple Keto System meal plan, and 2 days on a regular diet - it’s that simple.");
        }
        if (window.location.href.indexOf("/esc/") > -1) {
            carthook_url = "https://konsciousketo.com/a/secure/checkout/ALlHVvQhFZ9t9z1sMKDA";
        }
        var carthook_payment_link = carthook_url + "?email=" + encodeURIComponent(email);
        if (window.location.href.indexOf("/get/") > -1) {
            $('body.pricing .timer-area').hide();
            var html = '<img class="w-100 w-md-60 mx-auto d-block d-sm-none mb-3" src="' + baseUrl + '/assets/img/pricing-header-review-all-get.jpg" alt="">';
            html += '<img class="w-100 w-md-75 mx-auto d-none d-sm-block mb-3" src="' + baseUrl + '/assets/img/pricing-header-review-all-get-desktop.jpg" alt="">';
            $('body.pricing .success-section .review-list').html(html);
            carthook_payment_link += "&version=get";
        }
        $('body.pricing .btn-continue.submit').attr('href', carthook_payment_link);

        var timer2 = "10:01";
        var interval = setInterval(function () {
            var timer = timer2.split(':');
            //by parsing integer, I avoid all extra string processing
            var minutes = parseInt(timer[0], 10);
            var seconds = parseInt(timer[1], 10);
            --seconds;
            minutes = (seconds < 0) ? --minutes : minutes;
            if (minutes < 0) {
                clearInterval(interval);
            } else {
                seconds = (seconds < 0) ? 59 : seconds;
                seconds = (seconds < 10) ? '0' + seconds : seconds;
                minutes = (minutes < 10) ? '0' + minutes : minutes;

                $('body.pricing .countdown .timer-min').html(minutes);
                $('body.pricing .countdown .timer-sec').html(seconds);

                timer2 = minutes + ':' + seconds;
            }
        }, 1000);
    }

    // mobile keyboard
    if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) { // if mobile devices

        var _originalSize = $(window).width() + $(window).height();
        $(window).resize(function () {
            if ($(window).width() + $(window).height() !== _originalSize) {//if keyboard is shown
//                alert('keyboard open!');
                if ($('body.stepping').hasClass('stepnum10') || $('body.stepping').hasClass('stepnum11')) {
//                    alert('keyboard open!');
                    $('html, body').animate({
                        scrollTop: $(document).height()
                    }, 0);
                    return false;
                } else if ($('body').hasClass('email')) {
//                    alert('keyboard open!');
                    $('html, body').animate({
                        scrollTop: 150
                    }, 0);
                    return false;
                }
            } else {
//                alert('keyboard close!');
            }
        });
    }


});

function getClientIp() {
    console.log("geoplugin start");
    $.getJSON('https://api.ipify.org?format=jsonp&callback=?', function (data) {
        console.log("geoplugin response");
        console.log(JSON.stringify(data, null, 2));
        localStorage.setItem("client_ip", data['ip']);
    });
}


$(document).on('click', '.orb.orb_3', function (event) {
    var gender = 0;
    if ($(this).closest('.gender-circle').hasClass('male')) {
        console.log("man");
        gender = 1;
        $('#msform').removeClass('female-theme').addClass('male-theme');
    } else {
        console.log('woman');
        gender = 0;
        $('#msform').removeClass('male-theme').addClass('female-theme');
    }
    $(this).closest('fieldset').find("#gender").val(gender);
    $(this).closest("fieldset").find('.next.action-button').click();
});

$(document).on('click', 'body.pricing .btn-continue.submit', function (event) {
    event.preventDefault();
    event.stopPropagation();

    console.log('href link');
    console.log($(this).attr('href'));
    var carthook_payment_link = $(this).attr('href');

//    if (window.location.href.indexOf("/launch/") > -1) {
//        $('#order-bump-modal').modal('show');
//    } else {
//        window.open(carthook_payment_link, "_self");    
//    }

    var modal_shown = $('#order-bump-modal').data('myval');
    if (modal_shown === "shown") {
        console.log("order bump modal is shown");
        $('#order-bump-modal').modal('show');
    } else {
        if ($('.order-bump-inline #order-bump-checkbox').prop('checked')) {
            var carthook_url = "https://konsciousketo.com/a/secure/checkout/nyqTSyEuOFcVitNDUUrf";
            var email = getQuizDataFromLocalStorage('email');
            carthook_payment_link = carthook_url + "?email=" + encodeURIComponent(email);
        }
        window.open(carthook_payment_link, "_self");
    }
});
$(document).on('click', '#order-bump-modal .ob-body button', function (event) {
    var carthook_payment_link = "";
    if ($(event.target).hasClass("btn-primary")) {
        console.log("yes");
        var carthook_url = "https://konsciousketo.com/a/secure/checkout/nyqTSyEuOFcVitNDUUrf";
        var email = getQuizDataFromLocalStorage('email');
        carthook_payment_link = carthook_url + "?email=" + encodeURIComponent(email);
    } else {
        console.log("no");
        carthook_payment_link = $("body.pricing .btn-continue.submit").attr('href');
    }
    window.open(carthook_payment_link, "_self");
});

function saveFormToLocalStorage() {
    var serialized_value = $('#msform').serializeArray();
//    console.log(form_data_key);
//    console.log(serialized_value);
    var email = getQuizDataFromLocalStorage('email');
    if (email && email.length > 0) {
        serialized_value.push({name: "email", "value": email});
    }
    localStorage.setItem(form_data_key, JSON.stringify(serialized_value));
}

function saveStepsToLocalStorage(stepnum) {
    //var steps = localStorage.getItem('steps');
}

function getQuizDataFromLocalStorage(key) {
    var serialized_value = localStorage.getItem(form_data_key);
    if (serialized_value && serialized_value.length > 0) {
        serialized_value = JSON.parse(serialized_value);
    } else {
        return null;
    }
    var dataObj = {};
    $(serialized_value).each(function (i, field) {
        dataObj[field.name] = field.value;
    });
    return dataObj[key];
}

$("fieldset.single-option input[type='radio']").click(function () {
    $(this).closest("fieldset").find('.next.action-button').click();
});

$("fieldset.q-changes input[type='radio']").change(function () {
    if ($(this).val() === "none") {
        console.log("none!");
        setTimeout(function () {
            console.log("none checked false!");
            $("fieldset.q-changes input[type='radio']").prop('checked', false);
        }, 800);
    }
});


$("fieldset.q-meat input[type='checkbox']").change(function () {
    var name = $(this).attr('name');
    console.log("name = " + name);
    if (name === 'no_meat') {
        if ($(this).is(":checked")) {
            $("fieldset.q-meat input[name!='no_meat']").prop('checked', false);
        }
    } else {
        if ($(this).is(":checked")) {
            $("fieldset.q-meat input[name='no_meat']").prop('checked', false);
        } else {
            var checkednum = $("fieldset.q-meat input[type='checkbox']:checked").length;
            console.log("checkednum = ", checkednum);
            if (checkednum === 0) {
                $("fieldset.q-meat input[name='no_meat']").prop('checked', true);
            }
        }
    }

    var checkedNum = $('fieldset.q-meat').find("input[type='checkbox']:checked").length;
    if (checkedNum > 0) {
        $('fieldset.q-meat .action-button.next').show();
    } else {
        $('fieldset.q-meat .action-button.next').hide();
    }
});

$("fieldset.q-goals input[type='checkbox']").change(function () {
    var checkedNum = $('fieldset.q-goals').find("input[type='checkbox']:checked").length;
    if (checkedNum > 0) {
        $('fieldset.q-goals .action-button.next').show();
        var maxHeight = $('fieldset.q-goals').height();
        $('#msform').height(maxHeight);
    } else {
        $('fieldset.q-goals .action-button.next').hide();
    }
});

//$('fieldset.single-option ')
$('.q-radio-measure').change(function () {
    console.log('q-radio-measure changed');

    if ($(this).is(":checked")) {
        console.log('checked');
        $(this).parent().parent().parent().siblings().find('.q-radio-measure').prop('checked', false);
        $(this).siblings().find('input[type=number]:first').focus();
    } else {
        console.log('unchecked');
    }
});
$('.q-measure input[type=number]').focus(function () {
    $(this).parents('.same-ratio-container').find('.q-radio-measure').prop('checked', true);
    $(this).parents('.m-form-checkboxes__item').siblings().find('.q-radio-measure').prop('checked', false);
});


$('.q-measure input[type=number]').on('input', function (e) {

    var targetValue = $(this).val();

    var key = e.which || this.value.substr(-1).charCodeAt(0);
    console.log(targetValue);
    console.log(key);

    if (key === 8 || key === 13 || key === 37 || key === 39 || key === 46) {
        return;
    }

    if ((key > 47 && key < 58) || (key > 95 && key < 106)) {
        var c = String.fromCharCode(key);
        var val = parseInt(c);
        var textVal = parseInt(targetValue || "0");
        var result = textVal + val;

        var name = $(this).attr('name');
        if (name.localeCompare("height_ft") === 0 && (result < 0 || result > 9 || targetValue.length >= 1)) {
            e.preventDefault();
            $('.q-measure input[name="height_in"]').focus();
        } else if (name.localeCompare("height_in") === 0 && (result < 0 || result > 99 || targetValue.length >= 2)) {
            e.preventDefault();
            $('.q-measure input[name="age_imperial"]').focus();
        } else if (name.localeCompare("age_imperial") === 0 && (result < 0 || result > 99 || targetValue.length >= 2)) {
            e.preventDefault();
            $(this).blur();
        } else if (name.localeCompare("height_cm") === 0 && (result < 0 || result > 999 || targetValue.length >= 3)) {
            e.preventDefault();
            $('.q-measure input[name="age_metric"]').focus();
        } else if (name.localeCompare("age_metric") === 0 && (result < 0 || result > 99 || targetValue.length >= 2)) {
            e.preventDefault();
            $(this).blur();
        } else if (name.localeCompare("curr_weight_po") === 0 && (result < 0 || result > 999 || targetValue.length >= 3)) {
            e.preventDefault();
            $('.q-measure input[name="goal_weight_po"]').focus();
        } else if (name.localeCompare("goal_weight_po") === 0 && (result < 0 || result > 999 || targetValue.length >= 3)) {
            e.preventDefault();
            $(this).blur();
        } else if (name.localeCompare("curr_weight_kg") === 0 && (result < 0 || result > 999 || targetValue.length >= 3)) {
            e.preventDefault();
            $('.q-measure input[name="goal_weight_kg"]').focus();
        } else if (name.localeCompare("goal_weight_kg") === 0 && (result < 0 || result > 999 || targetValue.length >= 3)) {
            e.preventDefault();
            $(this).blur();
        }

        if (targetValue === "0") {
            $(this).val(val);
            e.preventDefault();
        }
    } else {
        e.preventDefault();
    }
});

$('.input-term').change(function () {
    console.log('input term changed');
    if ($(this).is(":checked")) {
        if ($(this).val() === 'imperial') {
            $('.q-measure-metric').hide();
            $('.q-measure-imperial').show();
        } else {
            $('.q-measure-metric').show();
            $('.q-measure-imperial').hide();
        }
    }
});

$('.button-weeks-right').click(function () {
    if ($(".m-meal-weeks__select > option:selected").index() != 8) {
        $(".m-meal-weeks__select > option:selected")
                .prop("selected", false)
                .next()
                .prop("selected", true);
        $(".m-meal-weeks__select").trigger('change');
    }
});

$('.button-weeks-left').click(function () {
    if ($(".m-meal-weeks__select > option:selected").index() != 0) {
        $(".m-meal-weeks__select > option:selected")
                .prop("selected", false)
                .prev()
                .prop("selected", true);
        $(".m-meal-weeks__select").trigger('change');
    }
});

function saveHash(strHash) {
    console.log('saveHash = ' + strHash);
    if (history.pushState) {
        history.pushState(null, null, strHash);
    } else {
        location.hash = strHash;
    }

    gtag('config', 'UA-122527750-1', {'page_path': location.pathname + location.search + location.hash});

    if (strHash !== "#summary") {
        //save current form and step number///+++
        ///+++ last page retarget test 2
        /*
         var serialized_value = $('#msform').serializeArray();
         console.log(form_data_key);
         console.log(serialized_value);
         localStorage.setItem(form_data_key, JSON.stringify(serialized_value));
         */
        // last page retarget end
    }
    localStorage.setItem(current_step_key, strHash);
}


//jQuery time
var current_fs, next_fs, previous_fs; //fieldsets
var left, opacity, scale; //fieldset properties which we will animate
var animating; //flag to prevent quick multi-click glitches

$(document).on('click', '.action-button.next', function (event) {

    event.preventDefault();
    console.log('.action-button.next .clicked animating = ' + animating);

    if (animating)
        return false;
    animating = true;

    current_fs = $(this).parent().parent();
    next_fs = $(this).parent().parent().next();




    //activate next step on progressbar using the index of next_fs
//    $("#progressbar li").eq($("fieldset").index(next_fs)).addClass("active");

    var duration = 800;
    /* navbar image background */
    var nextQuizIndex = $("fieldset").index(next_fs);
    console.log("nextQuizIndex = " + nextQuizIndex);

    if (nextQuizIndex === 1) {
        $('body').addClass('stepping');
        $('body.stepping .masthead').addClass('back-trans-none');
//        $('body.stepping .quiz-area .quiz-column').removeClass('col-lg-7').addClass('col-lg-12');
        duration = 0;

        removeStepnumClass();
        $('body.stepping').addClass(('stepnum' + (nextQuizIndex + 1)));

        $('footer').hide();

    } else if (nextQuizIndex < 0) {

        if (!validateForm(false)) {
            animating = false;
            return;
        }
        saveFormToLocalStorage();

//        if ($('.processing-area .button-area').css("visibility") == "hidden") {
        $('#progress').html('');
        $('.processing-area #processing_carousel').show();
        $('.processing-area .button-area').css('visibility', 'hidden');

        playProcessing();

        removeStepnumClass();
        $('body').removeClass('stepping').addClass('processing');
        $(document).scrollTop(0);
        $('footer').hide();

    } else {
        if (nextQuizIndex === 11) {
            if (!validateForm(true)) {
                animating = false;
                return;
            }
        }
        $('body.stepping .masthead').removeClass('back-trans-none');
        removeStepnumClass();
        $('body.stepping').addClass(('stepnum' + (nextQuizIndex + 1)));

        $('footer').hide();
    }


    //show the next fieldset
    next_fs.show();

//    var iOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !window.MSStream;
//    if (iOS) {
//        $('.q-measure input[name="height_ft"]').focus();
//    }

    var maxHeight = next_fs.height() > current_fs.height() ? next_fs.height() : current_fs.height();
    $('#msform').height(maxHeight);

    //hide the current fieldset with style
    current_fs.animate({opacity: 0}, {
        step: function (now, mx) {
            if (now < 1) {
//                return;
            }


            //as the opacity of current_fs reduces to 0 - stored in "now"
            //1. scale current_fs down to 80%
            scale = 1 - (1 - now) * 0.2;

            //2. bring next_fs from the right(50%)
            left = (now * 50) + "%";
            //3. increase opacity of next_fs to 1 as it moves in
            opacity = 1 - now;

            current_fs.css({
                'transform': 'scale(' + scale + ')',
                'position': 'relative',
                'top': 0
            });
            next_fs.css({'left': left, 'opacity': opacity, 'position': 'absolute', 'top': '0'});
//            next_fs.css({'left': left, 'opacity': opacity});
        },
        duration: duration,
        complete: function () {
            current_fs.hide();
            current_fs.css({
                'transform': 'scale(1)',
                'opacity': 1
            });
            animating = false;

            current_fs = next_fs;
            current_fs.css({'position': 'relative'});
            $('#msform').height('initial');

            var strHash = nextQuizIndex < 0 ? "#processing" : ("#" + (nextQuizIndex + 1));
            saveHash(strHash);

            if (nextQuizIndex == 1) {
                jumbleberry("init", "9AjB2Ho3E4Y8QdikAkP-0xf074T4KB17rj06I1oTX01yUbq9bipKJ39elFU5ys8qk0VpmLCnxMf4-Xb07AhjvA~~");
                jumbleberry("track", "ViewContent");
            }

            if (!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))) { // if NOT mobile devices
                if (nextQuizIndex == 10) {
                    $('.q-measure input[name="height_ft"]').focus();
                } else if (nextQuizIndex == 11) {
                    $('.q-measure input[name="curr_weight_po"]').focus();
                }
            }
        },
        //this comes from the custom easing plugin
        easing: 'easeInOutBack'
    });
});

$(".action-button.previous").click(function (event) {
    event.preventDefault();

    if (animating)
        return false;
    animating = true;

    current_fs = $(this).parent().parent();
    previous_fs = $(this).parent().parent().prev();

    //de-activate current step on progressbar
//    $("#progressbar li").eq($("fieldset").index(current_fs)).removeClass("active");

    /* navbar image background */
    var nextQuizIndex = $("fieldset").index(previous_fs);


    var duration = 800;
    removeStepnumClass();
    if (nextQuizIndex === 0) {
        $('body.stepping .masthead').addClass('back-trans-none');
//        $('body.stepping .quiz-area .quiz-column').removeClass('col-lg-12').addClass('col-lg-7');

        $('body').addClass(('stepnum' + (nextQuizIndex + 1)));
        duration = 0;

        $('footer').show();
    } else {
        $('body.stepping .masthead').removeClass('back-trans-none');
        console.log('removestepnum previous pageindex = ' + (nextQuizIndex + 1));
        $('body.stepping').addClass(('stepnum' + (nextQuizIndex + 1)));

        $('footer').hide();
    }



    //show the previous fieldset
    previous_fs.show();

    var maxHeight = previous_fs.height() > current_fs.height() ? previous_fs.height() : current_fs.height();
    $('#msform').height(maxHeight);

    //hide the current fieldset with style
    current_fs.animate({opacity: 0}, {
        step: function (now, mx) {
            //as the opacity of current_fs reduces to 0 - stored in "now"
            //1. scale previous_fs from 80% to 100%
            scale = 0.8 + (1 - now) * 0.2;
            //2. take current_fs to the right(50%) - from 0%
            left = ((1 - now) * 50) + "%";
            //3. increase opacity of previous_fs to 1 as it moves in
            opacity = 1 - now;
            current_fs.css({'left': left, 'position': 'relative'});
            previous_fs.css({
                'transform': 'scale(' + scale + ')',
                'opacity': opacity,
                'position': 'absolute'
            });
        },
        duration: duration,
        complete: function () {
            current_fs.hide();
            current_fs.css({
                'transform': 'scale(1)',
                'opacity': 1,
                'left': 'initial'
            });

            animating = false;
            current_fs = previous_fs;

            current_fs.css({'position': 'relative'});
            $('#msform').height('initial');

            var strHash = "#" + (nextQuizIndex + 1);
            saveHash(strHash);

            if (!(/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent))) { // if NOT mobile devices
                if (nextQuizIndex == 9) {
                    $('.q-measure input[name="height_ft"]').focus();
                } else if (nextQuizIndex == 10) {
                    $('.q-measure input[name="curr_weight_po"]').focus();
                }
            }
        },
        //this comes from the custom easing plugin
        easing: 'easeInOutBack'
    });
});

function gotoPage(index) {

}


$(".email-area .btn-continue").click(function (event) {
    event.preventDefault();
    event.stopPropagation();

    if (!validateEmailForm()) {
        return;
    }

    if ($('body').hasClass('recover')) {
        var email = $('.email-area #input-email').val();
        if (window.location.href.indexOf("/up6_subscription/") > -1) {
            var first_name = $('.email-area .input-first-name').val();
        }
        $.ajax({
            type: "POST",
            url: baseUrl + '/api/getuid.php',
            data: {'email': email},
            dataType: "json",
            success: function (resp) {
                console.log('getuid.php resp!!!');
                console.log(resp);
                var getUrl = window.location;

                if (!resp['uid'] || resp['uid'].length === 0) {
                    var strWarning = "There is no meal plan registered under this email address. Please contact customer support.";
                    $('body.recover .email-area .warning-text').text(strWarning).css('display', 'inline-block');
                } else {
                    $('.email-area .warning-text').hide();

                    var mealplanUrl = baseUrl + "/mealplan?uid=" + resp['uid'];
                    window.open(mealplanUrl, "_self");

                }

            },
            error: function (xhr, status, error) {
                var errorMessage = xhr.status + ': ' + xhr.statusText + ", Error: " + error;
                alert('Error - ' + errorMessage);
            }
        });
    } else {
        var serialized_value = localStorage.getItem(form_data_key);
        if (serialized_value && serialized_value.length > 0) {
            serialized_value = JSON.parse(serialized_value);
        } else {
            window.location.href = baseUrl;
            alert("To process your custom meal plan please complete the quiz to select your preferences.");
        }
        var email = $('.email-area #input-email').val();

        serialized_value.push({name: "email", "value": email});
        serialized_value.push({name: "client_ip", "value": localStorage.getItem('client_ip')});
        //serialized_value.push({name: "client_device", "value": localStorage.getItem('client_device')});

        var version = "main";
        if (window.location.href.indexOf("/get/") > -1) {
            version = "get";
        } else if (window.location.href.indexOf("/start/") > -1) {
            version = "start";
        }
        serialized_value.push({name: "version", "value": version});

        if (window.location.href.indexOf("/up6_subscription/") > -1) {
            var first_name = $('.email-area #input-first-name').val();
            serialized_value.push({name: "first_name", "value": first_name});
        }
        localStorage.setItem(form_data_key, JSON.stringify(serialized_value));



        var calcResults = startCalculation();
        serialized_value = serialized_value.concat(calcResults);

        console.log(serialized_value);
        console.log("final serialized_value");
        localStorage.setItem(form_data_key, JSON.stringify(serialized_value));
        serialized_value = localStorage.getItem(form_data_key);

        if (serialized_value && serialized_value.length > 0) {
            serialized_value = JSON.parse(serialized_value);
            console.log('serialized_value = ');
            console.log(serialized_value);
            var email = getQuizDataFromLocalStorage('email');
            console.log('email = ' + email);

            $.ajax({
                type: "POST",
                url: baseUrl + '/api/savequiz.php',
                data: serialized_value,
                dataType: "json",
                success: function (resp) {
                    console.log('savequiz.php resp!!!');
                    console.log(resp);
                    if (resp.status === "success") {
                        //affiliate code start
                        var data1 = getQueryString('data1');
                        var a_aid = getQueryString('a_aid');
                        if (data1 && data1.length > 0 && a_aid && a_aid == "db1e6546") {
                            var postbackUrl = 'https://cors-anywhere.herokuapp.com/https://track.ingwire.com/postback?cid=' + data1 + '&txid=KSK-email&et=email_signup';

                            var jqxhr = $.post(postbackUrl, function () {
                                console.log("affiliate success");
                            })
                                    .done(function () {
                                        console.log("affiliate second success");
                                    })
                                    .fail(function (xhr, status, error) {
                                        console.log(xhr, status, error);
                                        console.log("affiliate error");
                                    })
                                    .always(function () {
                                        console.log("affiliate finished");
                                    });
                        }
                        //affiliate code end

                        window.location.href = baseUrl + "/summary";

                    } else {
                        window.location.href = baseUrl;
                        alert("To process your custom meal plan please complete the quiz to select your preferences.");
                    }
                },
                error: function (xhr, status, error) {
                    var errorMessage = xhr.status + ': ' + xhr.statusText + ", Error: " + error;
                    alert('Error - ' + errorMessage);
                }
            });
        } else {
            window.location.href = baseUrl;
            alert("To process your custom meal plan please complete the quiz to select your preferences.");
            console.log("no serialized value");
        }



    }
});

function validateForm(isHeightAge) {
    var returnVal = true;
    var inputNames = [];

    if ($('#msform input[name="input_term"]:checked').val() === 'imperial') {
        if (isHeightAge) {
            inputNames = ['height_ft', 'age_imperial'];
        } else {
            inputNames = ['goal_weight_po', 'curr_weight_po'];
        }
    } else {
        if (isHeightAge) {
            inputNames = ['height_cm', 'age_metric'];
        } else {
            inputNames = ['goal_weight_kg', 'curr_weight_kg'];
        }
    }

    var str_warning = '';

    for (var i in inputNames) {
        var strSelector = '#msform input[name="' + inputNames[i] + '"]';

        if (!$(strSelector).val()) {
            $(strSelector).addClass('warning');
            str_warning = 'Oops!  Please enter your selection before proceeding to the next page.';
            returnVal = false;
        } else {
            if ((inputNames[i] == "age_imperial" || inputNames[i] == "age_metric")
                    && ($(strSelector).val() < 18 || $(strSelector).val() > 90)) {
                str_warning = "Please enter between 18 and 90 for your age.";
                $('fieldset.q-measure-height-age .warning-text').text(str_warning);
                returnVal = false;
            } else if ((inputNames[i] == "height_ft")
                    && (($(strSelector).val() < 3 || ($(strSelector).val() == 3 && $('#msform input[name="height_in"]').val() < 6)) ||
                            ($(strSelector).val() > 7 || ($(strSelector).val() == 7 && $('#msform input[name="height_in"]').val() > 10))
                            )) {
                str_warning = "Please enter between 3ft 6in and 7ft 10in for your height.";
                $('fieldset.q-measure-height-age .warning-text').text(str_warning);
                returnVal = false;
            } else if ((inputNames[i] == "height_cm")
                    && ($(strSelector).val() < 106 || $(strSelector).val() > 238)) {
                str_warning = "Please enter between 106cm and 238cm for your height.";
                $('fieldset.q-measure-height-age .warning-text').text(str_warning);
                returnVal = false;
            } else if ((inputNames[i] == "curr_weight_po")
                    && ($(strSelector).val() < 110 || $(strSelector).val() > 850)) {
                str_warning = "Please enter between 110lbs and 850lbs for your current weight.";
                $('fieldset.q-measure-weight .warning-text').text(str_warning);
                returnVal = false;
            } else if ((inputNames[i] == "goal_weight_po")
                    && ($(strSelector).val() < 100 || $(strSelector).val() > 500)) {
                str_warning = "Please enter between 100lbs and 500lbs for your goal weight.";
                $('fieldset.q-measure-weight .warning-text').text(str_warning);
                returnVal = false;
            } else if ((inputNames[i] == "curr_weight_kg")
                    && ($(strSelector).val() < 50 || $(strSelector).val() > 385)) {
                str_warning = "Please enter between 50kg and 385kg for your current weight.";
                $('fieldset.q-measure-weight .warning-text').text(str_warning);
                returnVal = false;
            } else if ((inputNames[i] == "goal_weight_kg")
                    && ($(strSelector).val() < 45 || $(strSelector).val() > 227)) {
                str_warning = "Please enter between 45kg and 227kg for your goal weight.";
                $('fieldset.q-measure-weight .warning-text').text(str_warning);
                returnVal = false;
            } else {
                $(strSelector).removeClass('warning');
            }
        }
    }
    if (!returnVal) {
        if (isHeightAge) {
            $('fieldset.q-measure-height-age .warning-text').css('display', 'inline-block');
        } else {
            $('fieldset.q-measure-weight .warning-text').css('display', 'inline-block');
        }
    } else {
        if (isHeightAge) {
            $('fieldset.q-measure-height-age .warning-text').hide();
        } else {
            $('fieldset.q-measure-weight .warning-text').hide();
        }
    }
    console.log('validateForm-returnVal = ' + returnVal);

    return returnVal;
}

function validateEmailForm() {
    var returnVal = true;

    var email = $('.email-area #input-email').val();
    var strWarning = "";
    if (window.location.href.indexOf("/up6_subscription/") > -1) {
        var first_name = $('.email-area #input-first-name').val();
        if (first_name.length === 0) {
            strWarning = "Please enter first name.";
        }
    }
    if (email.length === 0) {
        strWarning = "Please enter email address.";
    } else if (!validateEmail(email)) {
        strWarning = "Please enter valid email address.";
    }
    $('.email-area .warning-text').text(strWarning);
    if (strWarning.length > 0) {
        $('.email-area .warning-text').css('display', 'inline-block');
        returnVal = false;
    } else {
        $('.email-area .warning-text').hide();
    }
    return returnVal;
}
$('.email-area #input-email').on('change', function () {
    validateEmailForm();
});
$('.email-area .tos-link').click(function (e) {
    e.preventDefault();

    var link = $(this).attr("href");

    var h = screen.height * .8;
    var w = screen.width * .8;
    window.open(this.href, link, 'toolbar=no ,location=0, status=no,titlebar=no,menubar=no,width=' + w + ',height=' + h);
});

function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

//$('#processing_video').on('ended', function () {
//    console.log('Video has ended!');
//    $('.processing-area #processing_carousel').hide();
////    $('.processing-area .button-area').show();
//    $('.processing-area .button-area').css('visibility', 'visible');
//});

function playProcessing() {
    var circle = new ProgressBar.Circle('#progress', {
        color: '#F9464B',
        duration: 5000,
        easing: 'easeInOut',
        trailColor: '#EDD1D1',
        trailWidth: 6,
        strokeWidth: 6,
        svgStyle: null,
        text: {
            autoStyleContainer: false
        },
        step: function (state, circle) {
            var value = Math.round(circle.value() * 100);
            if (value === 0) {
                circle.setText('');
            } else {
                var html = value + "<span class=percent-span>%</span>";
                circle.setText(html);
            }
        }
    });
    circle.text.style.fontFamily = 'Proxima Nova Bold';
    circle.text.style.fontSize = '6.5rem';

    circle.animate(1, function () {
        console.log('Video has ended!');
        $('.processing-area #processing_carousel').hide();
        $('.processing-area .button-area').css('visibility', 'visible');
        if ($('body').hasClass('processing')) {
            setTimeout(function () {
                // main version
                window.location.href = baseUrl + "/email";

                // email retarget version ///+++
                /*
                 var email = getQuizDataFromLocalStorage('email');
                 if (!email || email && email.length == 0) {
                 window.location.href = baseUrl + "/email";
                 } else {
                 window.location.href = baseUrl + "/summary";
                 }
                 */
                // email retarget version end


            }, 1000);
        }
    });
    carouselAnimStart();
}
var processing_text_counter = 0;
var processing_timer;
function carouselAnimStart() {
    processing_timer = setInterval(carouselTimer, 700);
}
function carouselTimer() {
    var selector = "#processing_carousel li:eq(" + processing_text_counter + ")";
    $(selector).css('visibility', 'visible');
    processing_text_counter++;
    if (processing_text_counter >= $('#processing_carousel li').length) {
        processing_text_counter = 0;
        clearInterval(processing_timer); // uncomment this if you want to stop refreshing after one cycle
    }
}

$('#summary-section-area section#summary .btn-continue').click(function (event) {
    event.preventDefault();

    window.location.href = baseUrl + '/pricing';
});


function removeStepnumClass() {
    console.log('removestepnum');
    $('body').removeClass(function (index, className) {
        return (className.match(/(^|\s)stepnum\S+/g) || []).join(' ');
    });
}

function readmoreClicked(btn_readmore) {
    var moreText = $(btn_readmore).parent().find('.more-text');
    var btnText = $(btn_readmore);
    var parent = $(btn_readmore).parent();

    if ($(moreText).css('display') != 'none') {
//    if ($(btnText).html() == 'Read Less') {
        $(btnText).html('Learn More <i class="fa fa-angle-down"></i>');
        $(moreText).hide();
        $(parent).css('height', '8.3rem');
    } else {
        $(btnText).html('Show Less <i class="fa fa-angle-up"></i>');
        $(moreText).css('display', 'inline');
        $(parent).css('height', 'initial');
    }
}

/* pricing page accordion menu */
$(document).on('click', '.accordion', function (event) {
    this.classList.toggle("active");
    var panel = this.nextElementSibling;
    if (panel.style.maxHeight) {
        panel.style.maxHeight = null;
    } else {
        panel.style.maxHeight = panel.scrollHeight + "px";
    }
});

function getQueryString() {// use instead of searchParams
    var key = false, res = {}, itm = null;
    // get the query string without the ?
    var qs = location.search.substring(1);
    // check for the key as an argument
    if (arguments.length > 0 && arguments[0].length > 1)
        key = arguments[0];
    // make a regex pattern to grab key/value
    var pattern = /([^&=]+)=([^&]*)/g;
    // loop the items in the query string, either
    // find a match to the argument, or build an object
    // with key/value pairs
    while (itm = pattern.exec(qs)) {
        if (key !== false && decodeURIComponent(itm[1]) === key)
            return decodeURIComponent(itm[2]);
        else if (key === false)
            res[decodeURIComponent(itm[1])] = decodeURIComponent(itm[2]);
    }

    return key === false ? res : null;
}

// Unused functions
function populateForm(data) {
    var serialized_value = localStorage.getItem(form_data_key);
    if (serialized_value && serialized_value.length > 0) {
        serialized_value = JSON.parse(serialized_value);
    } else {
        return null;
    }
    var dataObj = {};
    $(serialized_value).each(function (i, field) {
        dataObj[field.name] = field.value;
        var ctrl = $('[name=' + field.name + ']', $('#msform'));
        if (ctrl.prop("type") == "checkbox") {
//            console.log(field.name);
            if ($(ctrl).attr('value') == field.value)
                $(ctrl).attr("checked", field.value);
//            $("fieldset.q-changes input[type='radio']").prop('checked', false);
        } else if (ctrl.prop("type") == "radio") {
            var ctrl = $('[name=' + field.name + '][value=' + field.value + ']', $('#msform'));
            $(ctrl).prop('checked', true);
        } else {
            ctrl.val(field.value);
        }
    });
}

$(document).on('click', '.switch-video', function (e) {
    e.preventDefault();
    e.stopPropagation();

    console.log($(this).attr('id'));

    var id = $(this).attr('id');
    $(this).addClass('selected');
    $('.twovideosection .switch-video').not(this).removeClass('selected');

    var selector = ".twovideosection .wistia_responsive_padding." + id;
    $(selector).show();
    var selector = ".twovideosection .wistia_responsive_padding:not(." + id + ")";
    $(selector).hide();
});