<?php
	//var_dump($_FILES['file']);die;
	//var_dump($_FILES,$_FILES['file']['type']);die;
	/*$rar = stripos($_FILES['file']['name'],'.rar');
	$zip = stripos($_FILES['file']['name'],'.zip');
	if($rar===false && $zip===false){
		echo "<script>alert('请选择项目压缩包文件！');</script>";
        echo "<script>history.back();</script></script>";
        exit;
	}
	if($rar!==false){
		$file_name = substr($_FILES['file']['name'],0,$rar);
	}
	if($zip!==false){
		$file_name = substr($_FILES['file']['name'],0,$zip);
	}
	//var_dump($rar,$zip,$file_name);die;
	move_uploaded_file($_FILES["file"]["tmp_name"],
      "upload/" . $_FILES["file"]["name"]);
	//实例化ZipArchive类
	$zip = new ZipArchive();
	//打开压缩文件，打开成功时返回true
	if ($zip->open("upload/" . $_FILES["file"]["name"]) === true) {
		//解压文件到获得的路径a文件夹下
		$zip->extractTo('/var/www/html');
		//关闭
		$zip->close();
		echo 'ok';
	} else {
		echo 'error';
	}*/
	//unlink("upload/" . $_FILES["file"]["name"]);
	//delDirAndFile('/var/www/html/'.$file_name);
	function delDirAndFile($dirName){
		if ( $handle = opendir( "$dirName" ) ) {
		   while ( false !== ( $item = readdir( $handle ) ) ) {
				if ( $item != "." && $item != ".." ) {
					if ( is_dir( "$dirName/$item" ) ) {
						delDirAndFile( "$dirName/$item" );
					} else {
						unlink( "$dirName/$item" );
					}
				}
		   }
		   closedir( $handle );
		   rmdir( $dirName );
		}
	}
    $value = $_POST['choose'];
    if($value == '')
    {
        echo "<script>alert('请选择提交方式！');</script>";
        echo "<script>history.back();</script></script>";
        exit;
    }
    $file = $_POST['file'];
    if(@$file['file'] == '')
    {
        echo "<script>alert('配置文件不能为空！');</script>";
        echo "<script>window.location.href='https://ketoby.cn/config/conf.html';</script>";
        exit;
    }
    $local_file = '/var/www/html/weightlosspill/config/upload/'.$file;
    if(!file_exists($local_file))
    {
        echo "<script>alert('配置文件找不到！');</script>";
        echo "<script>window.location.href='https://ketoby.cn/config/conf.html';</script></script>";
        exit;
    }
    $host = $_POST['ip'];
    $username = $_POST['username'];
    if(empty($host))
    {
        echo "<script>alert('ip不能为空！');</script>";
        echo "<script>history.back();</script></script>";
        exit;
    }
    if(empty($username))
    {
        echo "<script>alert('用户名不能为空！');</script>";
        echo "<script>history.back();</script></script>";
        exit;
    }
    if(!function_exists("ssh2_connect"))
    {
        echo "<script>alert('ssh拓展没有安装成功！');</script>";
        echo "<script>history.back();</script></script>";
        exit;
    }
    if($value == 1)
    {
        $connection = ssh2_connect($host, 22, array('hostkey'=>'ssh-rsa'));
        $res = ssh2_auth_pubkey_file($connection, $username, '/tmp/id_rsa.pub', '/tmp/key.pem');

        if ($res !== FALSE)
        {
            $remote_file = '/etc/nginx/conf.d/'.$file;
            if(ssh2_scp_send($connection,$local_file,$remote_file,0644))
            {
                echo "<script>alert('配置成功！');</script>";
                echo "<script>history.back();</script>";
            }else{
                echo "<script>alert('配置失败！');</script>";
                echo "<script>history.back();</script>";
            }
			/*$scp_data = "scp -v -r /var/www/html/".$file_name."  ".$host.":/var/www/html/".$file_name;
			echo exec($scp_data);
			echo system($scp_data);
			if(ssh2_scp_send($connection,'/var/www/html/weightlosspill/config/upload/'.$_FILES["file"]["name"],'/var/www/html/' . $_FILES["file"]["name"],0777))
            {
                echo "<script>alert('配置文件成功！');</script>";
                //echo "<script>history.back();</script></script>";
            }else{
                echo "<script>alert('配置文件失败！');</script>";
                //echo "<script>history.back();</script></script>";
            }
			$testd = ssh2_exec($connection,"unzip /var/www/html/".$_FILES["file"]["name"]." -d /var/www/html/".$file_name);
			$testd = ssh2_exec($connection,"ls");
			stream_set_blocking($testd,true);

			echo stream_get_contents($testd);die;
			var_dump($_FILES["file"]["name"],$file_name,$testd);*/
        }
    }else if($value == 2)
    {
        $password = $_POST['password'];
        if($password == '')
        {
            echo "<script>alert('请输入密码！');</script>";
            echo "<script>history.back();</script></script>";
            exit;
        }
        $connection = ssh2_connect($host,22);
        $result = ssh2_auth_password($connection,$username,$password);
        if($result)
        {
            $remote_file = '/etc/nginx/conf.d/'.$file;
            if(ssh2_scp_send($connection,$local_file,$remote_file,0644))
            {
                echo "<script>alert('配置成功！');</script>";
                echo "<script>history.back();</script></script>";
            }else{
                echo "<script>alert('配置失败！');</script>";
                echo "<script>history.back();</script></script>";
            }
        }
    }